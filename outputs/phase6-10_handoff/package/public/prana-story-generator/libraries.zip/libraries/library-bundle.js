window.PRANA_STORY_LIBRARY_BUNDLE = {
  "sourceWorkbook": "C:\\Users\\Madhurima Agarwal\\Downloads\\Prana_Kids_Full_Library_v12.xlsx",
  "libraryCount": 21,
  "libraries": {
    "childhoodSituations": [
      {
        "id": 1,
        "slug": "toy-not-shared-or-taken-away",
        "name": "Toy not shared or taken away",
        "category": "Anger & Frustration",
        "coreNeed": "Self-Control",
        "falseBelief": "I have to react when things feel unfair.",
        "trueBelief": "I can pause and choose my response.",
        "feeling": "Hot frustration and a flash of 'that's mine' — wanting to grab it back.",
        "parentTeach": "That other people's feelings matter too, even when something feels unfair.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Friendship & Sharing",
          "Playing & Games",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 2,
        "slug": "screen-time-cut-off-suddenly",
        "name": "Screen time cut off suddenly",
        "category": "Anger & Frustration",
        "coreNeed": "Self-Control",
        "falseBelief": "I have to get what I want immediately.",
        "trueBelief": "I can handle disappointment and make wise choices.",
        "feeling": "A sudden jolt of protest — the fun was cut off with no warning.",
        "parentTeach": "That transitions go easier with a heads-up, and endings aren't punishments.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 3,
        "slug": "told-no-without-explanation",
        "name": "Told 'no' without explanation",
        "category": "Anger & Frustration",
        "coreNeed": "Respect",
        "falseBelief": "If people say \"no\", they don't care about me.",
        "trueBelief": "I can listen, ask and understand even when I don't like the answer.",
        "feeling": "Stubborn defiance — wanting a reason, not just an order.",
        "parentTeach": "That some rules don't need debate, and trust can hold even without an explanation.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Communication",
          "Family & Daily Life",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 4,
        "slug": "sibling-gets-bigger-portion-or-more-attention",
        "name": "Sibling gets bigger portion or more attention",
        "category": "Anger & Frustration",
        "coreNeed": "Self-Worth",
        "falseBelief": "Someone else's success makes me less important.",
        "trueBelief": "Everyone has their own gifts and my worth doesn't depend on comparison.",
        "feeling": "A sting of unfairness — feeling smaller and less important than a sibling.",
        "parentTeach": "That love isn't measured in portions, and being loved doesn't mean being equal.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Helping & Caring",
          "Responsibility",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 5,
        "slug": "can-t-finish-homework-or-a-craft",
        "name": "Can't finish homework or a craft",
        "category": "Anger & Frustration",
        "coreNeed": "Perseverance",
        "falseBelief": "If I can't do it quickly, I can't do it.",
        "trueBelief": "Every attempt helps me improve.",
        "feeling": "Rising frustration at their own hands not doing what their mind wants.",
        "parentTeach": "That struggling is part of learning, not proof they're bad at it.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Building & Creating",
          "Art",
          "Music & Creativity"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 6,
        "slug": "playdate-or-plan-suddenly-cancelled",
        "name": "Playdate or plan suddenly cancelled",
        "category": "Anger & Frustration",
        "coreNeed": "Flexibility",
        "falseBelief": "Plans must happen my way.",
        "trueBelief": "I can adapt and still enjoy life.",
        "feeling": "Sharp disappointment — an exciting plan just disappeared.",
        "parentTeach": "That plans can change and disappointment can be survived without spoiling everything.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Friendship & Sharing",
          "Playing & Games",
          "Family & Daily Life"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 7,
        "slug": "someone-breaks-their-lego-or-drawing",
        "name": "Someone breaks their Lego or drawing",
        "category": "Anger & Frustration",
        "coreNeed": "Self-Control",
        "falseBelief": "My anger should decide what I do.",
        "trueBelief": "I can choose calm actions even when I'm upset.",
        "feeling": "A wave of anger at seeing something they made get destroyed.",
        "parentTeach": "That things can be rebuilt, and their effort still counted even if it broke.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Building & Creating",
          "Communication",
          "Friendship & Sharing"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 8,
        "slug": "being-hurried-to-put-shoes-on-or-leave",
        "name": "Being hurried to put shoes on or leave",
        "category": "Anger & Frustration",
        "coreNeed": "Patience",
        "falseBelief": "Everything has to happen right now.",
        "trueBelief": "I can slow down and work with the moment I'm in.",
        "feeling": "Irritable resistance to being hurried when they weren't ready.",
        "parentTeach": "That slowing down sometimes isn't possible, but their pace still matters.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Modak",
        "lifeDomains": [
          "Family & Daily Life",
          "Responsibility",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 9,
        "slug": "feeling-hungry-or-extremely-tired-hangry",
        "name": "Feeling hungry or extremely tired (hangry)",
        "category": "Anger & Frustration",
        "coreNeed": "Comfort",
        "falseBelief": "I can't cope when my body feels uncomfortable.",
        "trueBelief": "I can care for my body and uncomfortable moments will pass.",
        "feeling": "Short-fused crankiness that isn't really about what just happened.",
        "parentTeach": "That big feelings are sometimes just a full tummy or tired body in disguise.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Family & Daily Life",
          "Helping & Caring"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 10,
        "slug": "blamed-for-something-they-didn-t-do",
        "name": "Blamed for something they didn't do",
        "category": "Anger & Frustration",
        "coreNeed": "Fairness",
        "falseBelief": "Being blamed means nobody believes me.",
        "trueBelief": "I can respond honestly and calmly, even when things feel unfair.",
        "feeling": "Indignation at being punished for something they didn't do.",
        "parentTeach": "That being falsely blamed hurts, and it's safe to say so calmly.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Communication",
          "Responsibility",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 11,
        "slug": "being-teased-or-physically-pushed",
        "name": "Being teased or physically pushed",
        "category": "Anger & Frustration",
        "coreNeed": "Self-Control",
        "falseBelief": "If someone hurts me, I should hurt them back.",
        "trueBelief": "I can protect myself without losing control.",
        "feeling": "Fear tangled with anger — wanting to hit back or hide.",
        "parentTeach": "That standing tall doesn't require becoming what hurt them.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Playing & Games"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 12,
        "slug": "no-say-in-what-to-wear-or-eat",
        "name": "No say in what to wear or eat",
        "category": "Anger & Frustration",
        "coreNeed": "Independence",
        "falseBelief": "I should always get to decide everything.",
        "trueBelief": "I can cooperate even when I don't get my way.",
        "feeling": "Frustration at having no vote in small everyday decisions.",
        "parentTeach": "That a little choice, even in small things, builds real self-trust.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 13,
        "slug": "adult-doesn-t-understand-what-they-mean",
        "name": "Adult doesn't understand what they mean",
        "category": "Anger & Frustration",
        "coreNeed": "Acceptance",
        "falseBelief": "If people don't understand me, something is wrong with me.",
        "trueBelief": "I can express myself patiently and be myself.",
        "feeling": "Helpless irritation at not being understood, even while trying to explain.",
        "parentTeach": "That being patient while explaining again is its own kind of strength.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Communication",
          "Helping & Caring",
          "Family & Daily Life"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 14,
        "slug": "game-crashes-or-internet-lags-during-a-win",
        "name": "Game crashes or internet lags during a win",
        "category": "Anger & Frustration",
        "coreNeed": "Resilience",
        "falseBelief": "One setback ruins everything.",
        "trueBelief": "I can begin again after setbacks.",
        "feeling": "Sharp letdown when a win gets erased by something out of their control.",
        "parentTeach": "That effort still counts even when the outcome gets taken away.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Playing & Games",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 15,
        "slug": "forced-to-sit-still-too-long-car-flight",
        "name": "Forced to sit still too long (car, flight)",
        "category": "Anger & Frustration",
        "coreNeed": "Self-Control",
        "falseBelief": "I can't stay calm when I feel trapped.",
        "trueBelief": "I can find peaceful ways to handle uncomfortable moments.",
        "feeling": "Restless, fidgety irritation at a body that wants to move.",
        "parentTeach": "That stillness is a skill that grows, not a switch that flips.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Family & Daily Life",
          "Playing & Games",
          "Art",
          "Music & Creativity"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 16,
        "slug": "game-save-file-corrupted-or-deleted",
        "name": "Game save file corrupted or deleted",
        "category": "Anger & Frustration",
        "coreNeed": "Resilience",
        "falseBelief": "Losing my progress means I've failed.",
        "trueBelief": "I can rebuild and keep moving forward.",
        "feeling": "Grief-tinged anger at losing hours of effort in an instant.",
        "parentTeach": "That things we build can be rebuilt, and the loss still deserves comfort.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Playing & Games",
          "Building & Creating"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 17,
        "slug": "a-treat-or-promise-was-forgotten",
        "name": "A treat or promise was forgotten",
        "category": "Anger & Frustration",
        "coreNeed": "Trust",
        "falseBelief": "Broken promises mean people don't care about me.",
        "trueBelief": "Trust grows through honesty, reliability and understanding.",
        "feeling": "Betrayal-flavored disappointment when a promised treat quietly vanishes.",
        "parentTeach": "That promises matter, and it's fair to remind grown-ups gently when one slips.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 18,
        "slug": "sibling-tells-on-them-unfairly",
        "name": "Sibling tells on them unfairly",
        "category": "Anger & Frustration",
        "coreNeed": "Fairness",
        "falseBelief": "I have to get even when something feels unfair.",
        "trueBelief": "I can respond with honesty instead of revenge.",
        "feeling": "Anger at being reported on, especially if it feels exaggerated.",
        "parentTeach": "That tattling and telling are different, and both siblings deserve fairness.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Friendship & Sharing"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 19,
        "slug": "scratchy-clothes-or-irritating-noise",
        "name": "Scratchy clothes or irritating noise",
        "category": "Anger & Frustration",
        "coreNeed": "Comfort",
        "falseBelief": "I can't be okay when things feel uncomfortable.",
        "trueBelief": "I can stay peaceful even when my surroundings aren't perfect.",
        "feeling": "Irritable discomfort that has nothing to do with anyone's behavior.",
        "parentTeach": "That bodies have limits too, and naming discomfort isn't complaining.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 20,
        "slug": "repeatedly-failing-a-level-or-concept",
        "name": "Repeatedly failing a level or concept",
        "category": "Anger & Frustration",
        "coreNeed": "Perseverance",
        "falseBelief": "If I keep failing, I should quit.",
        "trueBelief": "Every challenge helps me become stronger.",
        "feeling": "Mounting frustration at hitting the same wall again and again.",
        "parentTeach": "That repetition isn't failure — it's how mastery actually happens.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Playing & Games",
          "Building & Creating"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 21,
        "slug": "darkness-or-shadows-in-the-room",
        "name": "Darkness or shadows in the room",
        "category": "Fear & Insecurity",
        "coreNeed": "Courage",
        "falseBelief": "Fear means I should stop.",
        "trueBelief": "Courage is taking one small brave step.",
        "feeling": "A prickle of dread when the room turns unfamiliar in the dark.",
        "parentTeach": "That the dark hides nothing new, just what daylight already showed.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Exploring & Nature",
          "Family & Daily Life",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 22,
        "slug": "thunder-fireworks-or-loud-sirens",
        "name": "Thunder, fireworks, or loud sirens",
        "category": "Fear & Insecurity",
        "coreNeed": "Security",
        "falseBelief": "Loud or unexpected things mean I'm not safe.",
        "trueBelief": "I can find safety, calm and support.",
        "feeling": "A full-body startle at a sound too loud to predict.",
        "parentTeach": "That loud sounds pass, and their body can learn to settle after the jolt.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Exploring & Nature",
          "Family & Daily Life",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 23,
        "slug": "monsters-under-the-bed-or-scary-stories",
        "name": "Monsters under the bed or scary stories",
        "category": "Fear & Insecurity",
        "coreNeed": "Courage",
        "falseBelief": "My imagination can control me.",
        "trueBelief": "I can be braver than my fears.",
        "feeling": "Vivid, sticky fear from an imagined creature that feels very real.",
        "parentTeach": "That imagination can also invent safety, not just monsters.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Art",
          "Music & Creativity",
          "Family & Daily Life",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 24,
        "slug": "parent-leaving-for-work-or-a-long-trip",
        "name": "Parent leaving for work or a long trip",
        "category": "Fear & Insecurity",
        "coreNeed": "Trust",
        "falseBelief": "When someone leaves, they might not come back.",
        "trueBelief": "I can trust the people who love and care for me.",
        "feeling": "A tight knot of worry that the goodbye might be a forever one.",
        "parentTeach": "That leaving and returning are part of the same promise, kept every time.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Helping & Caring"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 25,
        "slug": "fear-of-going-on-stage-or-presenting",
        "name": "Fear of going on stage or presenting",
        "category": "Fear & Insecurity",
        "coreNeed": "Confidence",
        "falseBelief": "If I'm nervous, I can't do it.",
        "trueBelief": "Confidence grows each time I try.",
        "feeling": "Stomach-churning stage fright — every eye suddenly too much.",
        "parentTeach": "That shaky knees and a steady voice can exist in the same moment.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Art",
          "Music & Creativity",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 26,
        "slug": "anxiety-before-a-big-test-or-result",
        "name": "Anxiety before a big test or result",
        "category": "Fear & Insecurity",
        "coreNeed": "Confidence",
        "falseBelief": "If I don't do well, I'm not good enough.",
        "trueBelief": "My effort and learning matter more than perfect results.",
        "feeling": "Anticipatory dread that builds for days before the actual test.",
        "parentTeach": "That preparation is protection, and one result doesn't define their worth.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Responsibility",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 27,
        "slug": "injections-doctors-or-dentist-visits",
        "name": "Injections, doctors, or dentist visits",
        "category": "Fear & Insecurity",
        "coreNeed": "Courage",
        "falseBelief": "If something hurts, I can't handle it.",
        "trueBelief": "I am stronger than I think, even during difficult moments.",
        "feeling": "Sharp anxiety about pain that hasn't even happened yet.",
        "parentTeach": "That brief discomfort can be survived, and asking for comfort is allowed.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Helping & Caring",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 28,
        "slug": "new-teacher-or-unfamiliar-adult",
        "name": "New teacher or unfamiliar adult",
        "category": "Fear & Insecurity",
        "coreNeed": "Trust",
        "falseBelief": "New people won't understand or help me.",
        "trueBelief": "Trust grows one step at a time.",
        "feeling": "Wary uncertainty around someone new whose intentions aren't known yet.",
        "parentTeach": "That caution is wise, and warming up slowly is not the same as rudeness.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "School & Community",
          "Communication",
          "Friendship & Sharing"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 29,
        "slug": "fear-of-getting-lost-in-a-mall-or-crowd",
        "name": "Fear of getting lost in a mall or crowd",
        "category": "Fear & Insecurity",
        "coreNeed": "Security",
        "falseBelief": "If I'm alone, I'm not safe.",
        "trueBelief": "I can stay calm, make wise choices and find help.",
        "feeling": "Panic at the thought of a familiar hand suddenly not being there.",
        "parentTeach": "That a plan for 'what if we get separated' turns fear into readiness.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Exploring & Nature",
          "Communication",
          "Helping & Caring"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 30,
        "slug": "accidentally-saw-a-scary-or-violent-video",
        "name": "Accidentally saw a scary or violent video",
        "category": "Fear & Insecurity",
        "coreNeed": "Security",
        "falseBelief": "The scary things I see will happen to me.",
        "trueBelief": "I can separate imagination from reality and seek comfort.",
        "feeling": "Intrusive, unsettling images that won't easily leave their mind.",
        "parentTeach": "That not everything seen online is meant for their eyes, and that's okay to say.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Art",
          "Music & Creativity"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 31,
        "slug": "heard-about-war-or-violence-on-news",
        "name": "Heard about war or violence on news",
        "category": "Fear & Insecurity",
        "coreNeed": "Security",
        "falseBelief": "The world is always dangerous.",
        "trueBelief": "There are many people working every day to keep others safe.",
        "feeling": "Heavy, adult-sized dread about something too big to fully picture.",
        "parentTeach": "That caring adults are working on big problems, and their job is just to be a kid.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Helping & Caring"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 32,
        "slug": "saw-news-about-floods-fires-earthquakes",
        "name": "Saw news about floods, fires, earthquakes",
        "category": "Fear & Insecurity",
        "coreNeed": "Hope",
        "falseBelief": "Bad things mean everything is ruined forever.",
        "trueBelief": "People can help, rebuild and begin again.",
        "feeling": "Overwhelm at scenes of destruction that feel close even from far away.",
        "parentTeach": "That most places, most days, are safe — and helpers exist for the hard days.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Exploring & Nature",
          "Helping & Caring",
          "Learning & Problem Solving"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 33,
        "slug": "fear-that-a-parent-might-get-sick",
        "name": "Fear that a parent might get sick",
        "category": "Fear & Insecurity",
        "coreNeed": "Trust",
        "falseBelief": "I might lose the people I love.",
        "trueBelief": "Love, care and support help us through uncertain times.",
        "feeling": "Quiet, private fear they might be carrying alone.",
        "parentTeach": "That saying a fear out loud to a trusted adult makes it smaller, not bigger.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Helping & Caring",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 34,
        "slug": "overheard-adults-talking-about-money-problems",
        "name": "Overheard adults talking about money problems",
        "category": "Fear & Insecurity",
        "coreNeed": "Security",
        "falseBelief": "We won't be okay if money is tight.",
        "trueBelief": "Families work together and find solutions during hard times.",
        "feeling": "A confusing unease absorbed from grown-up conversations not meant for them.",
        "parentTeach": "That money worries are a grown-up job, and they are still fully provided for.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 35,
        "slug": "overthinking-imaginary-future-dangers",
        "name": "Overthinking imaginary future dangers",
        "category": "Fear & Insecurity",
        "coreNeed": "Calm",
        "falseBelief": "I have to believe every scary thought.",
        "trueBelief": "Thoughts are not always facts, and I can return to the present.",
        "feeling": "Spiraling worry about things that haven't happened and may never.",
        "parentTeach": "That imagined futures aren't facts, and today is the only place to stand.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Art",
          "Music & Creativity",
          "Learning & Problem Solving",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 36,
        "slug": "fear-of-being-laughed-at-by-class",
        "name": "Fear of being laughed at by class",
        "category": "Fear & Insecurity",
        "coreNeed": "Self-Worth",
        "falseBelief": "If others laugh at me, I don't matter.",
        "trueBelief": "My value isn't decided by other people's opinions.",
        "feeling": "Sharp social dread — imagining every eye and every laugh.",
        "parentTeach": "That embarrassment fades fast, faster than it feels in the moment.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "School & Community",
          "Communication",
          "Friendship & Sharing"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 37,
        "slug": "first-day-at-a-new-school",
        "name": "First day at a new school",
        "category": "Fear & Insecurity",
        "coreNeed": "Belonging",
        "falseBelief": "I won't fit in here.",
        "trueBelief": "I can make connections while being myself.",
        "feeling": "Nervous unfamiliarity about a place with no known faces yet.",
        "parentTeach": "That every friend was once a stranger, and the first day is just the start.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "School & Community",
          "Friendship & Sharing",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 38,
        "slug": "fear-of-dogs-spiders-or-insects",
        "name": "Fear of dogs, spiders, or insects",
        "category": "Fear & Insecurity",
        "coreNeed": "Courage",
        "falseBelief": "Fear means I should avoid everything unfamiliar.",
        "trueBelief": "I can learn, stay safe and become braver step by step.",
        "feeling": "Instinctive alarm at something small, fast, or many-legged.",
        "parentTeach": "That fear can be respected without needing to run the whole show.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "Exploring & Nature",
          "Helping & Caring",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 39,
        "slug": "fear-of-falling-or-getting-hurt-at-park",
        "name": "Fear of falling or getting hurt at park",
        "category": "Fear & Insecurity",
        "coreNeed": "Confidence",
        "falseBelief": "If I fall once, I shouldn't try again.",
        "trueBelief": "Trying again helps me grow stronger and more confident.",
        "feeling": "Wary caution about a body that sometimes surprises them.",
        "parentTeach": "That falling is part of moving, and their body knows more than fear admits.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Playing & Games",
          "Learning & Problem Solving",
          "Helping & Caring"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 40,
        "slug": "fear-of-getting-in-trouble-with-teacher",
        "name": "Fear of getting in trouble with teacher",
        "category": "Fear & Insecurity",
        "coreNeed": "Integrity",
        "falseBelief": "Making mistakes makes me a bad child.",
        "trueBelief": "Honesty and responsibility are more important than being perfect.",
        "feeling": "Anxious dread about disappointing someone with authority.",
        "parentTeach": "That mistakes and consequences are both survivable, and trust can hold through both.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "School & Community",
          "Responsibility",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 41,
        "slug": "anxiety-about-the-earth-breaking-climate-change",
        "name": "Anxiety about the earth breaking (climate change)",
        "category": "Fear & Insecurity",
        "coreNeed": "Hope",
        "falseBelief": "Nothing I do can make a difference.",
        "trueBelief": "Small caring actions can help create a better future.",
        "feeling": "Diffuse, grown-up-scaled anxiety about a world too large to control.",
        "parentTeach": "That small daily actions matter, and worry doesn't have to carry the whole planet.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Exploring & Nature",
          "Helping & Caring",
          "Learning & Problem Solving"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 42,
        "slug": "friend-is-not-playing-with-them-today",
        "name": "Friend is not playing with them today",
        "category": "Sadness & Grief",
        "coreNeed": "Belonging",
        "falseBelief": "If my friend chooses someone else, I'm not important.",
        "trueBelief": "Friendships can grow even when people spend time with others.",
        "feeling": "A quiet ache of being left out of today's fun.",
        "parentTeach": "That one day of distance doesn't undo a friendship.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Playing & Games"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 43,
        "slug": "death-of-a-pet",
        "name": "Death of a pet",
        "category": "Sadness & Grief",
        "coreNeed": "Compassion",
        "falseBelief": "Love disappears when someone is gone.",
        "trueBelief": "Love stays with us through our memories and kindness.",
        "feeling": "Deep, unfiltered grief for a companion who won't come back.",
        "parentTeach": "That loving something means grieving it fully, and grief is love with nowhere to go yet.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Helping & Caring",
          "Family & Daily Life",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 44,
        "slug": "death-of-a-relative-or-family-member",
        "name": "Death of a relative or family member",
        "category": "Sadness & Grief",
        "coreNeed": "Hope",
        "falseBelief": "Life will never feel happy again.",
        "trueBelief": "Love continues through memories, family and hope.",
        "feeling": "Heavy, disorienting sadness around a loss too big for words.",
        "parentTeach": "That missing someone forever is the price and the proof of having loved them.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Helping & Caring"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 45,
        "slug": "lost-a-favourite-toy-or-comfort-blanket",
        "name": "Lost a favourite toy or comfort blanket",
        "category": "Sadness & Grief",
        "coreNeed": "Comfort",
        "falseBelief": "I can't be okay without this special thing.",
        "trueBelief": "The love and comfort I feel live inside me too.",
        "feeling": "Sharp grief over something small to others but precious to them.",
        "parentTeach": "That objects can be mourned too, and new comfort can still be found.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Exploring & Nature",
          "Learning & Problem Solving",
          "Family & Daily Life"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 46,
        "slug": "harshly-reprimanded-by-a-parent",
        "name": "Harshly reprimanded by a parent",
        "category": "Sadness & Grief",
        "coreNeed": "Acceptance",
        "falseBelief": "When I make mistakes, I'm not loved.",
        "trueBelief": "I can make mistakes and still be deeply loved.",
        "feeling": "Stinging shame layered under sadness after being scolded hard.",
        "parentTeach": "That correction and love can coexist, even when a voice was raised.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 47,
        "slug": "feeling-invisible-to-a-busy-parent",
        "name": "Feeling invisible to a busy parent",
        "category": "Sadness & Grief",
        "coreNeed": "Belonging",
        "falseBelief": "I'm not important because nobody notices me.",
        "trueBelief": "I matter even when people are busy.",
        "feeling": "A lonely ache of not being noticed, even in a full house.",
        "parentTeach": "That being busy isn't the same as not caring, and both can be true.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Family & Daily Life",
          "Helping & Caring",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 48,
        "slug": "not-invited-to-a-birthday-party",
        "name": "Not invited to a birthday party",
        "category": "Sadness & Grief",
        "coreNeed": "Belonging",
        "falseBelief": "Being left out means nobody likes me.",
        "trueBelief": "One invitation does not decide my worth or my friendships.",
        "feeling": "Sharp exclusion — wondering what made them not good enough to invite.",
        "parentTeach": "That not every gathering includes everyone, and that isn't a verdict on their worth.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Friendship & Sharing",
          "Celebrations & Traditions",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 49,
        "slug": "a-fall-or-scrape-the-shock-of-pain",
        "name": "A fall or scrape — the shock of pain",
        "category": "Sadness & Grief",
        "coreNeed": "Resilience",
        "falseBelief": "Getting hurt means I should stop trying.",
        "trueBelief": "I can heal, recover and keep growing.",
        "feeling": "Shock and sting that arrive together in the first seconds of pain.",
        "parentTeach": "That comfort matters as much as the injury, and both deserve attention.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Helping & Caring",
          "Playing & Games",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 50,
        "slug": "missing-a-parent-who-travels-often",
        "name": "Missing a parent who travels often",
        "category": "Sadness & Grief",
        "coreNeed": "Trust",
        "falseBelief": "Distance means love becomes smaller.",
        "trueBelief": "Love stays strong even when people are far away.",
        "feeling": "A steady undercurrent of missing someone who's often away.",
        "parentTeach": "That distance doesn't shrink love, and counting days can make waiting easier.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Art",
          "Music & Creativity"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 51,
        "slug": "close-friend-moved-to-another-city",
        "name": "Close friend moved to another city",
        "category": "Sadness & Grief",
        "coreNeed": "Belonging",
        "falseBelief": "If someone leaves, our friendship is over.",
        "trueBelief": "Real friendships can continue across distance and time.",
        "feeling": "Grief for a friendship that now has geography in the way.",
        "parentTeach": "That friendships can stretch across distance, even if they change shape.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Art",
          "Music & Creativity"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 52,
        "slug": "moving-house-and-leaving-familiar-bedroom",
        "name": "Moving house and leaving familiar bedroom",
        "category": "Sadness & Grief",
        "coreNeed": "Security",
        "falseBelief": "Everything familiar is gone forever.",
        "trueBelief": "Home is built through love, memories and new beginnings.",
        "feeling": "Disoriented sadness at losing the small, familiar details of home.",
        "parentTeach": "That a new room can become familiar too, in its own time.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Building & Creating",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 53,
        "slug": "long-illness-lockdown-recovery-school-break",
        "name": "Long illness, lockdown recovery, school break",
        "category": "Sadness & Grief",
        "coreNeed": "Resilience",
        "falseBelief": "Life will never feel normal again.",
        "trueBelief": "I can adapt and create new routines after change.",
        "feeling": "Fatigue-laced sadness from days that all started to blur together.",
        "parentTeach": "That slow recovery is still progress, even without visible milestones.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Family & Daily Life",
          "Playing & Games",
          "Friendship & Sharing"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 54,
        "slug": "highly-anticipated-movie-or-event-cancelled",
        "name": "Highly anticipated movie or event cancelled",
        "category": "Sadness & Grief",
        "coreNeed": "Flexibility",
        "falseBelief": "If plans change, everything is ruined.",
        "trueBelief": "New opportunities can grow from unexpected changes.",
        "feeling": "Sharp letdown when eager anticipation meets sudden cancellation.",
        "parentTeach": "That disappointment is proportional to how much they cared, and that's not silly.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Art",
          "Music & Creativity",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 55,
        "slug": "seeing-another-child-or-animal-cry-or-suffer",
        "name": "Seeing another child or animal cry or suffer",
        "category": "Sadness & Grief",
        "coreNeed": "Compassion",
        "falseBelief": "Their pain has nothing to do with me.",
        "trueBelief": "Caring actions can comfort others and make a difference.",
        "feeling": "Tender sadness on behalf of someone else's pain.",
        "parentTeach": "That noticing others' pain is a sign of a caring heart, not a burden.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Helping & Caring",
          "Communication",
          "Friendship & Sharing"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 56,
        "slug": "excluded-from-a-group-chat",
        "name": "Excluded from a group chat",
        "category": "Sadness & Grief",
        "coreNeed": "Belonging",
        "falseBelief": "Being left out means I don't matter.",
        "trueBelief": "One group doesn't decide my value or my friendships.",
        "feeling": "Modern exclusion — watching a conversation happen without them.",
        "parentTeach": "That being left off one thread doesn't mean being left out of the friendship.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "School & Community"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 57,
        "slug": "not-chosen-for-a-special-school-role",
        "name": "Not chosen for a special school role",
        "category": "Sadness & Grief",
        "coreNeed": "Self-Worth",
        "falseBelief": "If I'm not chosen, I'm not good enough.",
        "trueBelief": "My worth isn't decided by awards or roles.",
        "feeling": "Quiet disappointment at being passed over for something they wanted.",
        "parentTeach": "That not being chosen this time isn't a measure of their value.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "School & Community",
          "Learning & Problem Solving",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 58,
        "slug": "last-day-of-summer-vacation-school-year-end",
        "name": "Last day of summer vacation / school year end",
        "category": "Sadness & Grief",
        "coreNeed": "Hope",
        "falseBelief": "Good things are over forever.",
        "trueBelief": "Every ending also brings a new beginning.",
        "feeling": "Bittersweet sadness at something good coming to a close.",
        "parentTeach": "That endings can be grieved and next things can still be looked forward to.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "Friendship & Sharing",
          "Celebrations & Traditions",
          "Family & Daily Life"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 59,
        "slug": "looking-at-photos-when-they-were-little",
        "name": "Looking at photos when they were 'little'",
        "category": "Sadness & Grief",
        "coreNeed": "Acceptance",
        "falseBelief": "I've lost who I used to be.",
        "trueBelief": "Growing changes me, but I'm still me inside.",
        "feeling": "Wistful longing for a smaller, simpler version of themselves.",
        "parentTeach": "That growing up doesn't erase who they were — it adds to it.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Art",
          "Music & Creativity",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 60,
        "slug": "intentions-were-good-but-they-got-in-trouble-anyway",
        "name": "Intentions were good but they got in trouble anyway",
        "category": "Sadness & Grief",
        "coreNeed": "Integrity",
        "falseBelief": "Good intentions don't matter if I make mistakes.",
        "trueBelief": "Honest intentions and taking responsibility both matter.",
        "feeling": "Confused hurt at being punished despite meaning well.",
        "parentTeach": "That intentions matter, and it's fair to explain them calmly, even after trouble.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Responsibility",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 61,
        "slug": "made-a-mistake-in-front-of-the-class",
        "name": "Made a mistake in front of the class",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Confidence",
        "falseBelief": "One mistake means I'm not capable.",
        "trueBelief": "Mistakes are part of learning and growing.",
        "feeling": "Hot, exposed embarrassment with every eye suddenly on them.",
        "parentTeach": "That mistakes in public are still just mistakes, not verdicts.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "School & Community",
          "Learning & Problem Solving",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 62,
        "slug": "forgot-someone-s-name-or-a-social-cue",
        "name": "Forgot someone's name or a social cue",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Respect",
        "falseBelief": "If I forget, people won't like me.",
        "trueBelief": "Everyone makes mistakes, and kindness repairs them.",
        "feeling": "A flush of awkwardness at a small social slip.",
        "parentTeach": "That everyone forgets and fumbles sometimes — it's not a character flaw.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Communication",
          "Friendship & Sharing",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 63,
        "slug": "called-fat-or-chubby-by-a-peer",
        "name": "Called 'fat' or 'chubby' by a peer",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Self-Worth",
        "falseBelief": "My appearance decides my value.",
        "trueBelief": "My worth comes from who I am, not how I look.",
        "feeling": "Wounded hurt at being labeled by their body.",
        "parentTeach": "That bodies come in every shape, and none of them need permission to take up space.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Playing & Games"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 64,
        "slug": "new-glasses-and-feeling-nerdy-or-ugly",
        "name": "New glasses and feeling 'nerdy' or 'ugly'",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Acceptance",
        "falseBelief": "Looking different makes me less lovable.",
        "trueBelief": "The things that make me different are part of who I am.",
        "feeling": "Self-conscious unease about looking different overnight.",
        "parentTeach": "That how they see feels the same, even if how they look has changed.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "School & Community",
          "Communication",
          "Friendship & Sharing"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 65,
        "slug": "getting-acne-or-pimples-older-kids",
        "name": "Getting acne or pimples (older kids)",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Acceptance",
        "falseBelief": "I have to look perfect to be accepted.",
        "trueBelief": "My appearance doesn't define my value.",
        "feeling": "New, unfamiliar embarrassment about their changing skin.",
        "parentTeach": "That bodies change on their own timeline, and it says nothing about their worth.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 66,
        "slug": "being-shortest-or-tallest-in-the-class-line",
        "name": "Being shortest or tallest in the class line",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Self-Worth",
        "falseBelief": "Being different makes me less important.",
        "trueBelief": "Everyone grows in their own unique way.",
        "feeling": "Awareness of standing out physically in a lineup of peers.",
        "parentTeach": "That height is just a number, not a ranking of anything that matters.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "School & Community",
          "Playing & Games",
          "Friendship & Sharing"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 67,
        "slug": "being-slower-at-reading-or-math-than-others",
        "name": "Being 'slower' at reading or math than others",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Confidence",
        "falseBelief": "If I learn slowly, I'm not smart.",
        "trueBelief": "Everyone learns at their own pace.",
        "feeling": "Quiet shame at needing more time than classmates to learn something.",
        "parentTeach": "That everyone's brain has its own pace, and pace isn't proof of ability.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Learning & Problem Solving",
          "School & Community",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 68,
        "slug": "picked-last-for-a-team-or-called-clumsy",
        "name": "Picked last for a team or called 'clumsy'",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Confidence",
        "falseBelief": "I'm not good enough to belong.",
        "trueBelief": "Skills improve with practice and effort.",
        "feeling": "Sting of being ranked last, publicly, by peers.",
        "parentTeach": "That being picked last for one game says nothing about their overall worth.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Playing & Games",
          "School & Community",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 69,
        "slug": "their-clothes-aren-t-as-cool-as-others",
        "name": "Their clothes aren't as 'cool' as others'",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Contentment",
        "falseBelief": "I need nicer things to be accepted.",
        "trueBelief": "Who I am matters more than what I own.",
        "feeling": "Self-conscious comparison of their clothes against everyone else's.",
        "parentTeach": "That style is self-expression, not a scoreboard to win.",
        "wisdomElement": "Modak",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Art",
          "Music & Creativity"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 70,
        "slug": "thinking-i-can-t-do-anything-right",
        "name": "Thinking 'I can't do anything right'",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Confidence",
        "falseBelief": "I fail at everything.",
        "trueBelief": "I have many strengths and can keep improving.",
        "feeling": "A harsh inner voice repeating 'I can't.'",
        "parentTeach": "That the inner voice can be gentler than it currently is, and that's a skill to build.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Building & Creating",
          "Helping & Caring"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 71,
        "slug": "sibling-praised-while-they-were-ignored",
        "name": "Sibling praised while they were ignored",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Self-Worth",
        "falseBelief": "Love has to be earned by being the best.",
        "trueBelief": "I am loved for who I am, not because I outperform others.",
        "feeling": "Quiet hurt at being overlooked while a sibling is celebrated.",
        "parentTeach": "That praise for one child doesn't subtract from another's worth.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Helping & Caring",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 72,
        "slug": "project-or-video-gets-no-likes-or-views",
        "name": "Project or video gets no likes or views",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Self-Worth",
        "falseBelief": "If people don't notice me, I don't matter.",
        "trueBelief": "My work has value even without applause.",
        "feeling": "New-world sting of public performance with a visible scorecard.",
        "parentTeach": "That worth was never meant to be counted in likes.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Art",
          "Music & Creativity",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 73,
        "slug": "drawing-doesn-t-look-how-they-imagined",
        "name": "Drawing doesn't look how they imagined",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Perseverance",
        "falseBelief": "If it isn't perfect, I should stop.",
        "trueBelief": "Improvement comes through practice, not perfection.",
        "feeling": "Frustrated disappointment when the hand can't match the imagination yet.",
        "parentTeach": "That the gap between vision and skill is where all artists live, and it closes with practice.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Art",
          "Music & Creativity",
          "Learning & Problem Solving",
          "Building & Creating"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 74,
        "slug": "reprimanded-in-front-of-friends-or-guests",
        "name": "Reprimanded in front of friends or guests",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Acceptance",
        "falseBelief": "Public mistakes make me less worthy.",
        "trueBelief": "One embarrassing moment doesn't change my worth.",
        "feeling": "Doubled embarrassment — being corrected and watched at the same time.",
        "parentTeach": "That being corrected in front of others still doesn't make them any less loved.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Communication",
          "Family & Daily Life",
          "School & Community"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 75,
        "slug": "stuttered-or-forgot-lines-in-a-play",
        "name": "Stuttered or forgot lines in a play",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Confidence",
        "falseBelief": "If I mess up, everyone will remember forever.",
        "trueBelief": "Courage is continuing even after mistakes.",
        "feeling": "Panic-laced embarrassment at forgetting words in front of everyone.",
        "parentTeach": "That forgetting a line isn't the same as failing — recovering it is the real skill.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Art",
          "Music & Creativity",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 76,
        "slug": "told-their-work-is-messy-or-unreadable",
        "name": "Told their work is 'messy' or unreadable",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Confidence",
        "falseBelief": "If my work isn't perfect, I'm not capable.",
        "trueBelief": "Skills improve with practice and feedback.",
        "feeling": "Quiet shame about work that feels judged as sloppy.",
        "parentTeach": "That neat and good are different things, and effort shows in more than tidiness.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Art",
          "Music & Creativity",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 77,
        "slug": "why-can-t-you-be-more-like-cousin-friend",
        "name": "Why can't you be more like [cousin/friend]?",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Self-Worth",
        "falseBelief": "I have to be like someone else to be valued.",
        "trueBelief": "My unique strengths make me valuable.",
        "feeling": "The ache of being held up against someone else, and coming up short.",
        "parentTeach": "That comparisons say more about the comparer than the child being measured.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 78,
        "slug": "feeling-like-a-burden-to-parents",
        "name": "Feeling like a burden to parents",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Acceptance",
        "falseBelief": "I make life harder for everyone.",
        "trueBelief": "I am loved because I am part of the family, not because I'm perfect.",
        "feeling": "A heavy, private worry that they cost more than they give.",
        "parentTeach": "That children are never a burden — needing care is what childhood is for.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Helping & Caring"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 79,
        "slug": "feeling-like-they-re-not-seen-or-valued",
        "name": "Feeling like they're not seen or valued",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Belonging",
        "falseBelief": "Nobody notices or values me.",
        "trueBelief": "I matter even when others are busy or distracted.",
        "feeling": "A lonely feeling of going unnoticed even while present.",
        "parentTeach": "That being quiet doesn't mean being unimportant, and quiet needs can be spoken.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Communication",
          "Family & Daily Life",
          "Friendship & Sharing"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 80,
        "slug": "secretly-thinking-i-am-just-a-bad-kid",
        "name": "Secretly thinking 'I am just a bad kid'",
        "category": "Shame & Low Self-Esteem",
        "coreNeed": "Acceptance",
        "falseBelief": "I am a bad person because I make mistakes.",
        "trueBelief": "I make mistakes, but I am still a good person who can grow.",
        "feeling": "A frightening, secret belief that they are fundamentally bad.",
        "parentTeach": "That behavior and identity are different — a hard moment doesn't make a hard heart.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Responsibility",
          "Family & Daily Life",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 81,
        "slug": "parent-praises-sibling-s-work-but-not-theirs",
        "name": "Parent praises sibling's work but not theirs",
        "category": "Jealousy & Envy",
        "coreNeed": "Self-Worth",
        "falseBelief": "Praise decides my value.",
        "trueBelief": "My worth isn't measured by comparison or praise.",
        "feeling": "A pang of hurt watching praise go somewhere else.",
        "parentTeach": "That there's enough praise to go around, even if it doesn't always feel that way.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Helping & Caring",
          "Responsibility",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 82,
        "slug": "best-friend-is-playing-with-someone-else",
        "name": "Best friend is playing with someone else",
        "category": "Jealousy & Envy",
        "coreNeed": "Belonging",
        "falseBelief": "I'll be replaced.",
        "trueBelief": "Friendships grow and there's room for many connections.",
        "feeling": "The ache of being replaced, even temporarily, by someone else's company.",
        "parentTeach": "That friendships can include more than one person without anyone losing their place.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Playing & Games"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 83,
        "slug": "friend-got-the-newest-toy-phone-or-ipad",
        "name": "Friend got the newest toy, phone or iPad",
        "category": "Jealousy & Envy",
        "coreNeed": "Contentment",
        "falseBelief": "I need what others have to be happy.",
        "trueBelief": "Gratitude brings more joy than comparison.",
        "feeling": "Sharp wanting at seeing someone else get the newer, shinier thing.",
        "parentTeach": "That having less right now doesn't mean having less worth.",
        "wisdomElement": "Modak",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Friendship & Sharing",
          "Family & Daily Life",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 84,
        "slug": "classmate-won-student-of-the-month",
        "name": "Classmate won Student of the Month",
        "category": "Jealousy & Envy",
        "coreNeed": "Self-Worth",
        "falseBelief": "Someone else's success means I'm not successful.",
        "trueBelief": "I can celebrate others while continuing my own journey.",
        "feeling": "Competitive sting at someone else's recognition.",
        "parentTeach": "That someone else's win doesn't take anything away from their own effort.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Modak",
        "lifeDomains": [
          "School & Community",
          "Learning & Problem Solving",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 85,
        "slug": "someone-else-always-gets-to-go-first",
        "name": "Someone else always gets to go first",
        "category": "Jealousy & Envy",
        "coreNeed": "Fairness",
        "falseBelief": "Fair means I should get an equal turn every time.",
        "trueBelief": "Fairness includes patience and considering everyone.",
        "feeling": "Low-grade resentment at always being second in line.",
        "parentTeach": "That turns come around, even when the wait feels unfair in the moment.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Playing & Games",
          "Responsibility",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 86,
        "slug": "parent-on-work-call-when-child-wants-to-share-something",
        "name": "Parent on work call when child wants to share something",
        "category": "Jealousy & Envy",
        "coreNeed": "Patience",
        "falseBelief": "If I have to wait, what I want to say isn't important.",
        "trueBelief": "My thoughts matter, and I can wait for the right moment.",
        "feeling": "Frustrated longing to be heard right now, not later.",
        "parentTeach": "That waiting for attention is hard, and their voice still matters when it comes.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 87,
        "slug": "at-a-party-but-wanting-the-birthday-gifts",
        "name": "At a party but wanting the birthday gifts",
        "category": "Jealousy & Envy",
        "coreNeed": "Contentment",
        "falseBelief": "I'll only be happy if I get what someone else has.",
        "trueBelief": "Celebrating others can bring joy too.",
        "feeling": "Wistful envy at gifts meant for someone else.",
        "parentTeach": "That celebrating others can feel good too, even while wanting something similar.",
        "wisdomElement": "Modak",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Celebrations & Traditions",
          "Friendship & Sharing",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 88,
        "slug": "friend-is-naturally-better-at-football-or-dance",
        "name": "Friend is naturally better at football or dance",
        "category": "Jealousy & Envy",
        "coreNeed": "Confidence",
        "falseBelief": "Talent is something you either have or don't.",
        "trueBelief": "Practice helps me improve my own abilities.",
        "feeling": "A twinge of inadequacy next to someone else's natural talent.",
        "parentTeach": "That other people's skill isn't a measure of their own potential.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Playing & Games",
          "Learning & Problem Solving",
          "Self-Care"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 89,
        "slug": "new-sibling-gets-all-the-attention-and-new-things",
        "name": "New sibling gets all the attention and new things",
        "category": "Jealousy & Envy",
        "coreNeed": "Belonging",
        "falseBelief": "The new baby has replaced me.",
        "trueBelief": "Love grows; it isn't divided.",
        "feeling": "Complicated jealousy toward someone who can't even talk yet.",
        "parentTeach": "That love expands for new arrivals — it doesn't get divided up and shrink.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Family & Daily Life",
          "Helping & Caring",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 90,
        "slug": "another-kid-always-gets-teacher-s-favour",
        "name": "Another kid always gets teacher's favour",
        "category": "Jealousy & Envy",
        "coreNeed": "Fairness",
        "falseBelief": "If someone else is chosen, I'm less important.",
        "trueBelief": "I can focus on my own growth instead of comparison.",
        "feeling": "Resentment at a favoritism that feels impossible to earn.",
        "parentTeach": "That one adult's favor isn't the only kind of approval worth having.",
        "wisdomElement": "Eyes",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "School & Community",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 91,
        "slug": "friend-has-more-followers-or-game-skins",
        "name": "Friend has more followers or game skins",
        "category": "Jealousy & Envy",
        "coreNeed": "Contentment",
        "falseBelief": "Having more things or popularity makes someone better.",
        "trueBelief": "Real happiness and friendship can't be measured by possessions or popularity.",
        "feeling": "Comparison-driven envy fed by numbers on a screen.",
        "parentTeach": "That connection in real life outweighs any number online.",
        "wisdomElement": "Modak",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 92,
        "slug": "friend-went-on-a-fancy-international-vacation",
        "name": "Friend went on a fancy international vacation",
        "category": "Jealousy & Envy",
        "coreNeed": "Contentment",
        "falseBelief": "Exciting experiences make someone more important.",
        "trueBelief": "Meaningful memories can be created anywhere.",
        "feeling": "Envy at a life that looks more exciting from the outside.",
        "parentTeach": "That every family's story is different, and different isn't worse.",
        "wisdomElement": "Modak",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Friendship & Sharing",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 93,
        "slug": "wishing-they-had-someone-else-s-hair-or-height",
        "name": "Wishing they had someone else's hair or height",
        "category": "Jealousy & Envy",
        "coreNeed": "Acceptance",
        "falseBelief": "I have to look different to be enough.",
        "trueBelief": "My uniqueness is part of what makes me special.",
        "feeling": "Wishing to look like someone else instead of themselves.",
        "parentTeach": "That the features they have are the ones worth learning to love.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Self-Care"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 94,
        "slug": "wanting-what-s-in-a-friend-s-lunchbox",
        "name": "Wanting what's in a friend's lunchbox",
        "category": "Jealousy & Envy",
        "coreNeed": "Contentment",
        "falseBelief": "What others have is always better.",
        "trueBelief": "Gratitude helps me enjoy what I already have.",
        "feeling": "Simple, physical envy over someone else's snack.",
        "parentTeach": "That trading and sharing can turn envy into connection.",
        "wisdomElement": "Modak",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Friendship & Sharing",
          "Family & Daily Life",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 95,
        "slug": "friend-has-a-later-bedtime-or-more-freedom",
        "name": "Friend has a later bedtime or more freedom",
        "category": "Jealousy & Envy",
        "coreNeed": "Fairness",
        "falseBelief": "Different rules mean my parents are unfair.",
        "trueBelief": "Every family makes choices based on different needs.",
        "feeling": "Chafing against rules that feel stricter than a friend's.",
        "parentTeach": "That every family sets its own rules for its own good reasons.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 96,
        "slug": "always-wearing-older-sibling-s-old-clothes",
        "name": "Always wearing older sibling's old clothes",
        "category": "Jealousy & Envy",
        "coreNeed": "Self-Worth",
        "falseBelief": "New things make someone more valuable.",
        "trueBelief": "My value isn't determined by what I own.",
        "feeling": "Quiet embarrassment about wearing what's already been worn.",
        "parentTeach": "That hand-me-downs carry history, not less value.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Modak",
        "lifeDomains": [
          "Family & Daily Life",
          "Self-Care",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 97,
        "slug": "post-party-or-festival-hyperactivity",
        "name": "Post-party or festival hyperactivity",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Self-Control",
        "falseBelief": "I have to follow every exciting feeling.",
        "trueBelief": "I can enjoy excitement and still calm my body afterwards.",
        "feeling": "Buzzing, uncontainable energy with no clear place to go.",
        "parentTeach": "That big energy needs a big outlet, not a lecture.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Celebrations & Traditions",
          "Family & Daily Life",
          "Self-Care"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 98,
        "slug": "zoning-out-after-too-much-youtube-or-gaming",
        "name": "Zoning out after too much YouTube or gaming",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Self-Control",
        "falseBelief": "My attention controls me.",
        "trueBelief": "I can guide my attention back to what matters.",
        "feeling": "Foggy, disconnected zoning-out after too much screen stimulation.",
        "parentTeach": "That the brain needs quiet time to reset after bright, fast input.",
        "wisdomElement": "Eyes",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Responsibility",
          "Family & Daily Life"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 99,
        "slug": "noisy-overcrowded-mall-or-festival-environment",
        "name": "Noisy, overcrowded mall or festival environment",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Comfort",
        "falseBelief": "I can't cope when everything feels overwhelming.",
        "trueBelief": "I can notice what I need and find calm even in busy places.",
        "feeling": "Sensory flooding from noise and crowds pressing in on all sides.",
        "parentTeach": "That it's okay to need a quiet corner in a loud world.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Self-Care"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 100,
        "slug": "too-many-classes-tuition-sport-music-all-in-one-day",
        "name": "Too many classes — tuition, sport, music all in one day",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Calm",
        "falseBelief": "I have to do everything perfectly.",
        "trueBelief": "I can do my best while caring for my energy.",
        "feeling": "Frayed, thin patience from a day with no breathing room.",
        "parentTeach": "That rest is productive too, not just the things on the schedule.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Modak",
        "lifeDomains": [
          "Family & Daily Life",
          "Responsibility",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 101,
        "slug": "long-wait-at-doctor-bank-or-during-travel",
        "name": "Long wait at doctor, bank, or during travel",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Patience",
        "falseBelief": "Waiting is pointless and unbearable.",
        "trueBelief": "I can use waiting time calmly and wisely.",
        "feeling": "Restless irritability from time stretching with nothing to do.",
        "parentTeach": "That boredom can be sat with — it isn't an emergency to fix.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Responsibility",
          "Playing & Games"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 102,
        "slug": "stuck-indoors-on-a-rainy-day-with-nothing-to-do",
        "name": "Stuck indoors on a rainy day with nothing to do",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Flexibility",
        "falseBelief": "Fun only happens when things go as planned.",
        "trueBelief": "I can create joy wherever I am.",
        "feeling": "Antsy frustration at being stuck with no outlet for the day's energy.",
        "parentTeach": "That indoor days can still hold adventure, just a smaller-scale one.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "Playing & Games",
          "Art",
          "Music & Creativity",
          "Building & Creating"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 103,
        "slug": "end-of-a-long-school-week-brain-feels-full",
        "name": "End of a long school week — brain feels full",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Comfort",
        "falseBelief": "I should always keep going.",
        "trueBelief": "Rest is part of learning and growing.",
        "feeling": "Depleted, foggy exhaustion by the end of a long week.",
        "parentTeach": "That a full brain deserves rest, the same way a full day deserves sleep.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Modak",
        "lifeDomains": [
          "School & Community",
          "Family & Daily Life",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 104,
        "slug": "cranky-after-a-late-night-or-bad-sleep",
        "name": "Cranky after a late night or bad sleep",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Self-Control",
        "falseBelief": "Being tired gives me no control over my behaviour.",
        "trueBelief": "I can notice my feelings and choose kind actions.",
        "feeling": "Thin-skinned crankiness from a body running on too little sleep.",
        "parentTeach": "That crankiness isn't a character flaw — it's a body asking for rest.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Family & Daily Life",
          "Responsibility",
          "Helping & Caring"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 105,
        "slug": "trying-to-do-homework-while-tv-is-on",
        "name": "Trying to do homework while TV is on",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Self-Control",
        "falseBelief": "I can't focus when there are distractions.",
        "trueBelief": "I can gently bring my attention back.",
        "feeling": "Scattered frustration trying to focus with noise pulling attention away.",
        "parentTeach": "That focus needs a quiet space, and asking for one is a smart move, not a weakness.",
        "wisdomElement": "Eyes",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Responsibility",
          "Family & Daily Life"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 106,
        "slug": "too-many-options-for-a-toy-or-treat",
        "name": "Too many options for a toy or treat",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Contentment",
        "falseBelief": "More choices always make me happier.",
        "trueBelief": "Wise choices matter more than having everything.",
        "feeling": "Frozen overwhelm faced with too many options at once.",
        "parentTeach": "That fewer choices, offered kindly, can feel like relief instead of restriction.",
        "wisdomElement": "Modak",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Responsibility",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 107,
        "slug": "pressure-to-always-be-good-and-behave",
        "name": "Pressure to always 'be good' and behave",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Acceptance",
        "falseBelief": "I have to be perfect to be loved.",
        "trueBelief": "I am loved even while I'm learning and growing.",
        "feeling": "Quiet exhaustion from trying to be 'good' all the time.",
        "parentTeach": "That needing a break from being perfect is normal, not naughty.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 108,
        "slug": "waiting-for-a-turn-on-the-swings",
        "name": "Waiting for a turn on the swings",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Patience",
        "falseBelief": "I should always go first.",
        "trueBelief": "Everyone deserves a turn.",
        "feeling": "Impatient fidgeting while watching someone else get a turn.",
        "parentTeach": "That waiting is a skill, and it gets easier with practice, not willpower alone.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Modak",
        "lifeDomains": [
          "Playing & Games",
          "Friendship & Sharing",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 109,
        "slug": "switching-from-fun-activity-to-chores-or-homework",
        "name": "Switching from fun activity to chores or homework",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Self-Control",
        "falseBelief": "I should only do what I enjoy.",
        "trueBelief": "Responsibility helps me earn greater freedom.",
        "feeling": "Resistant friction switching from something fun to something necessary.",
        "parentTeach": "That transitions go smoother with a warning and a moment to finish up.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Family & Daily Life",
          "Responsibility",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 110,
        "slug": "the-before-dinner-energy-crash",
        "name": "The 'before dinner' energy crash",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Self-Control",
        "falseBelief": "My feelings should decide my behaviour.",
        "trueBelief": "I can care for my feelings without hurting others.",
        "feeling": "Sudden, sharp crankiness as hunger outruns patience.",
        "parentTeach": "That hunger changes mood, and naming it early heads off a meltdown.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Family & Daily Life",
          "Helping & Caring",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 111,
        "slug": "uncomfortable-uniform-flickering-lights-strong-smells",
        "name": "Uncomfortable uniform, flickering lights, strong smells",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Comfort",
        "falseBelief": "I can't cope when things feel uncomfortable.",
        "trueBelief": "I can care for myself and ask for help when needed.",
        "feeling": "Irritable overload from textures, lights, or smells that feel like too much.",
        "parentTeach": "That sensory needs are real needs, not fussiness.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 112,
        "slug": "waiting-very-excitedly-for-birthday-or-special-package",
        "name": "Waiting very excitedly for birthday or special package",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Patience",
        "falseBelief": "Waiting ruins the fun.",
        "trueBelief": "Anticipation can make joyful moments even sweeter.",
        "feeling": "Electric, can't-sit-still excitement that's hard to contain.",
        "parentTeach": "That excitement is welcome, even when it needs a little channeling.",
        "wisdomElement": "Modak",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Celebrations & Traditions",
          "Family & Daily Life",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 113,
        "slug": "trying-to-learn-a-very-hard-new-concept-or-language",
        "name": "Trying to learn a very hard new concept or language",
        "category": "Regulation & Energy Overload",
        "coreNeed": "Confidence",
        "falseBelief": "If I don't understand quickly, I'm not smart.",
        "trueBelief": "Understanding grows with patience and practice.",
        "feeling": "Mental strain from a concept that isn't clicking yet.",
        "parentTeach": "That confusion is the first step of learning, not a sign of failure.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Learning & Problem Solving",
          "School & Community",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 114,
        "slug": "moving-to-a-new-home-or-city",
        "name": "Moving to a new home or city",
        "category": "Change & Uncertainty",
        "coreNeed": "Belonging",
        "falseBelief": "I'll never feel at home again.",
        "trueBelief": "Home grows wherever love and connection grow.",
        "feeling": "Unmooring uncertainty about leaving everything familiar behind.",
        "parentTeach": "That home is made of people first, walls second.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Friendship & Sharing",
          "Building & Creating"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 115,
        "slug": "moving-abroad-very-relevant-for-nri-families",
        "name": "Moving abroad (very relevant for NRI families)",
        "category": "Change & Uncertainty",
        "coreNeed": "Belonging",
        "falseBelief": "I won't belong in a new country.",
        "trueBelief": "I can build new friendships while keeping my roots.",
        "feeling": "Disorientation layered with the extra weight of a whole new culture.",
        "parentTeach": "That belonging can grow in more than one place at once.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Friendship & Sharing",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 116,
        "slug": "parents-separating-or-getting-a-divorce",
        "name": "Parents separating or getting a divorce",
        "category": "Change & Uncertainty",
        "coreNeed": "Security",
        "falseBelief": "My family is broken and I'm not safe anymore.",
        "trueBelief": "Love and security can continue even when families change.",
        "feeling": "Confused grief about a family shape that's about to change.",
        "parentTeach": "That both parents' love continues, even when the household doesn't stay the same.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Helping & Caring"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 117,
        "slug": "a-parent-starts-a-new-job-with-different-hours",
        "name": "A parent starts a new job with different hours",
        "category": "Change & Uncertainty",
        "coreNeed": "Trust",
        "falseBelief": "Less time together means less love.",
        "trueBelief": "Love isn't measured by time but by care and connection.",
        "feeling": "Uneasy adjustment to a parent being less available than before.",
        "parentTeach": "That love isn't measured only in hours in the room.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 118,
        "slug": "starting-at-a-completely-new-school",
        "name": "Starting at a completely new school",
        "category": "Change & Uncertainty",
        "coreNeed": "Belonging",
        "falseBelief": "Nobody will accept me.",
        "trueBelief": "I can create new friendships by being myself.",
        "feeling": "Anxious blankness facing a place with no familiar faces yet.",
        "parentTeach": "That every new place becomes familiar with enough small, repeated days.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "School & Community",
          "Friendship & Sharing",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 119,
        "slug": "favourite-teacher-changes-mid-year",
        "name": "Favourite teacher changes mid-year",
        "category": "Change & Uncertainty",
        "coreNeed": "Trust",
        "falseBelief": "Good things never last.",
        "trueBelief": "New people can also become trusted guides.",
        "feeling": "Quiet grief for a favorite adult who is no longer in charge.",
        "parentTeach": "That good people can still be missed even after they're gone from a role.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "School & Community",
          "Communication",
          "Helping & Caring"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 120,
        "slug": "sudden-cancellation-of-a-normal-routine-event",
        "name": "Sudden cancellation of a normal routine event",
        "category": "Change & Uncertainty",
        "coreNeed": "Flexibility",
        "falseBelief": "Everything has to happen the way I expected.",
        "trueBelief": "I can adapt and discover new possibilities.",
        "feeling": "Frustrated disorientation when something ordinary suddenly doesn't happen.",
        "parentTeach": "That flexibility is a muscle, and disappointment can be worked through, not avoided.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Learning & Problem Solving",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 121,
        "slug": "summer-ending-and-school-starting-again",
        "name": "Summer ending and school starting again",
        "category": "Change & Uncertainty",
        "coreNeed": "Hope",
        "falseBelief": "Fun is over now.",
        "trueBelief": "Every new season brings new adventures.",
        "feeling": "A wistful, unsettled feeling as one familiar season hands off to another.",
        "parentTeach": "That endings and beginnings are the same event seen from two sides.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "School & Community",
          "Family & Daily Life",
          "Friendship & Sharing"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 122,
        "slug": "growing-pains-first-tooth-loss-puberty-signs",
        "name": "Growing pains, first tooth loss, puberty signs",
        "category": "Change & Uncertainty",
        "coreNeed": "Acceptance",
        "falseBelief": "Growing and changing is scary.",
        "trueBelief": "Growing is a natural and wonderful part of life.",
        "feeling": "Confusing physical sensations that don't match how they feel inside.",
        "parentTeach": "That growing bodies are strange and normal at the same time.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Family & Daily Life",
          "Learning & Problem Solving",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 123,
        "slug": "friend-suddenly-acting-different-or-cooler",
        "name": "Friend suddenly acting different or 'cooler'",
        "category": "Change & Uncertainty",
        "coreNeed": "Belonging",
        "falseBelief": "I have to change to keep my friends.",
        "trueBelief": "Real friendships accept me for who I am.",
        "feeling": "Uneasy watchfulness as a friendship starts to feel different.",
        "parentTeach": "That friends can change without the friendship having to end.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 124,
        "slug": "game-or-app-changes-interface-completely",
        "name": "Game or app changes interface completely",
        "category": "Change & Uncertainty",
        "coreNeed": "Flexibility",
        "falseBelief": "I don't like change, so I can't enjoy it.",
        "trueBelief": "I can learn new ways of doing things.",
        "feeling": "Mild disorientation at a familiar tool suddenly behaving differently.",
        "parentTeach": "That adapting to change is a skill, practiced on small things first.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Playing & Games",
          "Responsibility"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 125,
        "slug": "new-nanny-or-household-helper-joins-family",
        "name": "New nanny or household helper joins family",
        "category": "Change & Uncertainty",
        "coreNeed": "Trust",
        "falseBelief": "New people can't become part of my safe world.",
        "trueBelief": "Trust grows through kindness and shared experiences.",
        "feeling": "Wary uncertainty about a new person joining the household routine.",
        "parentTeach": "That trust with a new person builds the same way it did with the old one — slowly.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Helping & Caring",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 126,
        "slug": "news-of-an-upcoming-surgery-or-treatment",
        "name": "News of an upcoming surgery or treatment",
        "category": "Change & Uncertainty",
        "coreNeed": "Courage",
        "falseBelief": "I won't be able to handle what's coming.",
        "trueBelief": "I can face difficult moments one brave step at a time.",
        "feeling": "Quiet fear behind news of an upcoming medical event.",
        "parentTeach": "That worry and information can sit side by side, and questions are always welcome.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Helping & Caring",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 127,
        "slug": "family-having-to-cut-back-on-treats-or-outings",
        "name": "Family having to cut back on treats or outings",
        "category": "Change & Uncertainty",
        "coreNeed": "Contentment",
        "falseBelief": "Happiness comes from having more.",
        "trueBelief": "Love, togetherness and gratitude bring lasting happiness.",
        "feeling": "Confused disappointment at hearing 'we can't this time.'",
        "parentTeach": "That family resources ebb and flow, and love isn't rationed the same way money is.",
        "wisdomElement": "Modak",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Family & Daily Life",
          "Responsibility",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 128,
        "slug": "waiting-anxiously-for-exam-results",
        "name": "Waiting anxiously for exam results",
        "category": "Change & Uncertainty",
        "coreNeed": "Confidence",
        "falseBelief": "My marks decide my value.",
        "trueBelief": "My effort and character matter more than any score.",
        "feeling": "Stomach-churning anticipation while waiting for news out of their control.",
        "parentTeach": "That the waiting is often harder than the result, and both can be survived.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "School & Community",
          "Learning & Problem Solving",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 129,
        "slug": "first-time-staying-overnight-away-from-home",
        "name": "First time staying overnight away from home",
        "category": "Change & Uncertainty",
        "coreNeed": "Security",
        "falseBelief": "I can't feel safe away from home.",
        "trueBelief": "I can feel safe in new places with trusted people.",
        "feeling": "Nervous excitement tangled with homesickness before a first night away.",
        "parentTeach": "That being brave doesn't mean not missing home — both can be true at once.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Family & Daily Life",
          "Friendship & Sharing",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 130,
        "slug": "stopping-a-favourite-hobby-or-activity",
        "name": "Stopping a favourite hobby or activity",
        "category": "Change & Uncertainty",
        "coreNeed": "Hope",
        "falseBelief": "If one chapter ends, all the joy is gone.",
        "trueBelief": "New interests and opportunities will come.",
        "feeling": "Quiet grief for a hobby or identity that's ending.",
        "parentTeach": "That interests can change without erasing what was loved about the old one.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "Art",
          "Music & Creativity",
          "Playing & Games",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 131,
        "slug": "overheard-adults-talk-about-a-big-change-coming",
        "name": "Overheard adults talk about 'a big change coming'",
        "category": "Change & Uncertainty",
        "coreNeed": "Security",
        "falseBelief": "Unknown changes are always bad.",
        "trueBelief": "I can face change calmly and ask questions when I'm unsure.",
        "feeling": "Anxious eavesdropping-driven dread about an unnamed 'big change.'",
        "parentTeach": "That asking directly is safer than imagining, and most answers are less scary than the unknown.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Family & Daily Life",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 132,
        "slug": "told-a-lie-to-a-parent-and-feels-a-heavy-stomach",
        "name": "Told a lie to a parent and feels a 'heavy' stomach",
        "category": "Moral & Values Confusion",
        "coreNeed": "Integrity",
        "falseBelief": "Hiding the truth will protect me.",
        "trueBelief": "Honesty brings trust, even after mistakes.",
        "feeling": "A heavy, guilty knot in the stomach after bending the truth.",
        "parentTeach": "That honesty feels lighter than the lie, even when it's harder to say.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Communication",
          "Responsibility",
          "Family & Daily Life"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 133,
        "slug": "friends-asked-them-to-steal-or-break-a-rule",
        "name": "Friends asked them to steal or break a rule",
        "category": "Moral & Values Confusion",
        "coreNeed": "Integrity",
        "falseBelief": "I must follow my friends to belong.",
        "trueBelief": "Doing what's right is more important than fitting in.",
        "feeling": "Torn unease between wanting to belong and knowing something is wrong.",
        "parentTeach": "That real friends don't require doing something that feels wrong.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 134,
        "slug": "watched-someone-get-bullied-and-did-nothing",
        "name": "Watched someone get bullied and did nothing",
        "category": "Moral & Values Confusion",
        "coreNeed": "Courage",
        "falseBelief": "Speaking up won't make a difference.",
        "trueBelief": "Small acts of courage can protect others.",
        "feeling": "Guilty discomfort at having stood by while someone else got hurt.",
        "parentTeach": "That speaking up, even quietly to a trusted adult, is its own kind of courage.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Helping & Caring",
          "Communication",
          "School & Community"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 135,
        "slug": "a-mean-kid-got-praised-or-rewarded",
        "name": "A mean kid got praised or rewarded",
        "category": "Moral & Values Confusion",
        "coreNeed": "Fairness",
        "falseBelief": "Bad behaviour always wins.",
        "trueBelief": "I can't control others, but I can choose my own values.",
        "feeling": "Confused indignation when good behavior isn't the one that gets rewarded.",
        "parentTeach": "That doing right doesn't depend on being noticed for it.",
        "wisdomElement": "Eyes",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Communication",
          "Learning & Problem Solving",
          "School & Community"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 136,
        "slug": "wants-to-play-but-knows-they-should-study",
        "name": "Wants to play but knows they should study",
        "category": "Moral & Values Confusion",
        "coreNeed": "Self-Control",
        "falseBelief": "I should always do what feels fun now.",
        "trueBelief": "Choosing responsibility today helps me tomorrow.",
        "feeling": "An inner tug-of-war between what's fun and what's responsible.",
        "parentTeach": "That choosing the harder, better thing gets easier with practice, not willpower alone.",
        "wisdomElement": "Mouse",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Playing & Games",
          "Learning & Problem Solving",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 137,
        "slug": "tempted-to-look-at-friend-s-paper-during-a-test",
        "name": "Tempted to look at friend's paper during a test",
        "category": "Moral & Values Confusion",
        "coreNeed": "Integrity",
        "falseBelief": "Cheating is okay if it helps me succeed.",
        "trueBelief": "Honest effort builds real confidence.",
        "feeling": "Tempting shortcut-thinking under the pressure of a ticking clock.",
        "parentTeach": "That their own effort, even if smaller, belongs to them in a way a copied answer never will.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "School & Community",
          "Responsibility",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 138,
        "slug": "told-a-bad-secret-they-feel-should-be-shared",
        "name": "Told a 'bad' secret they feel should be shared",
        "category": "Moral & Values Confusion",
        "coreNeed": "Responsibility",
        "falseBelief": "Keeping every secret makes me a good friend.",
        "trueBelief": "Safe adults should know secrets that can protect someone.",
        "feeling": "Uneasy custodianship of information that feels too big to hold alone.",
        "parentTeach": "That some secrets are meant to be shared with a trusted adult, and that's not betrayal.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Communication",
          "Helping & Caring",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 139,
        "slug": "broke-something-by-mistake-and-hid-it",
        "name": "Broke something by mistake and hid it",
        "category": "Moral & Values Confusion",
        "coreNeed": "Responsibility",
        "falseBelief": "Hiding mistakes makes them disappear.",
        "trueBelief": "Taking responsibility helps rebuild trust.",
        "feeling": "Panicked guilt after damage they're afraid to admit to.",
        "parentTeach": "That owning a mistake quickly is easier than carrying the secret of it.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Responsibility",
          "Building & Creating",
          "Communication"
        ],
        "priority": "⭐⭐⭐ High"
      },
      {
        "id": 140,
        "slug": "realised-some-kids-don-t-have-food-or-shoes",
        "name": "Realised some kids don't have food or shoes",
        "category": "Moral & Values Confusion",
        "coreNeed": "Compassion",
        "falseBelief": "Other people's struggles have nothing to do with me.",
        "trueBelief": "Kindness and generosity can make a real difference.",
        "feeling": "Unsettled awareness of unfairness bigger than their own life.",
        "parentTeach": "That noticing unfairness in the world is the first step toward caring about it.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Modak",
        "lifeDomains": [
          "Helping & Caring",
          "Friendship & Sharing",
          "Family & Daily Life"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 141,
        "slug": "saw-a-parent-or-teacher-break-a-rule-they-enforce",
        "name": "Saw a parent or teacher break a rule they enforce",
        "category": "Moral & Values Confusion",
        "coreNeed": "Integrity",
        "falseBelief": "Rules only matter when they're convenient.",
        "trueBelief": "I can choose integrity regardless of what others do.",
        "feeling": "Confusing cognitive dissonance seeing a rule-enforcer break their own rule.",
        "parentTeach": "That adults are still learning too, and noticing that is a sign of a sharp, fair mind.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "Communication",
          "Learning & Problem Solving",
          "Responsibility"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 142,
        "slug": "someone-online-asked-for-their-personal-password",
        "name": "Someone online asked for their personal password",
        "category": "Moral & Values Confusion",
        "coreNeed": "Security",
        "falseBelief": "Everyone online can be trusted.",
        "trueBelief": "I protect myself by making safe choices and asking trusted adults.",
        "feeling": "Wary unease at a request that feels like it's crossing a line.",
        "parentTeach": "That trusted adults, not strangers online, are who private information belongs to.",
        "wisdomElement": "Eyes",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 143,
        "slug": "saw-someone-litter-and-felt-upset-but-said-nothing",
        "name": "Saw someone litter and felt upset but said nothing",
        "category": "Moral & Values Confusion",
        "coreNeed": "Responsibility",
        "falseBelief": "One person's actions don't matter.",
        "trueBelief": "Small responsible actions help care for our world.",
        "feeling": "Frustrated helplessness witnessing carelessness they can't undo.",
        "parentTeach": "That one person's small action, repeated, adds up to real care for a shared place.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Helping & Caring",
          "Exploring & Nature",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 144,
        "slug": "saw-a-stray-animal-being-treated-badly",
        "name": "Saw a stray animal being treated badly",
        "category": "Moral & Values Confusion",
        "coreNeed": "Compassion",
        "falseBelief": "It's not my place to help.",
        "trueBelief": "Every living being deserves kindness and care.",
        "feeling": "Distressed empathy at cruelty toward a creature who can't speak up.",
        "parentTeach": "That kindness to animals is a rehearsal for kindness everywhere.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Helping & Caring",
          "Exploring & Nature",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 145,
        "slug": "failed-to-keep-a-promise-they-made-to-a-friend",
        "name": "Failed to keep a promise they made to a friend",
        "category": "Moral & Values Confusion",
        "coreNeed": "Trust",
        "falseBelief": "One broken promise means the friendship is ruined.",
        "trueBelief": "Trust can be rebuilt through honesty and consistent actions.",
        "feeling": "Guilty regret at letting a friend down.",
        "parentTeach": "That a broken promise can be repaired with an honest apology and a next try.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Friendship & Sharing",
          "Responsibility",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 146,
        "slug": "feels-guilty-for-not-including-someone-in-play",
        "name": "Feels guilty for not including someone in play",
        "category": "Moral & Values Confusion",
        "coreNeed": "Inclusion",
        "falseBelief": "There's only room for some people.",
        "trueBelief": "Everyone deserves a chance to belong.",
        "feeling": "A tender guilt about a small social exclusion.",
        "parentTeach": "That noticing the discomfort of leaving someone out is the beginning of including them next time.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Friendship & Sharing",
          "Playing & Games",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 147,
        "slug": "friend-said-something-mean-about-their-culture-or-family",
        "name": "Friend said something mean about their culture or family",
        "category": "Moral & Values Confusion",
        "coreNeed": "Respect",
        "falseBelief": "I should hide who I am to fit in.",
        "trueBelief": "My identity deserves respect, and I can respect others too.",
        "feeling": "Defensive hurt layered with confusion after an identity-based jab.",
        "parentTeach": "That their family's traditions are not something to be embarrassed by — curiosity from others is a chance to teach, not a verdict.",
        "wisdomElement": "Eyes",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Communication",
          "Friendship & Sharing",
          "School & Community"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 148,
        "slug": "found-something-and-doesn-t-know-whether-to-keep-it",
        "name": "Found something and doesn't know whether to keep it",
        "category": "Moral & Values Confusion",
        "coreNeed": "Integrity",
        "falseBelief": "If I found it, it belongs to me.",
        "trueBelief": "Doing the right thing matters more than getting something extra.",
        "feeling": "Uncertain hesitation weighing honesty against a lucky find.",
        "parentTeach": "That doing the effortful right thing (asking, returning) feels better in the long run than keeping something unclaimed.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Responsibility",
          "Learning & Problem Solving",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 149,
        "slug": "overheard-talk-about-politics-protests-or-injustice",
        "name": "Overheard talk about politics, protests, or injustice",
        "category": "Moral & Values Confusion",
        "coreNeed": "Fairness",
        "falseBelief": "The world is only unfair and nothing can change.",
        "trueBelief": "Fairness grows through understanding, courage and responsible action.",
        "feeling": "Confused unease absorbing adult-sized topics without adult-sized context.",
        "parentTeach": "That the world has hard chapters and repair, and it's alright to ask questions about both.",
        "wisdomElement": "Eyes",
        "secondaryWisdomElement": "Lotus",
        "lifeDomains": [
          "Communication",
          "Learning & Problem Solving",
          "Helping & Caring"
        ],
        "priority": "⭐ Low"
      },
      {
        "id": 150,
        "slug": "best-friend-makes-a-new-best-friend",
        "name": "Best friend makes a new best friend",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Belonging",
        "falseBelief": "If my friend likes someone else, I'll be forgotten.",
        "trueBelief": "Friendships can grow without replacing each other.",
        "feeling": "A sharp pang of replacement — like their special spot just got taken.",
        "parentTeach": "That love and friendship expand to fit more people, they don't get divided up.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Playing & Games"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 151,
        "slug": "friends-don-t-reply-to-messages",
        "name": "Friends don't reply to messages",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Trust",
        "falseBelief": "No reply means they don't care about me.",
        "trueBelief": "I shouldn't assume the worst before I know the truth.",
        "feeling": "Anxious spiraling, assuming the worst from silence.",
        "parentTeach": "That a slow reply is rarely a verdict, and checking in beats assuming.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 152,
        "slug": "accidentally-left-out-of-a-game",
        "name": "Accidentally left out of a game",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Inclusion",
        "falseBelief": "Being left out means I don't belong.",
        "trueBelief": "I can help create spaces where everyone belongs.",
        "feeling": "A quiet sting of exclusion, even without anyone meaning it.",
        "parentTeach": "That noticing who's left out, even by accident, is worth speaking up about.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Friendship & Sharing",
          "Playing & Games",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 153,
        "slug": "a-secret-wasn-t-shared-with-them",
        "name": "A secret wasn't shared with them",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Trust",
        "falseBelief": "If I'm not told everything, I'm not important.",
        "trueBelief": "Trust grows through honesty, not knowing every secret.",
        "feeling": "A hurt feeling of being on the outside of something.",
        "parentTeach": "That not knowing everything doesn't mean being less trusted or valued.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Broken Tusk (Writing Tusk)",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 154,
        "slug": "friend-copies-their-work-or-idea",
        "name": "Friend copies their work or idea",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Respect",
        "falseBelief": "If someone copies me, I've lost what makes me special.",
        "trueBelief": "My ideas and creativity remain valuable.",
        "feeling": "Territorial frustration at losing what felt uniquely theirs.",
        "parentTeach": "That being copied is often a compliment in disguise, and originality isn't used up by sharing.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Eyes",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Art",
          "Music & Creativity",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 155,
        "slug": "a-friend-wins-while-they-lose",
        "name": "A friend wins while they lose",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Self-Worth",
        "falseBelief": "Someone else's success makes me less successful.",
        "trueBelief": "I can celebrate others while continuing my own journey.",
        "feeling": "Competitive sting swallowed under a forced smile.",
        "parentTeach": "That someone else's win and their own effort can both be true at once.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Modak",
        "lifeDomains": [
          "Playing & Games",
          "Friendship & Sharing",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 156,
        "slug": "friend-breaks-a-promise",
        "name": "Friend breaks a promise",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Trust",
        "falseBelief": "Once trust is broken, it can never be repaired.",
        "trueBelief": "Honest conversations and actions can rebuild trust.",
        "feeling": "Disappointment curdling into distrust.",
        "parentTeach": "That one broken promise is a repair conversation, not proof the friendship is over.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 157,
        "slug": "rumours-or-gossip-spread-about-them",
        "name": "Rumours or gossip spread about them",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Integrity",
        "falseBelief": "I have to prove myself to everyone.",
        "trueBelief": "Truth and character matter more than rumours.",
        "feeling": "Helpless anger at a story about them they didn't get to tell.",
        "parentTeach": "That their actions and character speak louder than a rumor, over time.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Communication",
          "School & Community",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 158,
        "slug": "friend-apologises-after-hurting-them",
        "name": "Friend apologises after hurting them",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Forgiveness",
        "falseBelief": "Holding on to hurt keeps me safe.",
        "trueBelief": "Forgiveness helps relationships heal and grow.",
        "feeling": "A tug-of-war between wanting to forgive and wanting to protect themselves.",
        "parentTeach": "That accepting an apology is a choice they get to make in their own time.",
        "wisdomElement": "Lotus",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Helping & Caring"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 159,
        "slug": "they-hurt-a-friend-s-feelings-by-mistake",
        "name": "They hurt a friend's feelings by mistake",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Responsibility",
        "falseBelief": "One mistake makes me a bad friend.",
        "trueBelief": "I can apologise, repair and learn from my mistakes.",
        "feeling": "Guilty regret at seeing the effect of their own words.",
        "parentTeach": "That a sincere apology repairs more than staying quiet out of embarrassment.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 160,
        "slug": "asked-to-choose-between-two-friends",
        "name": "Asked to choose between two friends",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Fairness",
        "falseBelief": "I have to choose one person over another.",
        "trueBelief": "I can be kind and fair to everyone.",
        "feeling": "Squeezed, torn loyalty with no comfortable answer.",
        "parentTeach": "That they don't have to rank people they care about.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Friendship & Sharing",
          "Communication",
          "Learning & Problem Solving"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 161,
        "slug": "lost-during-a-team-game-because-of-their-mistake",
        "name": "Lost during a team game because of their mistake",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Responsibility",
        "falseBelief": "Everyone will blame me forever.",
        "trueBelief": "Mistakes are part of teamwork and learning.",
        "feeling": "Public, hot-faced guilt at letting the team down.",
        "parentTeach": "That one mistake in a team game is shared, not carried alone.",
        "wisdomElement": "Broken Tusk (Writing Tusk)",
        "secondaryWisdomElement": "Mouse",
        "lifeDomains": [
          "Playing & Games",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 162,
        "slug": "teammate-isn-t-doing-their-part",
        "name": "Teammate isn't doing their part",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Respect",
        "falseBelief": "I have to control others for things to go well.",
        "trueBelief": "Cooperation grows through patience and communication.",
        "feeling": "Simmering frustration at carrying more than their share.",
        "parentTeach": "That naming the problem calmly works better than doing it all silently.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Playing & Games",
          "Communication",
          "Responsibility"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 163,
        "slug": "friend-gets-a-pet-they-always-wanted",
        "name": "Friend gets a pet they always wanted",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Contentment",
        "falseBelief": "Life is unfair because I don't have what they have.",
        "trueBelief": "I can be genuinely happy for others while appreciating my own life.",
        "feeling": "A wistful envy dressed up as happiness for a friend.",
        "parentTeach": "That wanting what someone else has doesn't make their own life less good.",
        "wisdomElement": "Modak",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "Friendship & Sharing",
          "Helping & Caring",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 164,
        "slug": "a-younger-child-wants-to-join-the-game",
        "name": "A younger child wants to join the game",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Inclusion",
        "falseBelief": "Younger children will spoil our fun.",
        "trueBelief": "Everyone deserves a chance to belong.",
        "feeling": "Impatient reluctance to slow down for someone less skilled.",
        "parentTeach": "That making room for someone smaller is its own kind of strength.",
        "wisdomElement": "Big Belly",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Playing & Games",
          "Friendship & Sharing",
          "Helping & Caring"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 165,
        "slug": "friend-is-nervous-before-a-performance",
        "name": "Friend is nervous before a performance",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Compassion",
        "falseBelief": "It's not my job to help.",
        "trueBelief": "Encouragement can help someone become brave.",
        "feeling": "A protective instinct paired with not knowing what to do with it.",
        "parentTeach": "That a few kind words before a hard moment can genuinely help someone else.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Helping & Caring",
          "Art",
          "Music & Creativity",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 166,
        "slug": "classmate-is-new-and-sitting-alone",
        "name": "Classmate is new and sitting alone",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Kindness",
        "falseBelief": "Someone else will help them.",
        "trueBelief": "Small acts of kindness can make someone feel welcome.",
        "feeling": "A flicker of concern quickly talked out of by shyness.",
        "parentTeach": "That the small effort of saying hello can change someone's whole day.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Big Belly",
        "lifeDomains": [
          "School & Community",
          "Helping & Caring",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 167,
        "slug": "friend-keeps-interrupting-while-talking",
        "name": "Friend keeps interrupting while talking",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Respect",
        "falseBelief": "The loudest person should be heard.",
        "trueBelief": "Listening is an important way to show respect.",
        "feeling": "Mounting frustration at not getting to finish a thought.",
        "parentTeach": "That asking to be heard, calmly, is fair and normal.",
        "wisdomElement": "Big Ears",
        "secondaryWisdomElement": "Curved Trunk",
        "lifeDomains": [
          "Communication",
          "Friendship & Sharing",
          "School & Community"
        ],
        "priority": "⭐⭐ Medium"
      },
      {
        "id": 168,
        "slug": "group-project-where-everyone-has-different-ideas",
        "name": "Group project where everyone has different ideas",
        "category": "Friendship & Peer Dynamics",
        "coreNeed": "Flexibility",
        "falseBelief": "My idea has to be chosen.",
        "trueBelief": "Great ideas grow when people work together.",
        "feeling": "Frustrated insistence that their idea is the right one.",
        "parentTeach": "That combining ideas usually makes something better than any one idea alone.",
        "wisdomElement": "Curved Trunk",
        "secondaryWisdomElement": "Big Ears",
        "lifeDomains": [
          "Learning & Problem Solving",
          "Building & Creating",
          "Communication"
        ],
        "priority": "⭐⭐ Medium"
      }
    ],
    "wisdomElements": [
      {
        "id": 1,
        "slug": "big-ears",
        "name": "Big Ears",
        "type": "Symbol",
        "coreMeaning": "Listen deeply before acting",
        "bestCoreNeeds": [
          "Belonging",
          "Communication"
        ],
        "bestChallenges": [
          "Interrupting",
          "Misunderstandings",
          "Not feeling heard"
        ],
        "teachingMethod": "Listening before speaking",
        "storyExpression": "Child pauses to listen to others or nature",
        "insight": "\"When I listen carefully, I understand better.\"",
        "bestEmotionalArcs": [
          "Empathetic Witness",
          "Circle of Safety"
        ],
        "bestStoryWorlds": [
          "Whispering Forest",
          "Whispering Meadow",
          "Crystal River Valley"
        ]
      },
      {
        "id": 2,
        "slug": "eyes",
        "name": "Eyes",
        "type": "Symbol",
        "coreMeaning": "Observe with awareness, kindness and understanding",
        "bestCoreNeeds": [
          "Empathy",
          "Curiosity"
        ],
        "bestChallenges": [
          "Judging others",
          "Missing details",
          "Jumping to conclusions"
        ],
        "teachingMethod": "Observe before deciding",
        "storyExpression": "Notices small clues, emotions or beauty",
        "insight": "\"When I look carefully, I understand more.\"",
        "bestEmotionalArcs": [
          "Sensory Discovery",
          "Identity Reframing"
        ],
        "bestStoryWorlds": [
          "Whispering Forest",
          "Lotus Pond",
          "Woodland Village"
        ]
      },
      {
        "id": 3,
        "slug": "curved-trunk",
        "name": "Curved Trunk",
        "type": "Symbol",
        "coreMeaning": "Be flexible and solve problems creatively",
        "bestCoreNeeds": [
          "Confidence",
          "Adaptability"
        ],
        "bestChallenges": [
          "Frustration",
          "Unexpected change"
        ],
        "teachingMethod": "Explore different solutions",
        "storyExpression": "Tries another path or approach",
        "insight": "\"There is more than one way.\"",
        "bestEmotionalArcs": [
          "Resourceful Improviser",
          "Creative Empowerment"
        ],
        "bestStoryWorlds": [
          "Whispering Forest",
          "Hidden Cave Network",
          "Golden Grasslands"
        ]
      },
      {
        "id": 4,
        "slug": "big-belly",
        "name": "Big Belly",
        "type": "Symbol",
        "coreMeaning": "Accept and hold big feelings calmly",
        "bestCoreNeeds": [
          "Emotional Regulation",
          "Safety"
        ],
        "bestChallenges": [
          "Anger",
          "Worry",
          "Embarrassment"
        ],
        "teachingMethod": "Pause, breathe, reflect",
        "storyExpression": "Breathes, waits, responds calmly",
        "insight": "\"I can hold my feelings without letting them control me.\"",
        "bestEmotionalArcs": [
          "Emotional Harbor",
          "Mindful De-escalation"
        ],
        "bestStoryWorlds": [
          "Lotus Pond",
          "Crystal River Valley",
          "Ancient Banyan Grove"
        ]
      },
      {
        "id": 5,
        "slug": "mouse",
        "name": "Mouse",
        "type": "Symbol",
        "coreMeaning": "Small, focused steps overcome big obstacles",
        "bestCoreNeeds": [
          "Confidence",
          "Self-Belief"
        ],
        "bestChallenges": [
          "Feeling small",
          "Fear of trying"
        ],
        "teachingMethod": "Tiny actions build courage",
        "storyExpression": "Small successes lead to bigger ones",
        "insight": "\"Small steps create big change.\"",
        "bestEmotionalArcs": [
          "Underdog's Wit",
          "Courageous Breath"
        ],
        "bestStoryWorlds": [
          "Whispering Forest",
          "Whispering Meadow",
          "Woodland Village"
        ]
      },
      {
        "id": 6,
        "slug": "modak",
        "name": "Modak",
        "type": "Symbol",
        "coreMeaning": "True joy comes through effort and sharing",
        "bestCoreNeeds": [
          "Gratitude",
          "Generosity"
        ],
        "bestChallenges": [
          "Selfishness",
          "Impatience",
          "Sharing"
        ],
        "teachingMethod": "Reward through effort",
        "storyExpression": "Shares, celebrates and enjoys together",
        "insight": "\"Giving and earning bring lasting joy.\"",
        "bestEmotionalArcs": [
          "Generous Heart",
          "Appreciated Helper"
        ],
        "bestStoryWorlds": [
          "Whispering Meadow",
          "Celebration Village",
          "Woodland Village"
        ]
      },
      {
        "id": 7,
        "slug": "lotus",
        "name": "Lotus",
        "type": "Symbol",
        "coreMeaning": "Grow beautifully through every challenge",
        "bestCoreNeeds": [
          "Self-Worth",
          "Hope"
        ],
        "bestChallenges": [
          "Feeling different",
          "Comparison"
        ],
        "teachingMethod": "Quiet inner growth",
        "storyExpression": "Blooms despite difficult surroundings",
        "insight": "\"I can grow wherever I am planted.\"",
        "bestEmotionalArcs": [
          "Radical Self-Acceptance",
          "Identity Reframing"
        ],
        "bestStoryWorlds": [
          "Lotus Pond",
          "Crystal River Valley",
          "Flower Garden"
        ]
      },
      {
        "id": 8,
        "slug": "broken-tusk-writing-tusk",
        "name": "Broken Tusk (Writing Tusk)",
        "type": "Symbol",
        "coreMeaning": "Learn through perseverance and wisdom",
        "bestCoreNeeds": [
          "Curiosity",
          "Learning"
        ],
        "bestChallenges": [
          "Fear of mistakes",
          "Learning new skills"
        ],
        "teachingMethod": "Learn by doing",
        "storyExpression": "Tries, reflects and improves",
        "insight": "\"Every mistake helps me grow wiser.\"",
        "bestEmotionalArcs": [
          "Creative Empowerment",
          "Rhythmic Growth"
        ],
        "bestStoryWorlds": [
          "Ancient Banyan Grove",
          "Secret Library",
          "Story House"
        ]
      },
      {
        "id": 17,
        "slug": "",
        "name": "•",
        "type": "Ganesha Chants",
        "coreMeaning": null,
        "bestCoreNeeds": [],
        "bestChallenges": [],
        "teachingMethod": null,
        "storyExpression": null,
        "insight": null,
        "bestEmotionalArcs": [],
        "bestStoryWorlds": []
      },
      {
        "id": 18,
        "slug": "",
        "name": "•",
        "type": "Ganesha Festivals",
        "coreMeaning": null,
        "bestCoreNeeds": [],
        "bestChallenges": [],
        "teachingMethod": null,
        "storyExpression": null,
        "insight": null,
        "bestEmotionalArcs": [],
        "bestStoryWorlds": []
      },
      {
        "id": 19,
        "slug": "",
        "name": "•",
        "type": "Sacred Objects",
        "coreMeaning": null,
        "bestCoreNeeds": [],
        "bestChallenges": [],
        "teachingMethod": null,
        "storyExpression": null,
        "insight": null,
        "bestEmotionalArcs": [],
        "bestStoryWorlds": []
      },
      {
        "id": 20,
        "slug": "",
        "name": "•",
        "type": "Ganesha Stories",
        "coreMeaning": null,
        "bestCoreNeeds": [],
        "bestChallenges": [],
        "teachingMethod": null,
        "storyExpression": null,
        "insight": null,
        "bestEmotionalArcs": [],
        "bestStoryWorlds": []
      }
    ],
    "mainCharacters": [
      {
        "id": 1,
        "slug": "chinu-squirrel",
        "name": "Chinu (Squirrel)",
        "corePersonality": "Curious, energetic learner",
        "canAlsoBe": [
          "Explorer",
          "helper",
          "comic"
        ],
        "primaryStoryRole": "Explorer",
        "bestCoreNeeds": [
          "Curiosity & Exploration",
          "Confidence",
          "Problem Solving"
        ],
        "bestChallenges": [
          "Trying new things",
          "Making mistakes",
          "Asking questions",
          "Solving mysteries",
          "Feeling left out because of curiosity"
        ],
        "bestWisdomElements": [
          "Big Ears",
          "Curved Trunk",
          "Mouse"
        ]
      },
      {
        "id": 2,
        "slug": "arin-rabbit",
        "name": "Arin (Rabbit)",
        "corePersonality": "Gentle, cautious",
        "canAlsoBe": [
          "Brave hero",
          "thoughtful friend"
        ],
        "primaryStoryRole": "Courage Learner",
        "bestCoreNeeds": [
          "Courage",
          "Confidence",
          "Emotional Safety"
        ],
        "bestChallenges": [
          "Fear of trying",
          "Anxiety",
          "New experiences",
          "Fear of failure",
          "Fear of the unknown"
        ],
        "bestWisdomElements": [
          "Broken Tusk (Writing Tusk)",
          "Big Belly",
          "Lotus"
        ]
      },
      {
        "id": 3,
        "slug": "bodhi-elephant",
        "name": "Bodhi (Elephant)",
        "corePersonality": "Wise, calm",
        "canAlsoBe": [
          "Protector",
          "playful elder brother"
        ],
        "primaryStoryRole": "Mentor / Protector",
        "bestCoreNeeds": [
          "Belonging",
          "Kindness",
          "Generosity",
          "Emotional Security"
        ],
        "bestChallenges": [
          "Big feelings",
          "Sharing",
          "Helping others",
          "Resolving conflicts",
          "Caring for friends"
        ],
        "bestWisdomElements": [
          "Big Belly",
          "Curved Trunk"
        ]
      },
      {
        "id": 4,
        "slug": "tara-turtle",
        "name": "Tara (Turtle)",
        "corePersonality": "Patient, steady",
        "canAlsoBe": [
          "Quiet thinker"
        ],
        "primaryStoryRole": "Patient Thinker",
        "bestCoreNeeds": [
          "Patience",
          "Perseverance",
          "Self-Belief"
        ],
        "bestChallenges": [
          "Waiting",
          "Slow progress",
          "Feeling left behind",
          "Giving up too soon"
        ],
        "bestWisdomElements": [
          "Lotus",
          "Big Belly"
        ]
      },
      {
        "id": 5,
        "slug": "kavi-monkey",
        "name": "Kavi (Monkey)",
        "corePersonality": "Funny, impulsive",
        "canAlsoBe": [
          "Inventor",
          "explorer"
        ],
        "primaryStoryRole": "Comic Catalyst",
        "bestCoreNeeds": [
          "Self-Control",
          "Focus",
          "Responsibility"
        ],
        "bestChallenges": [
          "Distraction",
          "Acting without thinking",
          "Overexcitement",
          "Following rules"
        ],
        "bestWisdomElements": [
          "Mouse",
          "Curved Trunk"
        ]
      },
      {
        "id": 6,
        "slug": "mira-deer",
        "name": "Mira (Deer)",
        "corePersonality": "Gentle, observant",
        "canAlsoBe": [
          "Brave friend"
        ],
        "primaryStoryRole": "Empathy Builder",
        "bestCoreNeeds": [
          "Empathy",
          "Kindness",
          "Belonging"
        ],
        "bestChallenges": [
          "Shyness",
          "Making friends",
          "Understanding others",
          "Helping someone lonely"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Lotus"
        ]
      },
      {
        "id": 7,
        "slug": "nayan-fox",
        "name": "Nayan (Fox)",
        "corePersonality": "Clever, resourceful",
        "canAlsoBe": [
          "Puzzle solver"
        ],
        "primaryStoryRole": "Puzzle Solver",
        "bestCoreNeeds": [
          "Problem Solving",
          "Confidence",
          "Creativity"
        ],
        "bestChallenges": [
          "Solving difficult problems",
          "Thinking differently",
          "Making smart choices"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Broken Tusk (Writing Tusk)"
        ]
      },
      {
        "id": 8,
        "slug": "ved-owl",
        "name": "Ved (Owl)",
        "corePersonality": "Wise, reflective",
        "canAlsoBe": [
          "Detective",
          "teacher"
        ],
        "primaryStoryRole": "Wise Guide / Detective",
        "bestCoreNeeds": [
          "Curiosity",
          "Wisdom",
          "Understanding"
        ],
        "bestChallenges": [
          "Confusion",
          "Curiosity",
          "Asking questions",
          "Solving mysteries"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Big Ears"
        ]
      },
      {
        "id": 9,
        "slug": "veer-bear",
        "name": "Veer (Bear)",
        "corePersonality": "Strong, kind",
        "canAlsoBe": [
          "Gentle protector"
        ],
        "primaryStoryRole": "Gentle Guardian",
        "bestCoreNeeds": [
          "Courage",
          "Responsibility",
          "Kindness"
        ],
        "bestChallenges": [
          "Helping others",
          "Standing up for someone",
          "Protecting others",
          "Leadership"
        ],
        "bestWisdomElements": [
          "Big Belly",
          "Broken Tusk (Writing Tusk)"
        ]
      },
      {
        "id": 10,
        "slug": "anu-mouse",
        "name": "Anu (Mouse)",
        "corePersonality": "Tiny but courageous",
        "canAlsoBe": [
          "Determined learner"
        ],
        "primaryStoryRole": "Underdog Hero",
        "bestCoreNeeds": [
          "Courage",
          "Self-Worth",
          "Confidence"
        ],
        "bestChallenges": [
          "Feeling small",
          "Being underestimated",
          "Fear of trying",
          "Speaking up"
        ],
        "bestWisdomElements": [
          "Mouse",
          "Broken Tusk (Writing Tusk)"
        ]
      },
      {
        "id": 11,
        "slug": "mayur-peacock",
        "name": "Mayur (Peacock)",
        "corePersonality": "Joyful, expressive",
        "canAlsoBe": [
          "Performer"
        ],
        "primaryStoryRole": "Performer",
        "bestCoreNeeds": [
          "Self-Expression",
          "Confidence",
          "Joy"
        ],
        "bestChallenges": [
          "Stage fright",
          "Expressing talents",
          "Celebrating uniqueness"
        ],
        "bestWisdomElements": [
          "Lotus"
        ]
      },
      {
        "id": 12,
        "slug": "vani-parrot",
        "name": "Vani (Parrot)",
        "corePersonality": "Talkative, cheerful",
        "canAlsoBe": [
          "Messenger"
        ],
        "primaryStoryRole": "Messenger",
        "bestCoreNeeds": [
          "Communication",
          "Listening",
          "Friendship"
        ],
        "bestChallenges": [
          "Listening carefully",
          "Speaking kindly",
          "Solving misunderstandings"
        ],
        "bestWisdomElements": [
          "Big Ears"
        ]
      },
      {
        "id": 13,
        "slug": "mitra-dog",
        "name": "Mitra (Dog)",
        "corePersonality": "Loyal, dependable",
        "canAlsoBe": [
          "Best friend"
        ],
        "primaryStoryRole": "Loyal Companion",
        "bestCoreNeeds": [
          "Trust",
          "Friendship",
          "Belonging"
        ],
        "bestChallenges": [
          "Broken promises",
          "Friendship problems",
          "Loyalty",
          "Teamwork"
        ],
        "bestWisdomElements": [
          "Big Belly"
        ]
      },
      {
        "id": 14,
        "slug": "gauri-cow",
        "name": "Gauri (Cow)",
        "corePersonality": "Caring, nurturing",
        "canAlsoBe": [
          "Mother figure"
        ],
        "primaryStoryRole": "Nurturer",
        "bestCoreNeeds": [
          "Kindness",
          "Gratitude",
          "Generosity"
        ],
        "bestChallenges": [
          "Sharing",
          "Caring for others",
          "Gratitude",
          "Community"
        ],
        "bestWisdomElements": [
          "Modak",
          "Big Belly"
        ]
      },
      {
        "id": 15,
        "slug": "simha-lion",
        "name": "Simha (Lion)",
        "corePersonality": "Brave, confident",
        "canAlsoBe": [
          "Protector"
        ],
        "primaryStoryRole": "Leader",
        "bestCoreNeeds": [
          "Leadership",
          "Courage",
          "Responsibility"
        ],
        "bestChallenges": [
          "Leading others",
          "Making difficult choices",
          "Protecting others",
          "Doing the right thing"
        ],
        "bestWisdomElements": [
          "Broken Tusk (Writing Tusk)"
        ]
      },
      {
        "id": 16,
        "slug": "neel-young-elephant-calf",
        "name": "Neel (Young Elephant Calf)",
        "corePersonality": "Curious, playful, eager to learn",
        "canAlsoBe": [
          "Adventurous learner"
        ],
        "primaryStoryRole": "Young Learner",
        "bestCoreNeeds": [
          "Curiosity",
          "Confidence",
          "Courage",
          "Self-Belief"
        ],
        "bestChallenges": [
          "First-time experiences",
          "Fear of failure",
          "Learning from mistakes",
          "Trying again"
        ],
        "bestWisdomElements": [
          "Curved Trunk",
          "Big Ears",
          "Modak"
        ]
      },
      {
        "id": 17,
        "slug": "pihu-red-panda",
        "name": "Pihu (Red Panda)",
        "corePersonality": "Imaginative, artistic",
        "canAlsoBe": [
          "Creator",
          "inventor"
        ],
        "primaryStoryRole": "Creator / Inventor",
        "bestCoreNeeds": [
          "Creativity",
          "Self-Expression",
          "Problem Solving"
        ],
        "bestChallenges": [
          "Creative blocks",
          "Thinking differently",
          "Inventing solutions",
          "Expressing ideas"
        ],
        "bestWisdomElements": [
          "Lotus",
          "Mouse"
        ]
      },
      {
        "id": 18,
        "slug": "kabir-mountain-goat",
        "name": "Kabir (Mountain Goat)",
        "corePersonality": "Determined, adventurous",
        "canAlsoBe": [
          "Explorer",
          "climber"
        ],
        "primaryStoryRole": "Adventurer",
        "bestCoreNeeds": [
          "Perseverance",
          "Courage",
          "Independence"
        ],
        "bestChallenges": [
          "Difficult challenges",
          "Never giving up",
          "Exploring unknown places",
          "Reaching a goal"
        ],
        "bestWisdomElements": [
          "Broken Tusk (Writing Tusk)",
          "Lotus"
        ]
      }
    ],
    "lifeDomains": [
      {
        "id": 1,
        "slug": "friendship-sharing",
        "name": "Friendship & Sharing",
        "description": "Building friendships, kindness and cooperation.",
        "storyFocus": "Sharing, inclusion, teamwork, resolving conflicts",
        "exampleMissions": [
          "Help a Lonely Friend",
          "Share the Harvest"
        ]
      },
      {
        "id": 2,
        "slug": "family-daily-life",
        "name": "Family & Daily Life",
        "description": "Everyday family experiences and responsibilities.",
        "storyFocus": "Home, siblings, routines, caring",
        "exampleMissions": [
          "Return a Borrowed Item",
          "Care for an Elder"
        ]
      },
      {
        "id": 3,
        "slug": "school-community",
        "name": "School & Community",
        "description": "Learning to be part of a group and contribute.",
        "storyFocus": "School, neighbourhood, teamwork, leadership",
        "exampleMissions": [
          "Help the Community",
          "Clean a Shared Space"
        ]
      },
      {
        "id": 4,
        "slug": "learning-problem-solving",
        "name": "Learning & Problem Solving",
        "description": "Curiosity, thinking and discovering solutions.",
        "storyFocus": "Mysteries, puzzles, learning skills",
        "exampleMissions": [
          "Solve a Puzzle",
          "Find the Last Clue"
        ]
      },
      {
        "id": 5,
        "slug": "playing-games",
        "name": "Playing & Games",
        "description": "Play, imagination and friendly competition.",
        "storyFocus": "Games, adventures, sports, pretend play",
        "exampleMissions": [
          "Treasure Hunt",
          "Friendly Challenge"
        ]
      },
      {
        "id": 6,
        "slug": "helping-caring",
        "name": "Helping & Caring",
        "description": "Compassion and helping people, animals and nature.",
        "storyFocus": "Service, empathy, kindness",
        "exampleMissions": [
          "Rescue a Trapped Animal",
          "Deliver Medicine"
        ]
      },
      {
        "id": 7,
        "slug": "exploring-nature",
        "name": "Exploring & Nature",
        "description": "Discovering the natural world.",
        "storyFocus": "Forests, rivers, mountains, exploration",
        "exampleMissions": [
          "Explore a Hidden Cave",
          "Find a Rare Flower"
        ]
      },
      {
        "id": 8,
        "slug": "building-creating",
        "name": "Building & Creating",
        "description": "Making, repairing and inventing.",
        "storyFocus": "Construction, crafts, creativity",
        "exampleMissions": [
          "Build a Bridge",
          "Repair a Nest"
        ]
      },
      {
        "id": 9,
        "slug": "art-music-creativity",
        "name": "Art, Music & Creativity",
        "description": "Expressing ideas through creativity.",
        "storyFocus": "Music, dance, painting, storytelling",
        "exampleMissions": [
          "Plan a Performance",
          "Create Something Together"
        ]
      },
      {
        "id": 10,
        "slug": "communication",
        "name": "Communication",
        "description": "Listening, speaking and understanding others.",
        "storyFocus": "Honest conversations, misunderstandings, teamwork",
        "exampleMissions": [
          "Deliver an Important Message",
          "Settle a Disagreement"
        ]
      },
      {
        "id": 11,
        "slug": "responsibility",
        "name": "Responsibility",
        "description": "Keeping promises and doing the right thing.",
        "storyFocus": "Honesty, duties, caring for belongings",
        "exampleMissions": [
          "Return Something Precious",
          "Protect the Harvest"
        ]
      },
      {
        "id": 12,
        "slug": "celebrations-traditions",
        "name": "Celebrations & Traditions",
        "description": "Festivals, customs and joyful community moments.",
        "storyFocus": "Festivals, gratitude, family traditions",
        "exampleMissions": [
          "Prepare a Festival",
          "Decorate a Village"
        ]
      },
      {
        "id": 13,
        "slug": "self-care",
        "name": "Self-Care",
        "description": "Understanding and managing oneself.",
        "storyFocus": "Feelings, courage, confidence, resilience",
        "exampleMissions": [
          "Face a Fear",
          "Learn a New Skill"
        ]
      }
    ],
    "storyActions": [
      {
        "id": 1,
        "slug": "search",
        "name": "Search",
        "description": "Look for someone, something or clues.",
        "bestLifeDomains": [
          "Exploring & Nature",
          "Learning & Problem Solving",
          "Responsibility"
        ],
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Mystery to Solve",
          "Detective Story",
          "Treasure Hunt",
          "Secret Discovery"
        ]
      },
      {
        "id": 2,
        "slug": "explore",
        "name": "Explore",
        "description": "Discover unknown places or investigate new environments.",
        "bestLifeDomains": [
          "Exploring & Nature",
          "Playing & Games"
        ],
        "bestAdventureArchetypes": [
          "Great Journey",
          "Expedition",
          "Hidden World",
          "Secret Discovery",
          "Ancient Secret"
        ]
      },
      {
        "id": 3,
        "slug": "help",
        "name": "Help",
        "description": "Assist another character in overcoming a challenge.",
        "bestLifeDomains": [
          "Helping & Caring",
          "Friendship & Sharing",
          "School & Community"
        ],
        "bestAdventureArchetypes": [
          "Helping Hand",
          "Shared Mission",
          "Team Adventure",
          "Community Project"
        ]
      },
      {
        "id": 4,
        "slug": "rescue",
        "name": "Rescue",
        "description": "Save someone or something from danger.",
        "bestLifeDomains": [
          "Helping & Caring",
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Guardian Adventure",
          "Escape Adventure",
          "Race Against Time"
        ]
      },
      {
        "id": 5,
        "slug": "protect",
        "name": "Protect",
        "description": "Keep a person, place or object safe.",
        "bestLifeDomains": [
          "Responsibility",
          "Helping & Caring",
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Guardian Adventure",
          "Nature's Balance",
          "Responsibility Quest"
        ]
      },
      {
        "id": 6,
        "slug": "build",
        "name": "Build",
        "description": "Construct, repair or improve something.",
        "bestLifeDomains": [
          "Building & Creating"
        ],
        "bestAdventureArchetypes": [
          "Build Together",
          "Restoration Story",
          "Community Project"
        ]
      },
      {
        "id": 7,
        "slug": "create",
        "name": "Create",
        "description": "Make something artistic, useful or original.",
        "bestLifeDomains": [
          "Art",
          "Music & Creativity",
          "Building & Creating"
        ],
        "bestAdventureArchetypes": [
          "Performance Story",
          "Festival Adventure",
          "Magical Discovery"
        ]
      },
      {
        "id": 8,
        "slug": "deliver",
        "name": "Deliver",
        "description": "Carry something safely to its destination.",
        "bestLifeDomains": [
          "Responsibility",
          "Family & Daily Life",
          "Communication"
        ],
        "bestAdventureArchetypes": [
          "Delivery Quest",
          "Escort Mission",
          "Promise Keeper"
        ]
      },
      {
        "id": 9,
        "slug": "solve",
        "name": "Solve",
        "description": "Solve a mystery, puzzle or practical problem.",
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestAdventureArchetypes": [
          "Mystery to Solve",
          "Detective Story",
          "Problem Solver",
          "Ancient Secret"
        ]
      },
      {
        "id": 10,
        "slug": "learn",
        "name": "Learn",
        "description": "Gain a new skill or understanding.",
        "bestLifeDomains": [
          "Learning & Problem Solving",
          "Self-Care"
        ],
        "bestAdventureArchetypes": [
          "Training Journey",
          "Transformation Story",
          "Learning Quest"
        ]
      },
      {
        "id": 11,
        "slug": "teach",
        "name": "Teach",
        "description": "Help another character learn.",
        "bestLifeDomains": [
          "Learning & Problem Solving",
          "Helping & Caring"
        ],
        "bestAdventureArchetypes": [
          "Helping Hand",
          "Community Project",
          "Journey Together"
        ]
      },
      {
        "id": 12,
        "slug": "share",
        "name": "Share",
        "description": "Give, include or cooperate with others.",
        "bestLifeDomains": [
          "Friendship & Sharing",
          "Celebrations & Traditions"
        ],
        "bestAdventureArchetypes": [
          "Gift of Giving",
          "Friendship Repair",
          "New Friend",
          "Journey Together"
        ]
      },
      {
        "id": 13,
        "slug": "care-for",
        "name": "Care For",
        "description": "Look after a person, animal, place or nature.",
        "bestLifeDomains": [
          "Helping & Caring",
          "Self-Care"
        ],
        "bestAdventureArchetypes": [
          "Nature's Balance",
          "Restoration Story",
          "Helping Hand"
        ]
      },
      {
        "id": 14,
        "slug": "restore",
        "name": "Restore",
        "description": "Bring something back to its best condition.",
        "bestLifeDomains": [
          "Building & Creating",
          "Exploring & Nature",
          "Helping & Caring"
        ],
        "bestAdventureArchetypes": [
          "Restoration Story",
          "Nature's Balance",
          "Friendship Repair"
        ]
      },
      {
        "id": 15,
        "slug": "organize",
        "name": "Organize",
        "description": "Plan, prepare or coordinate an activity.",
        "bestLifeDomains": [
          "Responsibility",
          "School & Community",
          "Celebrations & Traditions"
        ],
        "bestAdventureArchetypes": [
          "Celebration Preparation",
          "Festival Adventure",
          "Community Project"
        ]
      },
      {
        "id": 16,
        "slug": "communicate",
        "name": "Communicate",
        "description": "Listen, explain or resolve through conversation.",
        "bestLifeDomains": [
          "Communication",
          "Friendship & Sharing"
        ],
        "bestAdventureArchetypes": [
          "Friendship Repair",
          "Promise Keeper",
          "Choice & Consequence"
        ]
      },
      {
        "id": 17,
        "slug": "guide",
        "name": "Guide",
        "description": "Lead others safely or wisely.",
        "bestLifeDomains": [
          "Helping & Caring",
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Great Journey",
          "Escort Mission",
          "Guardian Adventure"
        ]
      },
      {
        "id": 18,
        "slug": "perform",
        "name": "Perform",
        "description": "Present music, dance, drama or another talent.",
        "bestLifeDomains": [
          "Art",
          "Music & Creativity"
        ],
        "bestAdventureArchetypes": [
          "Performance Story",
          "Festival Adventure",
          "Celebration Preparation"
        ]
      },
      {
        "id": 19,
        "slug": "celebrate",
        "name": "Celebrate",
        "description": "Mark a joyful occasion together.",
        "bestLifeDomains": [
          "Celebrations & Traditions",
          "Family & Daily Life"
        ],
        "bestAdventureArchetypes": [
          "Festival Adventure",
          "Celebration Preparation",
          "Heritage Journey"
        ]
      },
      {
        "id": 20,
        "slug": "practice",
        "name": "Practice",
        "description": "Improve through repetition and perseverance.",
        "bestLifeDomains": [
          "Learning & Problem Solving",
          "Self-Care"
        ],
        "bestAdventureArchetypes": [
          "Training Journey",
          "Hero's Trial",
          "Transformation Story"
        ]
      }
    ],
    "adventureArchetypes": [
      {
        "id": 1,
        "slug": "rescue-mission",
        "name": "Rescue Mission",
        "description": "Save someone or something from danger.",
        "bestAdventureTriggers": [
          "Someone Missing",
          "Danger Appears",
          "Call for Help"
        ],
        "bestStoryStructures": [
          "Rescue Story",
          "Quest Story"
        ],
        "bestEmotionalArcs": [
          "Fear → Courage",
          "Anxiety → Confidence"
        ],
        "bestStoryWorlds": [
          "Forest",
          "River",
          "Mountain",
          "Village"
        ],
        "notes": "High urgency"
      },
      {
        "id": 2,
        "slug": "guardian-adventure",
        "name": "Guardian Adventure",
        "description": "Protect a person, place or treasure.",
        "bestAdventureTriggers": [
          "Something Valuable at Risk",
          "Nature in Danger",
          "Threat Appears"
        ],
        "bestStoryStructures": [
          "Protection Story",
          "Hero Story"
        ],
        "bestEmotionalArcs": [
          "Responsibility → Confidence",
          "Worry → Calm"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Temple",
          "Village",
          "Garden"
        ],
        "notes": "Focus on protection rather than rescue"
      },
      {
        "id": 3,
        "slug": "escape-adventure",
        "name": "Escape Adventure",
        "description": "Escape safely from danger or confinement.",
        "bestAdventureTriggers": [
          "Trapped",
          "Unexpected Danger",
          "Wrong Turn"
        ],
        "bestStoryStructures": [
          "Escape Story",
          "Survival Story"
        ],
        "bestEmotionalArcs": [
          "Panic → Calm",
          "Fear → Relief"
        ],
        "bestStoryWorlds": [
          "Cave",
          "Forest",
          "Mountain"
        ],
        "notes": "Fast-paced"
      },
      {
        "id": 4,
        "slug": "survival-adventure",
        "name": "Survival Adventure",
        "description": "Overcome nature or environmental challenges.",
        "bestAdventureTriggers": [
          "Storm",
          "Flood",
          "Lost",
          "Harsh Weather"
        ],
        "bestStoryStructures": [
          "Survival Story",
          "Journey Story"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Resilience",
          "Fear → Confidence"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Mountain",
          "Desert",
          "Snow"
        ],
        "notes": "Nature is the main challenge"
      },
      {
        "id": 5,
        "slug": "delivery-quest",
        "name": "Delivery Quest",
        "description": "Deliver something important safely.",
        "bestAdventureTriggers": [
          "Important Delivery",
          "Promise Made",
          "Urgent Request"
        ],
        "bestStoryStructures": [
          "Delivery Story",
          "Journey Story"
        ],
        "bestEmotionalArcs": [
          "Responsibility → Pride",
          "Hesitation → Commitment"
        ],
        "bestStoryWorlds": [
          "Village",
          "Forest",
          "River",
          "School"
        ],
        "notes": "Time pressure works well"
      },
      {
        "id": 7,
        "slug": "mystery-to-solve",
        "name": "Mystery to Solve",
        "description": "Solve an unexplained mystery.",
        "bestAdventureTriggers": [
          "Strange Clue",
          "Missing Object",
          "Odd Event"
        ],
        "bestStoryStructures": [
          "Mystery Story"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Confidence",
          "Confusion → Clarity"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Village",
          "Story House"
        ],
        "notes": "Clue-driven"
      },
      {
        "id": 8,
        "slug": "detective-story",
        "name": "Detective Story",
        "description": "Investigate clues to uncover the truth.",
        "bestAdventureTriggers": [
          "Conflicting Clues",
          "Suspicious Behaviour",
          "Missing Item"
        ],
        "bestStoryStructures": [
          "Investigation Story",
          "Mystery Story"
        ],
        "bestEmotionalArcs": [
          "Doubt → Understanding",
          "Curiosity → Insight"
        ],
        "bestStoryWorlds": [
          "Village",
          "School",
          "Forest"
        ],
        "notes": "Observation is key"
      },
      {
        "id": 9,
        "slug": "treasure-hunt",
        "name": "Treasure Hunt",
        "description": "Find something valuable by following clues.",
        "bestAdventureTriggers": [
          "Hidden Map",
          "Ancient Clue",
          "Secret Message"
        ],
        "bestStoryStructures": [
          "Treasure Hunt Story",
          "Quest Story"
        ],
        "bestEmotionalArcs": [
          "Excitement → Achievement",
          "Curiosity → Joy"
        ],
        "bestStoryWorlds": [
          "Cave",
          "Forest",
          "Mountain",
          "Beach"
        ],
        "notes": "Treasure can be wisdom, not just an object"
      },
      {
        "id": 10,
        "slug": "secret-discovery",
        "name": "Secret Discovery",
        "description": "Discover a hidden truth or place.",
        "bestAdventureTriggers": [
          "Hidden Door",
          "Forgotten Path",
          "Secret Message"
        ],
        "bestStoryStructures": [
          "Discovery Story"
        ],
        "bestEmotionalArcs": [
          "Wonder → Understanding",
          "Curiosity → Awe"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Garden",
          "Story House"
        ],
        "notes": "Focus on revelation"
      },
      {
        "id": 11,
        "slug": "hidden-world",
        "name": "Hidden World",
        "description": "Discover a world unknown to the hero.",
        "bestAdventureTriggers": [
          "Secret Entrance",
          "Unexpected Discovery",
          "Magical Gateway"
        ],
        "bestStoryStructures": [
          "Discovery Story",
          "Exploration Story"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Wonder",
          "Uncertainty → Belonging"
        ],
        "bestStoryWorlds": [
          "Cave",
          "Forest",
          "Ancient Garden",
          "Sky World"
        ],
        "notes": "Strong sense of exploration"
      },
      {
        "id": 13,
        "slug": "great-journey",
        "name": "Great Journey",
        "description": "Travel to an important destination.",
        "bestAdventureTriggers": [
          "Invitation",
          "Important Mission",
          "Call to Adventure"
        ],
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestEmotionalArcs": [
          "Uncertainty → Confidence",
          "Doubt → Growth"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Mountain",
          "River",
          "Desert"
        ],
        "notes": "Classic travel adventure"
      },
      {
        "id": 14,
        "slug": "expedition",
        "name": "Expedition",
        "description": "Explore an unknown place together.",
        "bestAdventureTriggers": [
          "New Discovery",
          "Explorer's Map",
          "Curious Rumour"
        ],
        "bestStoryStructures": [
          "Exploration Story"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Wonder"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Cave",
          "Snow",
          "Desert"
        ],
        "notes": "Focus on exploration"
      },
      {
        "id": 15,
        "slug": "find-the-way-home",
        "name": "Find the Way Home",
        "description": "Return safely after becoming lost.",
        "bestAdventureTriggers": [
          "Lost",
          "Wrong Turn",
          "Storm"
        ],
        "bestStoryStructures": [
          "Return Home Story",
          "Journey Story"
        ],
        "bestEmotionalArcs": [
          "Fear → Relief",
          "Confusion → Confidence"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Mountain",
          "River"
        ],
        "notes": "Home becomes the emotional goal"
      },
      {
        "id": 16,
        "slug": "escort-mission",
        "name": "Escort Mission",
        "description": "Safely accompany someone or something.",
        "bestAdventureTriggers": [
          "Someone Needs Guidance",
          "Important Delivery",
          "Rescue Request"
        ],
        "bestStoryStructures": [
          "Escort Story",
          "Journey Story"
        ],
        "bestEmotionalArcs": [
          "Responsibility → Pride"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Village",
          "River"
        ],
        "notes": "Protection through companionship"
      },
      {
        "id": 17,
        "slug": "race-against-time",
        "name": "Race Against Time",
        "description": "Complete the mission before time runs out.",
        "bestAdventureTriggers": [
          "Before Sunset",
          "Festival Begins",
          "Rising Water"
        ],
        "bestStoryStructures": [
          "Time Challenge Story"
        ],
        "bestEmotionalArcs": [
          "Anxiety → Determination"
        ],
        "bestStoryWorlds": [
          "Any",
          "especially Forest",
          "Village",
          "River"
        ],
        "notes": "Strong pacing and urgency"
      },
      {
        "id": 19,
        "slug": "friendship-repair",
        "name": "Friendship Repair",
        "description": "Heal a damaged friendship.",
        "bestAdventureTriggers": [
          "Misunderstanding",
          "Broken Promise",
          "Hurt Feelings"
        ],
        "bestStoryStructures": [
          "Relationship Story"
        ],
        "bestEmotionalArcs": [
          "Hurt → Forgiveness",
          "Loneliness → Belonging"
        ],
        "bestStoryWorlds": [
          "Village",
          "Meadow",
          "School"
        ],
        "notes": "Emotion-driven"
      },
      {
        "id": 20,
        "slug": "new-friend",
        "name": "New Friend",
        "description": "Build a friendship with someone new.",
        "bestAdventureTriggers": [
          "New Arrival",
          "Lonely Character",
          "Shared Problem"
        ],
        "bestStoryStructures": [
          "Friendship Story"
        ],
        "bestEmotionalArcs": [
          "Shyness → Connection"
        ],
        "bestStoryWorlds": [
          "Village",
          "School",
          "Forest"
        ],
        "notes": "Ideal for younger readers"
      },
      {
        "id": 21,
        "slug": "second-chance",
        "name": "Second Chance",
        "description": "Make things right after a mistake.",
        "bestAdventureTriggers": [
          "Mistake Made",
          "Failure",
          "Lost Opportunity"
        ],
        "bestStoryStructures": [
          "Redemption Story"
        ],
        "bestEmotionalArcs": [
          "Guilt → Self-Forgiveness"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "notes": "Growth through action"
      },
      {
        "id": 22,
        "slug": "helping-hand",
        "name": "Helping Hand",
        "description": "Help someone succeed without taking over.",
        "bestAdventureTriggers": [
          "Someone Struggling",
          "Request for Help"
        ],
        "bestStoryStructures": [
          "Helper Story"
        ],
        "bestEmotionalArcs": [
          "Empathy → Joy"
        ],
        "bestStoryWorlds": [
          "Village",
          "Forest",
          "Garden"
        ],
        "notes": "Fits the Prana Kids philosophy well"
      },
      {
        "id": 23,
        "slug": "journey-together",
        "name": "Journey Together",
        "description": "Work together to reach a shared goal.",
        "bestAdventureTriggers": [
          "Shared Mission",
          "Group Challenge",
          "Invitation"
        ],
        "bestStoryStructures": [
          "Team Journey Story"
        ],
        "bestEmotionalArcs": [
          "Independence → Cooperation"
        ],
        "bestStoryWorlds": [
          "Forest",
          "River",
          "Mountain",
          "Village"
        ],
        "notes": "Teamwork is central"
      },
      {
        "id": 25,
        "slug": "team-adventure",
        "name": "Team Adventure",
        "description": "A group works together to achieve a common goal.",
        "bestAdventureTriggers": [
          "Group Challenge",
          "Call for Help",
          "Community Need"
        ],
        "bestStoryStructures": [
          "Team Story"
        ],
        "bestEmotionalArcs": [
          "Independence → Cooperation"
        ],
        "bestStoryWorlds": [
          "Village",
          "Forest",
          "School",
          "River"
        ],
        "notes": "Every character contributes"
      },
      {
        "id": 26,
        "slug": "community-project",
        "name": "Community Project",
        "description": "Characters improve something for everyone.",
        "bestAdventureTriggers": [
          "Community Problem",
          "Festival Preparation",
          "Shared Need"
        ],
        "bestStoryStructures": [
          "Community Story"
        ],
        "bestEmotionalArcs": [
          "Responsibility → Pride"
        ],
        "bestStoryWorlds": [
          "Village",
          "Garden",
          "School"
        ],
        "notes": "Focus on service"
      },
      {
        "id": 27,
        "slug": "leadership-challenge",
        "name": "Leadership Challenge",
        "description": "A character learns to guide others.",
        "bestAdventureTriggers": [
          "Leader Needed",
          "Difficult Decision",
          "Group Conflict"
        ],
        "bestStoryStructures": [
          "Leadership Story"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Confidence"
        ],
        "bestStoryWorlds": [
          "Village",
          "Mountain",
          "Forest"
        ],
        "notes": "Leadership through kindness"
      },
      {
        "id": 28,
        "slug": "shared-mission",
        "name": "Shared Mission",
        "description": "Two or more heroes complete one objective together.",
        "bestAdventureTriggers": [
          "Common Goal",
          "Invitation",
          "Urgent Task"
        ],
        "bestStoryStructures": [
          "Partnership Story"
        ],
        "bestEmotionalArcs": [
          "Individual Thinking → Teamwork"
        ],
        "bestStoryWorlds": [
          "Forest",
          "River",
          "Village"
        ],
        "notes": "Equal contribution"
      },
      {
        "id": 29,
        "slug": "build-together",
        "name": "Build Together",
        "description": "Characters create or repair something as a team.",
        "bestAdventureTriggers": [
          "Broken Structure",
          "Need for Shelter",
          "Community Request"
        ],
        "bestStoryStructures": [
          "Builder Story"
        ],
        "bestEmotionalArcs": [
          "Frustration → Achievement"
        ],
        "bestStoryWorlds": [
          "Village",
          "River",
          "Forest"
        ],
        "notes": "Cooperation is central"
      },
      {
        "id": 31,
        "slug": "hero-s-trial",
        "name": "Hero's Trial",
        "description": "The hero faces a difficult personal test.",
        "bestAdventureTriggers": [
          "Challenge Issued",
          "Important Opportunity",
          "Personal Goal"
        ],
        "bestStoryStructures": [
          "Trial Story"
        ],
        "bestEmotionalArcs": [
          "Fear → Courage"
        ],
        "bestStoryWorlds": [
          "Mountain",
          "Forest",
          "Cave"
        ],
        "notes": "Internal growth is the real victory"
      },
      {
        "id": 32,
        "slug": "final-challenge",
        "name": "Final Challenge",
        "description": "One last obstacle before success.",
        "bestAdventureTriggers": [
          "Mission Nearly Complete",
          "Final Barrier"
        ],
        "bestStoryStructures": [
          "Climax Story"
        ],
        "bestEmotionalArcs": [
          "Determination → Triumph"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "notes": "Used near the story climax"
      },
      {
        "id": 33,
        "slug": "training-journey",
        "name": "Training Journey",
        "description": "Growth happens through practice and persistence.",
        "bestAdventureTriggers": [
          "Mentor Appears",
          "Need for New Skill",
          "Personal Goal"
        ],
        "bestStoryStructures": [
          "Training Story"
        ],
        "bestEmotionalArcs": [
          "Inexperience → Confidence"
        ],
        "bestStoryWorlds": [
          "Mountain",
          "Banyan Grove",
          "School"
        ],
        "notes": "Progress through repetition"
      },
      {
        "id": 34,
        "slug": "problem-solver",
        "name": "Problem Solver",
        "description": "The hero overcomes a practical challenge using thinking and creativity.",
        "bestAdventureTriggers": [
          "Problem Appears",
          "Broken Object",
          "Missing Solution"
        ],
        "bestStoryStructures": [
          "Problem-Solving Story"
        ],
        "bestEmotionalArcs": [
          "Confusion → Clarity"
        ],
        "bestStoryWorlds": [
          "Village",
          "Story House",
          "Forest"
        ],
        "notes": "Emphasises reasoning"
      },
      {
        "id": 35,
        "slug": "responsibility-quest",
        "name": "Responsibility Quest",
        "description": "The hero earns trust by doing the right thing.",
        "bestAdventureTriggers": [
          "Promise Made",
          "Important Duty",
          "Mistake to Correct"
        ],
        "bestStoryStructures": [
          "Responsibility Story"
        ],
        "bestEmotionalArcs": [
          "Carelessness → Responsibility"
        ],
        "bestStoryWorlds": [
          "Village",
          "Home",
          "School"
        ],
        "notes": "Strong moral growth without preaching"
      },
      {
        "id": 37,
        "slug": "invention-story",
        "name": "Invention Story",
        "description": "Invent or improve something to solve a practical problem.",
        "bestAdventureTriggers": [
          "Problem to Solve",
          "Broken Tool",
          "Community Need"
        ],
        "bestStoryStructures": [
          "Innovation Story"
        ],
        "bestEmotionalArcs": [
          "Frustration → Confidence"
        ],
        "bestStoryWorlds": [
          "Workshop",
          "Village",
          "School",
          "Maker's Corner"
        ],
        "notes": "Focus on experimentation and learning from failure."
      },
      {
        "id": 38,
        "slug": "restoration-story",
        "name": "Restoration Story",
        "description": "Repair something that has been damaged or lost.",
        "bestAdventureTriggers": [
          "Damage Discovered",
          "Community Need"
        ],
        "bestStoryStructures": [
          "Restoration Story"
        ],
        "bestEmotionalArcs": [
          "Loss → Hope"
        ],
        "bestStoryWorlds": [
          "Village",
          "Garden",
          "Forest"
        ],
        "notes": "Physical and emotional restoration"
      },
      {
        "id": 39,
        "slug": "creative-quest",
        "name": "Creative Quest",
        "description": "Use imagination, art or creativity to complete a meaningful mission.",
        "bestAdventureTriggers": [
          "Art Contest",
          "Empty Space",
          "Special Request"
        ],
        "bestStoryStructures": [
          "Creation Story"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Confidence"
        ],
        "bestStoryWorlds": [
          "Art Studio",
          "Celebration Village",
          "School",
          "Garden"
        ],
        "notes": "Creativity becomes the solution, not magic."
      },
      {
        "id": 40,
        "slug": "build-repair",
        "name": "Build & Repair",
        "description": "Build, repair or restore something that helps others.",
        "bestAdventureTriggers": [
          "Broken Bridge",
          "Damaged Home",
          "Community Request"
        ],
        "bestStoryStructures": [
          "Restoration Story"
        ],
        "bestEmotionalArcs": [
          "Helplessness → Achievement"
        ],
        "bestStoryWorlds": [
          "Village",
          "Forest",
          "River",
          "Workshop"
        ],
        "notes": "Strong teamwork stories with visible progress."
      },
      {
        "id": 41,
        "slug": "transformation-story",
        "name": "Transformation Story",
        "description": "The hero changes through experience and wisdom.",
        "bestAdventureTriggers": [
          "Personal Challenge",
          "Mistake",
          "Inner Conflict"
        ],
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "False Belief → True Belief"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "notes": "Ideal for Prana Kids' philosophy"
      },
      {
        "id": 43,
        "slug": "mentor-journey",
        "name": "Mentor Journey",
        "description": "Learn through guidance from a wise mentor while solving a real challenge.",
        "bestAdventureTriggers": [
          "Mentor's Invitation",
          "Wisdom Challenge",
          "Special Training"
        ],
        "bestStoryStructures": [
          "Mentor Story"
        ],
        "bestEmotionalArcs": [
          "Confusion → Understanding"
        ],
        "bestStoryWorlds": [
          "Temple",
          "Story House",
          "Forest",
          "Mountain"
        ],
        "notes": "Mentor guides through questions and examples rather than giving answers."
      },
      {
        "id": 44,
        "slug": "learning-quest",
        "name": "Learning Quest",
        "description": "Complete a series of learning challenges to achieve an important goal.",
        "bestAdventureTriggers": [
          "New Skill Needed",
          "Challenge Accepted",
          "Important Mission"
        ],
        "bestStoryStructures": [
          "Training Story"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Competence"
        ],
        "bestStoryWorlds": [
          "School",
          "Forest",
          "Workshop",
          "Temple"
        ],
        "notes": "Progress should happen through practice and persistence."
      },
      {
        "id": 45,
        "slug": "discovery-journey",
        "name": "Discovery Journey",
        "description": "Explore unknown places to uncover knowledge, history or hidden truths.",
        "bestAdventureTriggers": [
          "Hidden Map",
          "Strange Clue",
          "Forgotten Path"
        ],
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Wonder"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Cave",
          "Desert",
          "Snow World",
          "Story House"
        ],
        "notes": "Emphasize exploration over danger."
      },
      {
        "id": 46,
        "slug": "wisdom-challenge",
        "name": "Wisdom Challenge",
        "description": "Face situations that require wise choices rather than clever solutions.",
        "bestAdventureTriggers": [
          "Moral Dilemma",
          "Difficult Decision",
          "Ancient Wisdom"
        ],
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "Confusion → Wisdom"
        ],
        "bestStoryWorlds": [
          "Temple",
          "Village",
          "Story House"
        ],
        "notes": "Perfect for Ganesha symbolism and value-based stories."
      },
      {
        "id": 47,
        "slug": "teaching-adventure",
        "name": "Teaching Adventure",
        "description": "Help another character learn an important skill or lesson through shared experiences.",
        "bestAdventureTriggers": [
          "Someone Needs Help",
          "Younger Friend",
          "Community Request"
        ],
        "bestStoryStructures": [
          "Relationship Story"
        ],
        "bestEmotionalArcs": [
          "Responsibility → Compassion"
        ],
        "bestStoryWorlds": [
          "Village",
          "School",
          "Forest",
          "Celebration Village"
        ],
        "notes": "The hero also learns while teaching; avoid preachy lessons."
      },
      {
        "id": 49,
        "slug": "festival-adventure",
        "name": "Festival Adventure",
        "description": "Solve challenges during a festival or celebration.",
        "bestAdventureTriggers": [
          "Festival Begins",
          "Community Celebration",
          "Special Invitation"
        ],
        "bestStoryStructures": [
          "Celebration Story"
        ],
        "bestEmotionalArcs": [
          "Excitement → Belonging"
        ],
        "bestStoryWorlds": [
          "Village",
          "Temple",
          "Celebration Village"
        ],
        "notes": "Ideal for Ganesh Chaturthi stories"
      },
      {
        "id": 50,
        "slug": "celebration-preparation",
        "name": "Celebration Preparation",
        "description": "Prepare everything before an important event.",
        "bestAdventureTriggers": [
          "Guests Arriving",
          "Festival Tomorrow",
          "Community Request"
        ],
        "bestStoryStructures": [
          "Community Story"
        ],
        "bestEmotionalArcs": [
          "Worry → Joy"
        ],
        "bestStoryWorlds": [
          "Village",
          "Home",
          "School"
        ],
        "notes": "Teamwork-focused"
      },
      {
        "id": 51,
        "slug": "performance-story",
        "name": "Performance Story",
        "description": "Prepare for and present a performance.",
        "bestAdventureTriggers": [
          "Talent Show",
          "Festival Performance",
          "Community Event"
        ],
        "bestStoryStructures": [
          "Performance Story"
        ],
        "bestEmotionalArcs": [
          "Stage Fright → Confidence"
        ],
        "bestStoryWorlds": [
          "School",
          "Village",
          "Celebration Village"
        ],
        "notes": "Great for self-confidence"
      },
      {
        "id": 52,
        "slug": "heritage-journey",
        "name": "Heritage Journey",
        "description": "Discover traditions, history and cultural wisdom.",
        "bestAdventureTriggers": [
          "Family Story",
          "Ancient Object",
          "Festival Tradition"
        ],
        "bestStoryStructures": [
          "Discovery Story"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Pride"
        ],
        "bestStoryWorlds": [
          "Temple",
          "Story House",
          "Village"
        ],
        "notes": "Strong Prana Kids fit"
      },
      {
        "id": 53,
        "slug": "gift-of-giving",
        "name": "Gift of Giving",
        "description": "Learn the joy of giving without expecting anything back.",
        "bestAdventureTriggers": [
          "Someone in Need",
          "Celebration",
          "Opportunity to Share"
        ],
        "bestStoryStructures": [
          "Relationship Story"
        ],
        "bestEmotionalArcs": [
          "Self-Focus → Generosity"
        ],
        "bestStoryWorlds": [
          "Village",
          "Meadow",
          "Festival"
        ],
        "notes": "Excellent with Modak wisdom"
      },
      {
        "id": 55,
        "slug": "magical-discovery",
        "name": "Magical Discovery",
        "description": "Discover a place, object or event that feels magical and inspiring.",
        "bestAdventureTriggers": [
          "Hidden Place",
          "Mysterious Light",
          "Unexpected Discovery"
        ],
        "bestStoryStructures": [
          "Discovery Story"
        ],
        "bestEmotionalArcs": [
          "Wonder → Gratitude"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Cave",
          "Garden"
        ],
        "notes": "Wonder, not magic solving problems"
      },
      {
        "id": 56,
        "slug": "magical-quest",
        "name": "Magical Quest",
        "description": "Complete an adventure filled with wonder and imagination.",
        "bestAdventureTriggers": [
          "Ancient Map",
          "Wise Invitation",
          "Special Mission"
        ],
        "bestStoryStructures": [
          "Quest Story"
        ],
        "bestEmotionalArcs": [
          "Doubt → Wonder"
        ],
        "bestStoryWorlds": [
          "Forest",
          "Mountain",
          "Story House"
        ],
        "notes": "Wisdom—not magic—solves the problem"
      },
      {
        "id": 57,
        "slug": "nature-s-balance",
        "name": "Nature's Balance",
        "description": "Restore harmony between nature and its living beings.",
        "bestAdventureTriggers": [
          "Nature Disturbed",
          "Animal Needs Help",
          "Weather Changes"
        ],
        "bestStoryStructures": [
          "Restoration Story"
        ],
        "bestEmotionalArcs": [
          "Carelessness → Stewardship"
        ],
        "bestStoryWorlds": [
          "Forest",
          "River",
          "Garden"
        ],
        "notes": "Environmental stories"
      },
      {
        "id": 58,
        "slug": "ancient-secret",
        "name": "Ancient Secret",
        "description": "Uncover an old mystery carrying timeless wisdom.",
        "bestAdventureTriggers": [
          "Ancient Symbol",
          "Forgotten Path",
          "Hidden Message"
        ],
        "bestStoryStructures": [
          "Mystery Story"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Understanding"
        ],
        "bestStoryWorlds": [
          "Temple",
          "Cave",
          "Story House"
        ],
        "notes": "Excellent for Ganesha symbolism"
      },
      {
        "id": 59,
        "slug": "wish-or-blessing",
        "name": "Wish or Blessing",
        "description": "A heartfelt wish inspires positive action and change.",
        "bestAdventureTriggers": [
          "Wish Made",
          "Blessing Received",
          "Hope Needed"
        ],
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "Hopelessness → Hope"
        ],
        "bestStoryWorlds": [
          "Temple",
          "Village",
          "Garden"
        ],
        "notes": "The wish inspires effort—it never grants success directly"
      },
      {
        "id": 61,
        "slug": "dream-adventure",
        "name": "Dream Adventure",
        "description": "A dream reveals insight that helps solve a real-life problem.",
        "bestAdventureTriggers": [
          "Meaningful Dream",
          "Restful Sleep",
          "Night Reflection"
        ],
        "bestStoryStructures": [
          "Dream Story"
        ],
        "bestEmotionalArcs": [
          "Confusion → Clarity"
        ],
        "bestStoryWorlds": [
          "Dream World",
          "Forest",
          "Story House"
        ],
        "notes": "Dream provides insight only"
      },
      {
        "id": 62,
        "slug": "time-adventure",
        "name": "Time Adventure",
        "description": "Complete a mission before time runs out.",
        "bestAdventureTriggers": [
          "Before Sunset",
          "Rising River",
          "Festival Starts Soon"
        ],
        "bestStoryStructures": [
          "Time Challenge Story"
        ],
        "bestEmotionalArcs": [
          "Anxiety → Determination"
        ],
        "bestStoryWorlds": [
          "Forest",
          "River",
          "Village"
        ],
        "notes": "High pacing"
      },
      {
        "id": 63,
        "slug": "choice-consequence",
        "name": "Choice & Consequence",
        "description": "A difficult choice shapes the outcome of the story.",
        "bestAdventureTriggers": [
          "Two Paths",
          "Moral Dilemma",
          "Temptation"
        ],
        "bestStoryStructures": [
          "Choice Story"
        ],
        "bestEmotionalArcs": [
          "Confusion → Wisdom"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "notes": "Decisions drive the story"
      },
      {
        "id": 64,
        "slug": "promise-keeper",
        "name": "Promise Keeper",
        "description": "Honour an important promise through action.",
        "bestAdventureTriggers": [
          "Promise Made",
          "Trust Given",
          "Important Responsibility"
        ],
        "bestStoryStructures": [
          "Promise Story"
        ],
        "bestEmotionalArcs": [
          "Responsibility → Integrity"
        ],
        "bestStoryWorlds": [
          "Village",
          "Forest",
          "Home"
        ],
        "notes": "Builds trust and reliability"
      },
      {
        "id": 65,
        "slug": "unexpected-surprise",
        "name": "Unexpected Surprise",
        "description": "An unexpected event changes the direction of the adventure.",
        "bestAdventureTriggers": [
          "Surprise Visitor",
          "Hidden Discovery",
          "Sudden Change"
        ],
        "bestStoryStructures": [
          "Twist Story"
        ],
        "bestEmotionalArcs": [
          "Expectation → Delight"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "notes": "Best used as a mid-story twist or ending reveal"
      }
    ],
    "adventureTriggers": [
      {
        "id": 1,
        "archetype": "Rescue Mission",
        "name": "Someone is trapped."
      },
      {
        "id": 2,
        "archetype": "Rescue Mission",
        "name": "Someone has gone missing."
      },
      {
        "id": 3,
        "archetype": "Rescue Mission",
        "name": "A young creature is separated from its family."
      },
      {
        "id": 4,
        "archetype": "Rescue Mission",
        "name": "A cry for help echoes nearby."
      },
      {
        "id": 5,
        "archetype": "Rescue Mission",
        "name": "A dangerous situation is getting worse."
      },
      {
        "id": 6,
        "archetype": "Rescue Mission",
        "name": "An important rescue must happen before sunset."
      },
      {
        "id": 7,
        "archetype": "Rescue Mission",
        "name": "A safe path suddenly disappears."
      },
      {
        "id": 8,
        "archetype": "Rescue Mission",
        "name": "Someone cannot escape without help."
      },
      {
        "id": 9,
        "archetype": "Guardian Adventure",
        "name": "Someone asks you to protect something precious."
      },
      {
        "id": 10,
        "archetype": "Guardian Adventure",
        "name": "A younger companion depends on you."
      },
      {
        "id": 11,
        "archetype": "Guardian Adventure",
        "name": "Danger begins approaching a peaceful place."
      },
      {
        "id": 12,
        "archetype": "Guardian Adventure",
        "name": "An important object attracts unwanted attention."
      },
      {
        "id": 13,
        "archetype": "Guardian Adventure",
        "name": "A promise to protect must be honored."
      },
      {
        "id": 14,
        "archetype": "Guardian Adventure",
        "name": "A safe place becomes unsafe."
      },
      {
        "id": 15,
        "archetype": "Guardian Adventure",
        "name": "Someone is too small to protect themselves."
      },
      {
        "id": 16,
        "archetype": "Guardian Adventure",
        "name": "Staying watchful becomes the biggest challenge."
      },
      {
        "id": 17,
        "archetype": "Escape Adventure",
        "name": "The only exit suddenly closes."
      },
      {
        "id": 18,
        "archetype": "Escape Adventure",
        "name": "Time begins running out."
      },
      {
        "id": 19,
        "archetype": "Escape Adventure",
        "name": "A dangerous place must be escaped."
      },
      {
        "id": 20,
        "archetype": "Escape Adventure",
        "name": "The group becomes trapped."
      },
      {
        "id": 21,
        "archetype": "Escape Adventure",
        "name": "A wrong turn leads into trouble."
      },
      {
        "id": 22,
        "archetype": "Escape Adventure",
        "name": "The safest route disappears."
      },
      {
        "id": 23,
        "archetype": "Escape Adventure",
        "name": "A hidden exit may exist."
      },
      {
        "id": 24,
        "archetype": "Escape Adventure",
        "name": "Every decision changes the escape."
      },
      {
        "id": 25,
        "archetype": "Survival Adventure",
        "name": "Shelter is suddenly lost."
      },
      {
        "id": 26,
        "archetype": "Survival Adventure",
        "name": "Supplies begin running out."
      },
      {
        "id": 27,
        "archetype": "Survival Adventure",
        "name": "Nature becomes unpredictable."
      },
      {
        "id": 28,
        "archetype": "Survival Adventure",
        "name": "The group becomes stranded."
      },
      {
        "id": 29,
        "archetype": "Survival Adventure",
        "name": "Food or water is difficult to find."
      },
      {
        "id": 30,
        "archetype": "Survival Adventure",
        "name": "Weather creates unexpected danger."
      },
      {
        "id": 31,
        "archetype": "Survival Adventure",
        "name": "Help is too far away."
      },
      {
        "id": 32,
        "archetype": "Survival Adventure",
        "name": "Working together becomes essential."
      },
      {
        "id": 33,
        "archetype": "Delivery Quest",
        "name": "An important message must be delivered."
      },
      {
        "id": 34,
        "archetype": "Delivery Quest",
        "name": "A special gift needs to reach someone."
      },
      {
        "id": 35,
        "archetype": "Delivery Quest",
        "name": "Medicine is urgently needed."
      },
      {
        "id": 36,
        "archetype": "Delivery Quest",
        "name": "A promise depends on making the delivery."
      },
      {
        "id": 37,
        "archetype": "Delivery Quest",
        "name": "The shortest route becomes impossible."
      },
      {
        "id": 38,
        "archetype": "Delivery Quest",
        "name": "The package is accidentally misplaced."
      },
      {
        "id": 39,
        "archetype": "Delivery Quest",
        "name": "Someone is waiting and cannot leave."
      },
      {
        "id": 40,
        "archetype": "Delivery Quest",
        "name": "Every delay makes the mission harder."
      },
      {
        "id": 41,
        "archetype": "Mystery to Solve",
        "name": "Something disappears without explanation."
      },
      {
        "id": 42,
        "archetype": "Mystery to Solve",
        "name": "Strange clues begin appearing."
      },
      {
        "id": 43,
        "archetype": "Mystery to Solve",
        "name": "Nobody knows what really happened."
      },
      {
        "id": 44,
        "archetype": "Mystery to Solve",
        "name": "Everyone remembers the story differently."
      },
      {
        "id": 45,
        "archetype": "Mystery to Solve",
        "name": "Something important is out of place."
      },
      {
        "id": 46,
        "archetype": "Mystery to Solve",
        "name": "A secret message is discovered."
      },
      {
        "id": 47,
        "archetype": "Mystery to Solve",
        "name": "Strange sounds are heard every night."
      },
      {
        "id": 48,
        "archetype": "Mystery to Solve",
        "name": "The final clue is hiding in plain sight."
      },
      {
        "id": 49,
        "archetype": "Detective Story",
        "name": "A tiny clue is overlooked."
      },
      {
        "id": 50,
        "archetype": "Detective Story",
        "name": "A valuable object goes missing."
      },
      {
        "id": 51,
        "archetype": "Detective Story",
        "name": "Someone's story doesn't match the facts."
      },
      {
        "id": 52,
        "archetype": "Detective Story",
        "name": "A trail suddenly ends."
      },
      {
        "id": 53,
        "archetype": "Detective Story",
        "name": "Strange footprints appear."
      },
      {
        "id": 54,
        "archetype": "Detective Story",
        "name": "An unusual pattern keeps repeating."
      },
      {
        "id": 55,
        "archetype": "Detective Story",
        "name": "A witness remembers one important detail."
      },
      {
        "id": 56,
        "archetype": "Detective Story",
        "name": "Solving the puzzle will help everyone."
      },
      {
        "id": 57,
        "archetype": "Treasure Hunt",
        "name": "An old map is discovered."
      },
      {
        "id": 58,
        "archetype": "Treasure Hunt",
        "name": "A mysterious clue appears."
      },
      {
        "id": 59,
        "archetype": "Treasure Hunt",
        "name": "Pieces of something valuable are scattered."
      },
      {
        "id": 60,
        "archetype": "Treasure Hunt",
        "name": "A forgotten legend points somewhere."
      },
      {
        "id": 61,
        "archetype": "Treasure Hunt",
        "name": "A hidden path is uncovered."
      },
      {
        "id": 62,
        "archetype": "Treasure Hunt",
        "name": "A riddle reveals the next step."
      },
      {
        "id": 63,
        "archetype": "Treasure Hunt",
        "name": "Every clue becomes harder to solve."
      },
      {
        "id": 64,
        "archetype": "Treasure Hunt",
        "name": "The final treasure isn't what anyone expected."
      },
      {
        "id": 65,
        "archetype": "Secret Discovery",
        "name": "A hidden door appears."
      },
      {
        "id": 66,
        "archetype": "Secret Discovery",
        "name": "Something forgotten is uncovered."
      },
      {
        "id": 67,
        "archetype": "Secret Discovery",
        "name": "An unusual object is found."
      },
      {
        "id": 68,
        "archetype": "Secret Discovery",
        "name": "A secret has been waiting for years."
      },
      {
        "id": 69,
        "archetype": "Secret Discovery",
        "name": "Curiosity leads somewhere unexpected."
      },
      {
        "id": 70,
        "archetype": "Secret Discovery",
        "name": "An old mystery returns."
      },
      {
        "id": 71,
        "archetype": "Secret Discovery",
        "name": "Something ordinary reveals an extraordinary secret."
      },
      {
        "id": 72,
        "archetype": "Secret Discovery",
        "name": "The discovery changes everything."
      },
      {
        "id": 73,
        "archetype": "Hidden World",
        "name": "A secret entrance opens."
      },
      {
        "id": 74,
        "archetype": "Hidden World",
        "name": "Someone accidentally crosses into another world."
      },
      {
        "id": 75,
        "archetype": "Hidden World",
        "name": "A hidden community needs help."
      },
      {
        "id": 76,
        "archetype": "Hidden World",
        "name": "The secret place is disappearing."
      },
      {
        "id": 77,
        "archetype": "Hidden World",
        "name": "Someone discovers its existence."
      },
      {
        "id": 78,
        "archetype": "Hidden World",
        "name": "A forgotten guardian appears."
      },
      {
        "id": 79,
        "archetype": "Hidden World",
        "name": "The way back is no longer obvious."
      },
      {
        "id": 80,
        "archetype": "Hidden World",
        "name": "Keeping the secret becomes important."
      },
      {
        "id": 81,
        "archetype": "Great Journey",
        "name": "A destination must be reached."
      },
      {
        "id": 82,
        "archetype": "Great Journey",
        "name": "Someone asks for help far away."
      },
      {
        "id": 83,
        "archetype": "Great Journey",
        "name": "A journey begins unexpectedly."
      },
      {
        "id": 84,
        "archetype": "Great Journey",
        "name": "Home cannot be reached the usual way."
      },
      {
        "id": 85,
        "archetype": "Great Journey",
        "name": "A shortcut becomes an adventure."
      },
      {
        "id": 86,
        "archetype": "Great Journey",
        "name": "The map proves unreliable."
      },
      {
        "id": 87,
        "archetype": "Great Journey",
        "name": "Every stop teaches something new."
      },
      {
        "id": 88,
        "archetype": "Great Journey",
        "name": "Reaching the destination changes the traveler."
      },
      {
        "id": 89,
        "archetype": "Expedition",
        "name": "An unexplored place is discovered."
      },
      {
        "id": 90,
        "archetype": "Expedition",
        "name": "A rare sighting is reported."
      },
      {
        "id": 91,
        "archetype": "Expedition",
        "name": "Something valuable may be hidden there."
      },
      {
        "id": 92,
        "archetype": "Expedition",
        "name": "The journey requires careful planning."
      },
      {
        "id": 93,
        "archetype": "Expedition",
        "name": "Nature blocks the easiest route."
      },
      {
        "id": 94,
        "archetype": "Expedition",
        "name": "A guide is needed."
      },
      {
        "id": 95,
        "archetype": "Expedition",
        "name": "Every step uncovers something new."
      },
      {
        "id": 96,
        "archetype": "Expedition",
        "name": "The expedition reveals more than expected."
      },
      {
        "id": 97,
        "archetype": "Find the Way Home",
        "name": "Someone becomes separated from the group."
      },
      {
        "id": 98,
        "archetype": "Find the Way Home",
        "name": "Familiar landmarks disappear."
      },
      {
        "id": 99,
        "archetype": "Find the Way Home",
        "name": "The usual path is blocked."
      },
      {
        "id": 100,
        "archetype": "Find the Way Home",
        "name": "A guide goes missing."
      },
      {
        "id": 101,
        "archetype": "Find the Way Home",
        "name": "Darkness arrives too soon."
      },
      {
        "id": 102,
        "archetype": "Find the Way Home",
        "name": "A map is lost."
      },
      {
        "id": 103,
        "archetype": "Find the Way Home",
        "name": "Every direction looks the same."
      },
      {
        "id": 104,
        "archetype": "Find the Way Home",
        "name": "Home can only be reached by helping someone else first."
      },
      {
        "id": 105,
        "archetype": "Escort Mission",
        "name": "Someone cannot travel alone."
      },
      {
        "id": 106,
        "archetype": "Escort Mission",
        "name": "A younger companion needs guidance."
      },
      {
        "id": 107,
        "archetype": "Escort Mission",
        "name": "A visitor needs help reaching safety."
      },
      {
        "id": 108,
        "archetype": "Escort Mission",
        "name": "The journey becomes more dangerous than expected."
      },
      {
        "id": 109,
        "archetype": "Escort Mission",
        "name": "The companion has an important secret."
      },
      {
        "id": 110,
        "archetype": "Escort Mission",
        "name": "The safest route suddenly changes."
      },
      {
        "id": 111,
        "archetype": "Escort Mission",
        "name": "Trust grows along the journey."
      },
      {
        "id": 112,
        "archetype": "Escort Mission",
        "name": "Reaching the destination is only half the mission."
      },
      {
        "id": 113,
        "archetype": "Race Against Time",
        "name": "Something important must happen before sunset."
      },
      {
        "id": 114,
        "archetype": "Race Against Time",
        "name": "Every minute counts."
      },
      {
        "id": 115,
        "archetype": "Race Against Time",
        "name": "A deadline is fast approaching."
      },
      {
        "id": 116,
        "archetype": "Race Against Time",
        "name": "Someone needs help immediately."
      },
      {
        "id": 117,
        "archetype": "Race Against Time",
        "name": "A natural event is about to begin."
      },
      {
        "id": 118,
        "archetype": "Race Against Time",
        "name": "Waiting is no longer an option."
      },
      {
        "id": 119,
        "archetype": "Race Against Time",
        "name": "One delay creates another."
      },
      {
        "id": 120,
        "archetype": "Race Against Time",
        "name": "Success depends on perfect timing."
      },
      {
        "id": 121,
        "archetype": "Friendship Repair",
        "name": "Two friends stop talking."
      },
      {
        "id": 122,
        "archetype": "Friendship Repair",
        "name": "Someone feels left out."
      },
      {
        "id": 123,
        "archetype": "Friendship Repair",
        "name": "A misunderstanding grows bigger."
      },
      {
        "id": 124,
        "archetype": "Friendship Repair",
        "name": "A promise is accidentally broken."
      },
      {
        "id": 125,
        "archetype": "Friendship Repair",
        "name": "Hurt feelings remain unspoken."
      },
      {
        "id": 126,
        "archetype": "Friendship Repair",
        "name": "An apology needs courage."
      },
      {
        "id": 127,
        "archetype": "Friendship Repair",
        "name": "Trust has to be rebuilt."
      },
      {
        "id": 128,
        "archetype": "Friendship Repair",
        "name": "Working together becomes unavoidable."
      },
      {
        "id": 129,
        "archetype": "New Friend",
        "name": "A newcomer arrives."
      },
      {
        "id": 130,
        "archetype": "New Friend",
        "name": "Someone is sitting alone."
      },
      {
        "id": 131,
        "archetype": "New Friend",
        "name": "Two strangers meet unexpectedly."
      },
      {
        "id": 132,
        "archetype": "New Friend",
        "name": "A shared problem brings two children together."
      },
      {
        "id": 133,
        "archetype": "New Friend",
        "name": "A misunderstanding creates distance."
      },
      {
        "id": 134,
        "archetype": "New Friend",
        "name": "Different personalities must cooperate."
      },
      {
        "id": 135,
        "archetype": "New Friend",
        "name": "A kind act starts a friendship."
      },
      {
        "id": 136,
        "archetype": "New Friend",
        "name": "Saying hello changes everything."
      },
      {
        "id": 137,
        "archetype": "Second Chance",
        "name": "A mistake deserves another opportunity."
      },
      {
        "id": 138,
        "archetype": "Second Chance",
        "name": "Trust is slowly returning."
      },
      {
        "id": 139,
        "archetype": "Second Chance",
        "name": "Someone wants to make things right."
      },
      {
        "id": 140,
        "archetype": "Second Chance",
        "name": "A new opportunity appears unexpectedly."
      },
      {
        "id": 141,
        "archetype": "Second Chance",
        "name": "Past mistakes create fresh challenges."
      },
      {
        "id": 142,
        "archetype": "Second Chance",
        "name": "Actions matter more than words."
      },
      {
        "id": 143,
        "archetype": "Second Chance",
        "name": "Forgiveness must be earned."
      },
      {
        "id": 144,
        "archetype": "Second Chance",
        "name": "A better choice changes the ending."
      },
      {
        "id": 145,
        "archetype": "Helping Hand",
        "name": "Someone quietly needs help."
      },
      {
        "id": 146,
        "archetype": "Helping Hand",
        "name": "A difficult task is too big for one person."
      },
      {
        "id": 147,
        "archetype": "Helping Hand",
        "name": "A small act of kindness makes a difference."
      },
      {
        "id": 148,
        "archetype": "Helping Hand",
        "name": "Someone asks for help for the first time."
      },
      {
        "id": 149,
        "archetype": "Helping Hand",
        "name": "A problem affects everyone."
      },
      {
        "id": 150,
        "archetype": "Helping Hand",
        "name": "Helping requires giving up something."
      },
      {
        "id": 151,
        "archetype": "Helping Hand",
        "name": "Unexpected helpers appear."
      },
      {
        "id": 152,
        "archetype": "Helping Hand",
        "name": "Kindness spreads from one person to another."
      },
      {
        "id": 153,
        "archetype": "Journey Together",
        "name": "Two very different companions must travel together."
      },
      {
        "id": 154,
        "archetype": "Journey Together",
        "name": "A shared destination brings strangers together."
      },
      {
        "id": 155,
        "archetype": "Journey Together",
        "name": "One traveler knows the way."
      },
      {
        "id": 156,
        "archetype": "Journey Together",
        "name": "Both travelers need each other in different ways."
      },
      {
        "id": 157,
        "archetype": "Journey Together",
        "name": "The journey tests the friendship."
      },
      {
        "id": 158,
        "archetype": "Journey Together",
        "name": "The path is harder than expected."
      },
      {
        "id": 159,
        "archetype": "Journey Together",
        "name": "Helping each other becomes essential."
      },
      {
        "id": 160,
        "archetype": "Journey Together",
        "name": "They arrive as different people than when they started."
      },
      {
        "id": 161,
        "archetype": "Team Adventure",
        "name": "One person cannot solve the problem alone."
      },
      {
        "id": 162,
        "archetype": "Team Adventure",
        "name": "Everyone has a different strength."
      },
      {
        "id": 163,
        "archetype": "Team Adventure",
        "name": "The team disagrees on the plan."
      },
      {
        "id": 164,
        "archetype": "Team Adventure",
        "name": "Success depends on cooperation."
      },
      {
        "id": 165,
        "archetype": "Team Adventure",
        "name": "Every member gets an important role."
      },
      {
        "id": 166,
        "archetype": "Team Adventure",
        "name": "A setback tests the team."
      },
      {
        "id": 167,
        "archetype": "Team Adventure",
        "name": "Someone feels they aren't needed."
      },
      {
        "id": 168,
        "archetype": "Team Adventure",
        "name": "Working together achieves the impossible."
      },
      {
        "id": 169,
        "archetype": "Community Project",
        "name": "The whole community needs help."
      },
      {
        "id": 170,
        "archetype": "Community Project",
        "name": "A place needs rebuilding."
      },
      {
        "id": 171,
        "archetype": "Community Project",
        "name": "Everyone contributes differently."
      },
      {
        "id": 172,
        "archetype": "Community Project",
        "name": "Resources are limited."
      },
      {
        "id": 173,
        "archetype": "Community Project",
        "name": "People disagree on the best solution."
      },
      {
        "id": 174,
        "archetype": "Community Project",
        "name": "Unexpected volunteers arrive."
      },
      {
        "id": 175,
        "archetype": "Community Project",
        "name": "A setback delays the work."
      },
      {
        "id": 176,
        "archetype": "Community Project",
        "name": "The finished project brings everyone together."
      },
      {
        "id": 177,
        "archetype": "Leadership Challenge",
        "name": "Nobody knows what to do."
      },
      {
        "id": 178,
        "archetype": "Leadership Challenge",
        "name": "A leader is suddenly needed."
      },
      {
        "id": 179,
        "archetype": "Leadership Challenge",
        "name": "Everyone has different opinions."
      },
      {
        "id": 180,
        "archetype": "Leadership Challenge",
        "name": "A difficult decision must be made."
      },
      {
        "id": 181,
        "archetype": "Leadership Challenge",
        "name": "Confidence begins to fade."
      },
      {
        "id": 182,
        "archetype": "Leadership Challenge",
        "name": "A quiet child steps forward."
      },
      {
        "id": 183,
        "archetype": "Leadership Challenge",
        "name": "Responsibility feels overwhelming."
      },
      {
        "id": 184,
        "archetype": "Leadership Challenge",
        "name": "Good leadership inspires others to lead."
      },
      {
        "id": 185,
        "archetype": "Shared Mission",
        "name": "Several groups have the same goal."
      },
      {
        "id": 186,
        "archetype": "Shared Mission",
        "name": "Different talents must be combined."
      },
      {
        "id": 187,
        "archetype": "Shared Mission",
        "name": "Success depends on everyone contributing."
      },
      {
        "id": 188,
        "archetype": "Shared Mission",
        "name": "Helping others helps yourself."
      },
      {
        "id": 189,
        "archetype": "Shared Mission",
        "name": "Someone must coordinate the effort."
      },
      {
        "id": 190,
        "archetype": "Shared Mission",
        "name": "A setback affects everyone equally."
      },
      {
        "id": 191,
        "archetype": "Shared Mission",
        "name": "Sharing resources becomes necessary."
      },
      {
        "id": 192,
        "archetype": "Shared Mission",
        "name": "The mission succeeds because nobody works alone."
      },
      {
        "id": 193,
        "archetype": "Build Together",
        "name": "Something important needs building."
      },
      {
        "id": 194,
        "archetype": "Build Together",
        "name": "Something valuable is broken."
      },
      {
        "id": 195,
        "archetype": "Build Together",
        "name": "A new idea needs creating."
      },
      {
        "id": 196,
        "archetype": "Build Together",
        "name": "Materials are difficult to find."
      },
      {
        "id": 197,
        "archetype": "Build Together",
        "name": "Everyone contributes one piece."
      },
      {
        "id": 198,
        "archetype": "Build Together",
        "name": "The design doesn't work at first."
      },
      {
        "id": 199,
        "archetype": "Build Together",
        "name": "Nature creates an unexpected obstacle."
      },
      {
        "id": 200,
        "archetype": "Build Together",
        "name": "The finished creation solves a much bigger problem."
      },
      {
        "id": 201,
        "archetype": "Hero's Trial",
        "name": "Three difficult challenges must be completed."
      },
      {
        "id": 202,
        "archetype": "Hero's Trial",
        "name": "Courage is tested before strength."
      },
      {
        "id": 203,
        "archetype": "Hero's Trial",
        "name": "Every success unlocks the next challenge."
      },
      {
        "id": 204,
        "archetype": "Hero's Trial",
        "name": "Giving up becomes tempting."
      },
      {
        "id": 205,
        "archetype": "Hero's Trial",
        "name": "Someone weaker needs help during the trial."
      },
      {
        "id": 206,
        "archetype": "Hero's Trial",
        "name": "The hardest challenge is inside yourself."
      },
      {
        "id": 207,
        "archetype": "Hero's Trial",
        "name": "Pride becomes the biggest obstacle."
      },
      {
        "id": 208,
        "archetype": "Hero's Trial",
        "name": "The final reward is wisdom, not victory."
      },
      {
        "id": 209,
        "archetype": "Final Challenge",
        "name": "Everything depends on one last attempt."
      },
      {
        "id": 210,
        "archetype": "Final Challenge",
        "name": "One final obstacle blocks success."
      },
      {
        "id": 211,
        "archetype": "Final Challenge",
        "name": "All previous lessons are needed."
      },
      {
        "id": 212,
        "archetype": "Final Challenge",
        "name": "The easiest choice is the wrong one."
      },
      {
        "id": 213,
        "archetype": "Final Challenge",
        "name": "Friends arrive just in time."
      },
      {
        "id": 214,
        "archetype": "Final Challenge",
        "name": "Confidence begins to disappear."
      },
      {
        "id": 215,
        "archetype": "Final Challenge",
        "name": "A surprising solution appears."
      },
      {
        "id": 216,
        "archetype": "Final Challenge",
        "name": "The ending depends on one brave decision."
      },
      {
        "id": 217,
        "archetype": "Training Journey",
        "name": "A new skill must be learned."
      },
      {
        "id": 218,
        "archetype": "Training Journey",
        "name": "Practice feels frustrating."
      },
      {
        "id": 219,
        "archetype": "Training Journey",
        "name": "A mentor gives a difficult challenge."
      },
      {
        "id": 220,
        "archetype": "Training Journey",
        "name": "Improvement happens slowly."
      },
      {
        "id": 221,
        "archetype": "Training Journey",
        "name": "A setback tests determination."
      },
      {
        "id": 222,
        "archetype": "Training Journey",
        "name": "Confidence grows little by little."
      },
      {
        "id": 223,
        "archetype": "Training Journey",
        "name": "The training prepares for something unexpected."
      },
      {
        "id": 224,
        "archetype": "Training Journey",
        "name": "The real lesson isn't the skill itself."
      },
      {
        "id": 225,
        "archetype": "Problem Solver",
        "name": "A problem affects everyone."
      },
      {
        "id": 226,
        "archetype": "Problem Solver",
        "name": "Every obvious solution fails."
      },
      {
        "id": 227,
        "archetype": "Problem Solver",
        "name": "A clever idea changes everything."
      },
      {
        "id": 228,
        "archetype": "Problem Solver",
        "name": "Small clues point toward the answer."
      },
      {
        "id": 229,
        "archetype": "Problem Solver",
        "name": "Different opinions create confusion."
      },
      {
        "id": 230,
        "archetype": "Problem Solver",
        "name": "Trial and error lead to progress."
      },
      {
        "id": 231,
        "archetype": "Problem Solver",
        "name": "Teamwork reveals the solution."
      },
      {
        "id": 232,
        "archetype": "Problem Solver",
        "name": "Solving one problem uncovers another opportunity."
      },
      {
        "id": 233,
        "archetype": "Responsibility Quest",
        "name": "An important duty is entrusted to someone."
      },
      {
        "id": 234,
        "archetype": "Responsibility Quest",
        "name": "A promise must be kept."
      },
      {
        "id": 235,
        "archetype": "Responsibility Quest",
        "name": "Looking after something becomes harder than expected."
      },
      {
        "id": 236,
        "archetype": "Responsibility Quest",
        "name": "A careless mistake has consequences."
      },
      {
        "id": 237,
        "archetype": "Responsibility Quest",
        "name": "Choosing responsibility means giving something up."
      },
      {
        "id": 238,
        "archetype": "Responsibility Quest",
        "name": "Others begin depending on them."
      },
      {
        "id": 239,
        "archetype": "Responsibility Quest",
        "name": "Doing the right thing isn't the easiest choice."
      },
      {
        "id": 240,
        "archetype": "Responsibility Quest",
        "name": "Responsibility earns trust and respect."
      },
      {
        "id": 241,
        "archetype": "Invention Story",
        "name": "An everyday problem needs a new solution."
      },
      {
        "id": 242,
        "archetype": "Invention Story",
        "name": "An old invention inspires a new idea."
      },
      {
        "id": 243,
        "archetype": "Invention Story",
        "name": "A tool suddenly stops working."
      },
      {
        "id": 244,
        "archetype": "Invention Story",
        "name": "Different ideas compete."
      },
      {
        "id": 245,
        "archetype": "Invention Story",
        "name": "An experiment fails unexpectedly."
      },
      {
        "id": 246,
        "archetype": "Invention Story",
        "name": "A small discovery becomes important."
      },
      {
        "id": 247,
        "archetype": "Invention Story",
        "name": "Limited materials force creativity."
      },
      {
        "id": 248,
        "archetype": "Invention Story",
        "name": "The invention solves a bigger problem."
      },
      {
        "id": 249,
        "archetype": "Restoration Story",
        "name": "Something beautiful has been damaged."
      },
      {
        "id": 250,
        "archetype": "Restoration Story",
        "name": "A special place has been forgotten."
      },
      {
        "id": 251,
        "archetype": "Restoration Story",
        "name": "An important object breaks."
      },
      {
        "id": 252,
        "archetype": "Restoration Story",
        "name": "Nature needs healing."
      },
      {
        "id": 253,
        "archetype": "Restoration Story",
        "name": "Hope begins to disappear."
      },
      {
        "id": 254,
        "archetype": "Restoration Story",
        "name": "Small repairs make a big difference."
      },
      {
        "id": 255,
        "archetype": "Restoration Story",
        "name": "Everyone contributes one part."
      },
      {
        "id": 256,
        "archetype": "Restoration Story",
        "name": "Restoring something restores friendships too."
      },
      {
        "id": 257,
        "archetype": "Creative Quest",
        "name": "A blank space needs imagination."
      },
      {
        "id": 258,
        "archetype": "Creative Quest",
        "name": "A celebration needs something special."
      },
      {
        "id": 259,
        "archetype": "Creative Quest",
        "name": "Inspiration suddenly disappears."
      },
      {
        "id": 260,
        "archetype": "Creative Quest",
        "name": "Different ideas clash."
      },
      {
        "id": 261,
        "archetype": "Creative Quest",
        "name": "A creative mistake becomes an opportunity."
      },
      {
        "id": 262,
        "archetype": "Creative Quest",
        "name": "Nature inspires a solution."
      },
      {
        "id": 263,
        "archetype": "Creative Quest",
        "name": "Working together creates something unique."
      },
      {
        "id": 264,
        "archetype": "Creative Quest",
        "name": "The finished creation surprises everyone."
      },
      {
        "id": 265,
        "archetype": "Build & Repair",
        "name": "Something essential breaks."
      },
      {
        "id": 266,
        "archetype": "Build & Repair",
        "name": "A structure becomes unsafe."
      },
      {
        "id": 267,
        "archetype": "Build & Repair",
        "name": "Missing pieces must be found."
      },
      {
        "id": 268,
        "archetype": "Build & Repair",
        "name": "A repair must happen before time runs out."
      },
      {
        "id": 269,
        "archetype": "Build & Repair",
        "name": "Working alone isn't enough."
      },
      {
        "id": 270,
        "archetype": "Build & Repair",
        "name": "Unexpected damage appears."
      },
      {
        "id": 271,
        "archetype": "Build & Repair",
        "name": "Creative materials replace missing ones."
      },
      {
        "id": 272,
        "archetype": "Build & Repair",
        "name": "The repaired object becomes even better."
      },
      {
        "id": 273,
        "archetype": "Transformation Story",
        "name": "Someone gets an unexpected opportunity."
      },
      {
        "id": 274,
        "archetype": "Transformation Story",
        "name": "A place begins changing."
      },
      {
        "id": 275,
        "archetype": "Transformation Story",
        "name": "A small act starts a big change."
      },
      {
        "id": 276,
        "archetype": "Transformation Story",
        "name": "Fear prevents growth."
      },
      {
        "id": 277,
        "archetype": "Transformation Story",
        "name": "Kindness transforms the situation."
      },
      {
        "id": 278,
        "archetype": "Transformation Story",
        "name": "A hidden talent emerges."
      },
      {
        "id": 279,
        "archetype": "Transformation Story",
        "name": "Old habits no longer work."
      },
      {
        "id": 280,
        "archetype": "Transformation Story",
        "name": "The greatest transformation happens inside."
      },
      {
        "id": 281,
        "archetype": "Mentor Journey",
        "name": "A wise guide appears unexpectedly."
      },
      {
        "id": 282,
        "archetype": "Mentor Journey",
        "name": "A difficult lesson blocks progress."
      },
      {
        "id": 283,
        "archetype": "Mentor Journey",
        "name": "Practice becomes the only path forward."
      },
      {
        "id": 284,
        "archetype": "Mentor Journey",
        "name": "The mentor gives very little help."
      },
      {
        "id": 285,
        "archetype": "Mentor Journey",
        "name": "Confidence is tested."
      },
      {
        "id": 286,
        "archetype": "Mentor Journey",
        "name": "The mentor suddenly disappears."
      },
      {
        "id": 287,
        "archetype": "Mentor Journey",
        "name": "The student must teach someone else."
      },
      {
        "id": 288,
        "archetype": "Mentor Journey",
        "name": "The final lesson is discovered independently."
      },
      {
        "id": 289,
        "archetype": "Learning Quest",
        "name": "A new skill becomes necessary."
      },
      {
        "id": 290,
        "archetype": "Learning Quest",
        "name": "A difficult question appears."
      },
      {
        "id": 291,
        "archetype": "Learning Quest",
        "name": "Curiosity starts the adventure."
      },
      {
        "id": 292,
        "archetype": "Learning Quest",
        "name": "Every mistake teaches something useful."
      },
      {
        "id": 293,
        "archetype": "Learning Quest",
        "name": "Learning unlocks the next step."
      },
      {
        "id": 294,
        "archetype": "Learning Quest",
        "name": "A puzzle cannot be solved without knowledge."
      },
      {
        "id": 295,
        "archetype": "Learning Quest",
        "name": "Someone unexpected becomes the teacher."
      },
      {
        "id": 296,
        "archetype": "Learning Quest",
        "name": "The lesson changes future choices."
      },
      {
        "id": 297,
        "archetype": "Discovery Journey",
        "name": "Curiosity leads somewhere unexpected."
      },
      {
        "id": 298,
        "archetype": "Discovery Journey",
        "name": "Something forgotten is rediscovered."
      },
      {
        "id": 299,
        "archetype": "Discovery Journey",
        "name": "A hidden clue changes everything."
      },
      {
        "id": 300,
        "archetype": "Discovery Journey",
        "name": "Every answer raises another question."
      },
      {
        "id": 301,
        "archetype": "Discovery Journey",
        "name": "A surprising connection is revealed."
      },
      {
        "id": 302,
        "archetype": "Discovery Journey",
        "name": "A journey uncovers forgotten history."
      },
      {
        "id": 303,
        "archetype": "Discovery Journey",
        "name": "The discovery helps others."
      },
      {
        "id": 304,
        "archetype": "Discovery Journey",
        "name": "Knowledge becomes the greatest treasure."
      },
      {
        "id": 305,
        "archetype": "Wisdom Challenge",
        "name": "Two choices both seem right."
      },
      {
        "id": 306,
        "archetype": "Wisdom Challenge",
        "name": "A difficult decision affects everyone."
      },
      {
        "id": 307,
        "archetype": "Wisdom Challenge",
        "name": "Listening becomes more important than speaking."
      },
      {
        "id": 308,
        "archetype": "Wisdom Challenge",
        "name": "Patience reveals the answer."
      },
      {
        "id": 309,
        "archetype": "Wisdom Challenge",
        "name": "A simple solution is overlooked."
      },
      {
        "id": 310,
        "archetype": "Wisdom Challenge",
        "name": "Someone asks for wise advice."
      },
      {
        "id": 311,
        "archetype": "Wisdom Challenge",
        "name": "Kindness solves the problem."
      },
      {
        "id": 312,
        "archetype": "Wisdom Challenge",
        "name": "Wisdom changes the outcome."
      },
      {
        "id": 313,
        "archetype": "Teaching Adventure",
        "name": "Someone wants to learn."
      },
      {
        "id": 314,
        "archetype": "Teaching Adventure",
        "name": "A lesson must be shared."
      },
      {
        "id": 315,
        "archetype": "Teaching Adventure",
        "name": "The student learns differently."
      },
      {
        "id": 316,
        "archetype": "Teaching Adventure",
        "name": "Practice becomes difficult."
      },
      {
        "id": 317,
        "archetype": "Teaching Adventure",
        "name": "Teaching requires patience."
      },
      {
        "id": 318,
        "archetype": "Teaching Adventure",
        "name": "The teacher learns something too."
      },
      {
        "id": 319,
        "archetype": "Teaching Adventure",
        "name": "A mistake becomes the best lesson."
      },
      {
        "id": 320,
        "archetype": "Teaching Adventure",
        "name": "The student eventually teaches others."
      },
      {
        "id": 321,
        "archetype": "Festival Adventure",
        "name": "Festival preparations begin."
      },
      {
        "id": 322,
        "archetype": "Festival Adventure",
        "name": "A tradition is in danger."
      },
      {
        "id": 323,
        "archetype": "Festival Adventure",
        "name": "Guests arrive unexpectedly."
      },
      {
        "id": 324,
        "archetype": "Festival Adventure",
        "name": "Something important goes missing."
      },
      {
        "id": 325,
        "archetype": "Festival Adventure",
        "name": "Weather threatens the celebration."
      },
      {
        "id": 326,
        "archetype": "Festival Adventure",
        "name": "Everyone has a role."
      },
      {
        "id": 327,
        "archetype": "Festival Adventure",
        "name": "A surprise changes the festival."
      },
      {
        "id": 328,
        "archetype": "Festival Adventure",
        "name": "The celebration brings everyone together."
      },
      {
        "id": 329,
        "archetype": "Celebration Preparation",
        "name": "A special event is approaching."
      },
      {
        "id": 330,
        "archetype": "Celebration Preparation",
        "name": "Decorations need finishing."
      },
      {
        "id": 331,
        "archetype": "Celebration Preparation",
        "name": "A last-minute problem appears."
      },
      {
        "id": 332,
        "archetype": "Celebration Preparation",
        "name": "Time becomes short."
      },
      {
        "id": 333,
        "archetype": "Celebration Preparation",
        "name": "Friends work together."
      },
      {
        "id": 334,
        "archetype": "Celebration Preparation",
        "name": "Someone feels left out."
      },
      {
        "id": 335,
        "archetype": "Celebration Preparation",
        "name": "Preparations don't go as planned."
      },
      {
        "id": 336,
        "archetype": "Celebration Preparation",
        "name": "The celebration becomes unforgettable."
      },
      {
        "id": 337,
        "archetype": "Performance Story",
        "name": "A performance is announced."
      },
      {
        "id": 338,
        "archetype": "Performance Story",
        "name": "Stage fright appears."
      },
      {
        "id": 339,
        "archetype": "Performance Story",
        "name": "Practice goes poorly."
      },
      {
        "id": 340,
        "archetype": "Performance Story",
        "name": "The audience grows unexpectedly."
      },
      {
        "id": 341,
        "archetype": "Performance Story",
        "name": "The main performer cannot continue."
      },
      {
        "id": 342,
        "archetype": "Performance Story",
        "name": "A mistake happens on stage."
      },
      {
        "id": 343,
        "archetype": "Performance Story",
        "name": "Friends offer encouragement."
      },
      {
        "id": 344,
        "archetype": "Performance Story",
        "name": "Confidence shines brighter than perfection."
      },
      {
        "id": 345,
        "archetype": "Heritage Journey",
        "name": "An old family story is discovered."
      },
      {
        "id": 346,
        "archetype": "Heritage Journey",
        "name": "A forgotten tradition returns."
      },
      {
        "id": 347,
        "archetype": "Heritage Journey",
        "name": "A meaningful object is found."
      },
      {
        "id": 348,
        "archetype": "Heritage Journey",
        "name": "Elders share an important lesson."
      },
      {
        "id": 349,
        "archetype": "Heritage Journey",
        "name": "History holds the answer."
      },
      {
        "id": 350,
        "archetype": "Heritage Journey",
        "name": "A celebration honors the past."
      },
      {
        "id": 351,
        "archetype": "Heritage Journey",
        "name": "A forgotten place is revisited."
      },
      {
        "id": 352,
        "archetype": "Heritage Journey",
        "name": "The tradition gains new meaning."
      },
      {
        "id": 353,
        "archetype": "Gift of Giving",
        "name": "Someone needs encouragement."
      },
      {
        "id": 354,
        "archetype": "Gift of Giving",
        "name": "A thoughtful gift is planned."
      },
      {
        "id": 355,
        "archetype": "Gift of Giving",
        "name": "Kindness is returned unexpectedly."
      },
      {
        "id": 356,
        "archetype": "Gift of Giving",
        "name": "Giving requires sacrifice."
      },
      {
        "id": 357,
        "archetype": "Gift of Giving",
        "name": "A handmade gift becomes special."
      },
      {
        "id": 358,
        "archetype": "Gift of Giving",
        "name": "A surprise brightens someone's day."
      },
      {
        "id": 359,
        "archetype": "Gift of Giving",
        "name": "Generosity inspires others."
      },
      {
        "id": 360,
        "archetype": "Gift of Giving",
        "name": "The greatest gift isn't something you keep."
      },
      {
        "id": 361,
        "archetype": "Magical Discovery",
        "name": "Magic appears unexpectedly."
      },
      {
        "id": 362,
        "archetype": "Magical Discovery",
        "name": "A magical object awakens."
      },
      {
        "id": 363,
        "archetype": "Magical Discovery",
        "name": "A hidden power is revealed."
      },
      {
        "id": 364,
        "archetype": "Magical Discovery",
        "name": "A magical creature asks for help."
      },
      {
        "id": 365,
        "archetype": "Magical Discovery",
        "name": "A spell changes everything."
      },
      {
        "id": 366,
        "archetype": "Magical Discovery",
        "name": "Kindness unlocks magic."
      },
      {
        "id": 367,
        "archetype": "Magical Discovery",
        "name": "Magic creates an unexpected problem."
      },
      {
        "id": 368,
        "archetype": "Magical Discovery",
        "name": "Responsibility comes with magical power."
      },
      {
        "id": 369,
        "archetype": "Magical Quest",
        "name": "A magical mission begins."
      },
      {
        "id": 370,
        "archetype": "Magical Quest",
        "name": "Ancient magic needs restoring."
      },
      {
        "id": 371,
        "archetype": "Magical Quest",
        "name": "A magical guide appears."
      },
      {
        "id": 372,
        "archetype": "Magical Quest",
        "name": "Three magical tasks must be completed."
      },
      {
        "id": 373,
        "archetype": "Magical Quest",
        "name": "A magical object must be returned."
      },
      {
        "id": 374,
        "archetype": "Magical Quest",
        "name": "The wrong spell creates trouble."
      },
      {
        "id": 375,
        "archetype": "Magical Quest",
        "name": "Every magical choice has consequences."
      },
      {
        "id": 376,
        "archetype": "Magical Quest",
        "name": "Balance must be restored."
      },
      {
        "id": 377,
        "archetype": "Nature's Balance",
        "name": "Nature behaves unusually."
      },
      {
        "id": 378,
        "archetype": "Nature's Balance",
        "name": "Animals begin acting differently."
      },
      {
        "id": 379,
        "archetype": "Nature's Balance",
        "name": "Water starts disappearing."
      },
      {
        "id": 380,
        "archetype": "Nature's Balance",
        "name": "Plants stop growing."
      },
      {
        "id": 381,
        "archetype": "Nature's Balance",
        "name": "Weather changes unexpectedly."
      },
      {
        "id": 382,
        "archetype": "Nature's Balance",
        "name": "Balance is slowly returning."
      },
      {
        "id": 383,
        "archetype": "Nature's Balance",
        "name": "A tiny action has a huge effect."
      },
      {
        "id": 384,
        "archetype": "Nature's Balance",
        "name": "Caring for nature restores harmony."
      },
      {
        "id": 385,
        "archetype": "Ancient Secret",
        "name": "An old map is discovered."
      },
      {
        "id": 386,
        "archetype": "Ancient Secret",
        "name": "Forgotten symbols appear."
      },
      {
        "id": 387,
        "archetype": "Ancient Secret",
        "name": "An ancient door opens."
      },
      {
        "id": 388,
        "archetype": "Ancient Secret",
        "name": "A legend proves true."
      },
      {
        "id": 389,
        "archetype": "Ancient Secret",
        "name": "A hidden guardian appears."
      },
      {
        "id": 390,
        "archetype": "Ancient Secret",
        "name": "History reveals a forgotten truth."
      },
      {
        "id": 391,
        "archetype": "Ancient Secret",
        "name": "The secret changes the mission."
      },
      {
        "id": 392,
        "archetype": "Ancient Secret",
        "name": "The past helps solve today's problem."
      },
      {
        "id": 393,
        "archetype": "Wish or Blessing",
        "name": "A heartfelt wish is made."
      },
      {
        "id": 394,
        "archetype": "Wish or Blessing",
        "name": "A blessing arrives unexpectedly."
      },
      {
        "id": 395,
        "archetype": "Wish or Blessing",
        "name": "Someone wishes for the wrong thing."
      },
      {
        "id": 396,
        "archetype": "Wish or Blessing",
        "name": "Gratitude changes the outcome."
      },
      {
        "id": 397,
        "archetype": "Wish or Blessing",
        "name": "A wish comes true in an unexpected way."
      },
      {
        "id": 398,
        "archetype": "Wish or Blessing",
        "name": "Helping others brings a blessing."
      },
      {
        "id": 399,
        "archetype": "Wish or Blessing",
        "name": "A difficult choice determines the blessing."
      },
      {
        "id": 400,
        "archetype": "Wish or Blessing",
        "name": "True happiness wasn't what was wished for."
      },
      {
        "id": 401,
        "archetype": "Dream Adventure",
        "name": "A mysterious dream repeats."
      },
      {
        "id": 402,
        "archetype": "Dream Adventure",
        "name": "A dream gives an important clue."
      },
      {
        "id": 403,
        "archetype": "Dream Adventure",
        "name": "Dreams and reality begin connecting."
      },
      {
        "id": 404,
        "archetype": "Dream Adventure",
        "name": "A dream guide appears."
      },
      {
        "id": 405,
        "archetype": "Dream Adventure",
        "name": "Fear must be faced in the dream."
      },
      {
        "id": 406,
        "archetype": "Dream Adventure",
        "name": "Something learned in sleep helps later."
      },
      {
        "id": 407,
        "archetype": "Dream Adventure",
        "name": "Waking creates a new mystery."
      },
      {
        "id": 408,
        "archetype": "Dream Adventure",
        "name": "The final answer comes after the dream."
      },
      {
        "id": 409,
        "archetype": "Time Adventure",
        "name": "Time suddenly becomes important."
      },
      {
        "id": 410,
        "archetype": "Time Adventure",
        "name": "Every minute counts."
      },
      {
        "id": 411,
        "archetype": "Time Adventure",
        "name": "Waiting changes everything."
      },
      {
        "id": 412,
        "archetype": "Time Adventure",
        "name": "The right moment must be found."
      },
      {
        "id": 413,
        "archetype": "Time Adventure",
        "name": "A forgotten deadline returns."
      },
      {
        "id": 414,
        "archetype": "Time Adventure",
        "name": "Small delays create big problems."
      },
      {
        "id": 415,
        "archetype": "Time Adventure",
        "name": "Patience reveals the answer."
      },
      {
        "id": 416,
        "archetype": "Time Adventure",
        "name": "Perfect timing saves the day."
      },
      {
        "id": 417,
        "archetype": "Choice & Consequence",
        "name": "Two paths appear."
      },
      {
        "id": 418,
        "archetype": "Choice & Consequence",
        "name": "Every choice changes the story."
      },
      {
        "id": 419,
        "archetype": "Choice & Consequence",
        "name": "The easiest option isn't the best."
      },
      {
        "id": 420,
        "archetype": "Choice & Consequence",
        "name": "Someone else's future depends on the decision."
      },
      {
        "id": 421,
        "archetype": "Choice & Consequence",
        "name": "A selfish choice creates problems."
      },
      {
        "id": 422,
        "archetype": "Choice & Consequence",
        "name": "Kindness changes the outcome."
      },
      {
        "id": 423,
        "archetype": "Choice & Consequence",
        "name": "Courage requires making a difficult choice."
      },
      {
        "id": 424,
        "archetype": "Choice & Consequence",
        "name": "Every decision teaches something valuable."
      },
      {
        "id": 425,
        "archetype": "Promise Keeper",
        "name": "An important promise is made."
      },
      {
        "id": 426,
        "archetype": "Promise Keeper",
        "name": "Keeping the promise becomes difficult."
      },
      {
        "id": 427,
        "archetype": "Promise Keeper",
        "name": "Obstacles test determination."
      },
      {
        "id": 428,
        "archetype": "Promise Keeper",
        "name": "Others begin depending on the promise."
      },
      {
        "id": 429,
        "archetype": "Promise Keeper",
        "name": "Breaking the promise seems easier."
      },
      {
        "id": 430,
        "archetype": "Promise Keeper",
        "name": "Unexpected help appears."
      },
      {
        "id": 431,
        "archetype": "Promise Keeper",
        "name": "Honoring the promise changes lives."
      },
      {
        "id": 432,
        "archetype": "Promise Keeper",
        "name": "The promise becomes the greatest reward."
      },
      {
        "id": 433,
        "archetype": "Unexpected Surprise",
        "name": "An ordinary day changes suddenly."
      },
      {
        "id": 434,
        "archetype": "Unexpected Surprise",
        "name": "An unexpected visitor arrives."
      },
      {
        "id": 435,
        "archetype": "Unexpected Surprise",
        "name": "A hidden opportunity appears."
      },
      {
        "id": 436,
        "archetype": "Unexpected Surprise",
        "name": "A mistake leads to something wonderful."
      },
      {
        "id": 437,
        "archetype": "Unexpected Surprise",
        "name": "The smallest idea grows unexpectedly."
      },
      {
        "id": 438,
        "archetype": "Unexpected Surprise",
        "name": "Someone receives surprising news."
      },
      {
        "id": 439,
        "archetype": "Unexpected Surprise",
        "name": "A coincidence changes everything."
      },
      {
        "id": 440,
        "archetype": "Unexpected Surprise",
        "name": "The ending is better than anyone imagined."
      }
    ],
    "storyWorlds": [
      {
        "id": 1,
        "slug": "whispering-forest",
        "name": "Whispering Forest",
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Mystery to Solve",
          "Treasure Hunt",
          "Friendship Repair",
          "Discovery Journey",
          "Team Adventure",
          "Great Journey"
        ]
      },
      {
        "id": 2,
        "slug": "ancient-banyan-grove",
        "name": "Ancient Banyan Grove",
        "bestAdventureArchetypes": [
          "Wisdom Challenge",
          "Mentor Journey",
          "Discovery Journey",
          "Ancient Secret",
          "Great Journey",
          "Choice & Consequence"
        ]
      },
      {
        "id": 3,
        "slug": "whispering-meadow",
        "name": "Whispering Meadow",
        "bestAdventureArchetypes": [
          "Friendship Repair",
          "Gift of Giving",
          "New Friend",
          "Discovery Journey",
          "Helping Hand",
          "Nature's Balance"
        ]
      },
      {
        "id": 4,
        "slug": "crystal-river-valley",
        "name": "Crystal River Valley",
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Great Journey",
          "Nature's Balance",
          "Discovery Journey",
          "Time Adventure",
          "Team Adventure"
        ]
      },
      {
        "id": 5,
        "slug": "hidden-waterfall",
        "name": "Hidden Waterfall",
        "bestAdventureArchetypes": [
          "Secret Discovery",
          "Treasure Hunt",
          "Rescue Mission",
          "Discovery Journey",
          "Great Journey",
          "Ancient Secret"
        ]
      },
      {
        "id": 6,
        "slug": "sunny-orchard",
        "name": "Sunny Orchard",
        "bestAdventureArchetypes": [
          "Gift of Giving",
          "Helping Hand",
          "Community Project",
          "Celebration Preparation",
          "Friendship Repair",
          "Nature's Balance"
        ]
      },
      {
        "id": 7,
        "slug": "flower-garden",
        "name": "Flower Garden",
        "bestAdventureArchetypes": [
          "Nature's Balance",
          "Gift of Giving",
          "Helping Hand",
          "Discovery Journey",
          "Friendship Repair",
          "New Friend"
        ]
      },
      {
        "id": 8,
        "slug": "bamboo-forest",
        "name": "Bamboo Forest",
        "bestAdventureArchetypes": [
          "Great Journey",
          "Discovery Journey",
          "Build & Repair",
          "Nature's Balance",
          "Team Adventure",
          "Rescue Mission"
        ]
      },
      {
        "id": 9,
        "slug": "misty-mountains",
        "name": "Misty Mountains",
        "bestAdventureArchetypes": [
          "Great Journey",
          "Survival Adventure",
          "Rescue Mission",
          "Time Adventure",
          "Discovery Journey",
          "Hero's Trial"
        ]
      },
      {
        "id": 10,
        "slug": "golden-grasslands",
        "name": "Golden Grasslands",
        "bestAdventureArchetypes": [
          "Great Journey",
          "Community Project",
          "Team Adventure",
          "Nature's Balance",
          "Discovery Journey",
          "Helping Hand"
        ]
      },
      {
        "id": 12,
        "slug": "lotus-pond",
        "name": "Lotus Pond",
        "bestAdventureArchetypes": [
          "Discovery Journey",
          "Gift of Giving",
          "Nature's Balance",
          "New Friend",
          "Helping Hand",
          "Mystery to Solve"
        ]
      },
      {
        "id": 13,
        "slug": "turtle-bay",
        "name": "Turtle Bay",
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Great Journey",
          "Nature's Balance",
          "Helping Hand",
          "Team Adventure",
          "Gift of Giving"
        ]
      },
      {
        "id": 14,
        "slug": "mangrove-marsh",
        "name": "Mangrove Marsh",
        "bestAdventureArchetypes": [
          "Discovery Journey",
          "Mystery to Solve",
          "Nature's Balance",
          "Rescue Mission",
          "Great Journey",
          "Survival Adventure"
        ]
      },
      {
        "id": 15,
        "slug": "waterfall-caves",
        "name": "Waterfall Caves",
        "bestAdventureArchetypes": [
          "Ancient Secret",
          "Treasure Hunt",
          "Rescue Mission",
          "Discovery Journey",
          "Mystery to Solve",
          "Great Journey"
        ]
      },
      {
        "id": 17,
        "slug": "woodland-village",
        "name": "Woodland Village",
        "bestAdventureArchetypes": [
          "Community Project",
          "Helping Hand",
          "Gift of Giving",
          "Build Together",
          "Friendship Repair",
          "Celebration Preparation"
        ]
      },
      {
        "id": 18,
        "slug": "treehouse-village",
        "name": "Treehouse Village",
        "bestAdventureArchetypes": [
          "Team Adventure",
          "Build Together",
          "Community Project",
          "Discovery Journey",
          "Helping Hand",
          "Performance Story"
        ]
      },
      {
        "id": 19,
        "slug": "riverside-village",
        "name": "Riverside Village",
        "bestAdventureArchetypes": [
          "Community Project",
          "Festival Adventure",
          "Helping Hand",
          "Nature's Balance",
          "Gift of Giving",
          "Performance Story"
        ]
      },
      {
        "id": 20,
        "slug": "hilltop-village",
        "name": "Hilltop Village",
        "bestAdventureArchetypes": [
          "Community Project",
          "Helping Hand",
          "Build Together",
          "Promise Keeper",
          "Celebration Preparation",
          "Performance Story"
        ]
      },
      {
        "id": 21,
        "slug": "celebration-village",
        "name": "Celebration Village",
        "bestAdventureArchetypes": [
          "Festival Adventure",
          "Performance Story",
          "Helping Hand",
          "Community Project",
          "Mystery to Solve",
          "Gift of Giving"
        ]
      },
      {
        "id": 23,
        "slug": "magic-garden",
        "name": "Magic Garden",
        "bestAdventureArchetypes": [
          "Magical Discovery",
          "Nature's Balance",
          "Gift of Giving",
          "Discovery Journey",
          "Helping Hand",
          "New Friend"
        ]
      },
      {
        "id": 24,
        "slug": "rainbow-kingdom",
        "name": "Rainbow Kingdom",
        "bestAdventureArchetypes": [
          "Great Journey",
          "Festival Adventure",
          "Gift of Giving",
          "Community Project",
          "Magical Quest",
          "Performance Story"
        ]
      },
      {
        "id": 25,
        "slug": "cloud-kingdom",
        "name": "Cloud Kingdom",
        "bestAdventureArchetypes": [
          "Great Journey",
          "Rescue Mission",
          "Magical Quest",
          "Discovery Journey",
          "Time Adventure",
          "Team Adventure"
        ]
      },
      {
        "id": 26,
        "slug": "moonlight-valley",
        "name": "Moonlight Valley",
        "bestAdventureArchetypes": [
          "Ancient Secret",
          "Mystery to Solve",
          "Dream Adventure",
          "Discovery Journey",
          "Wisdom Challenge",
          "Magical Discovery"
        ]
      },
      {
        "id": 27,
        "slug": "star-forest",
        "name": "Star Forest",
        "bestAdventureArchetypes": [
          "Great Journey",
          "Ancient Secret",
          "Discovery Journey",
          "Wish or Blessing",
          "Magical Quest",
          "Treasure Hunt"
        ]
      },
      {
        "id": 28,
        "slug": "crystal-caverns",
        "name": "Crystal Caverns",
        "bestAdventureArchetypes": [
          "Treasure Hunt",
          "Ancient Secret",
          "Mystery to Solve",
          "Rescue Mission",
          "Discovery Journey",
          "Magical Discovery"
        ]
      },
      {
        "id": 29,
        "slug": "temple-courtyard",
        "name": "Temple Courtyard",
        "bestAdventureArchetypes": [
          "Ancient Secret",
          "Treasure Hunt",
          "Wisdom Challenge",
          "Mystery to Solve",
          "Discovery Journey"
        ]
      },
      {
        "id": 30,
        "slug": "wishing-woods",
        "name": "Wishing Woods",
        "bestAdventureArchetypes": [
          "Wish or Blessing",
          "Magical Discovery",
          "Choice & Consequence",
          "Discovery Journey",
          "Gift of Giving",
          "Dream Adventure"
        ]
      },
      {
        "id": 32,
        "slug": "secret-library",
        "name": "Secret Library",
        "bestAdventureArchetypes": [
          "Discovery Journey",
          "Ancient Secret",
          "Wisdom Challenge",
          "Learning Quest",
          "Mentor Journey",
          "Mystery to Solve"
        ]
      },
      {
        "id": 33,
        "slug": "forgotten-ruins",
        "name": "Forgotten Ruins",
        "bestAdventureArchetypes": [
          "Ancient Secret",
          "Treasure Hunt",
          "Discovery Journey",
          "Great Journey",
          "Mystery to Solve",
          "Survival Adventure"
        ]
      },
      {
        "id": 34,
        "slug": "hidden-cave-network",
        "name": "Hidden Cave Network",
        "bestAdventureArchetypes": [
          "Treasure Hunt",
          "Rescue Mission",
          "Mystery to Solve",
          "Discovery Journey",
          "Great Journey",
          "Time Adventure"
        ]
      },
      {
        "id": 35,
        "slug": "lost-island",
        "name": "Lost Island",
        "bestAdventureArchetypes": [
          "Great Journey",
          "Survival Adventure",
          "Rescue Mission",
          "Discovery Journey",
          "Nature's Balance",
          "Team Adventure"
        ]
      },
      {
        "id": 36,
        "slug": "treasure-cliffs",
        "name": "Treasure Cliffs",
        "bestAdventureArchetypes": [
          "Treasure Hunt",
          "Great Journey",
          "Rescue Mission",
          "Time Adventure",
          "Discovery Journey",
          "Hero's Trial"
        ]
      },
      {
        "id": 38,
        "slug": "great-caravan-trail",
        "name": "Great Caravan Trail",
        "bestAdventureArchetypes": [
          "Great Journey",
          "Escort Mission",
          "Delivery Quest",
          "Team Adventure",
          "Community Project",
          "Time Adventure"
        ]
      },
      {
        "id": 39,
        "slug": "desert-oasis",
        "name": "Desert Oasis",
        "bestAdventureArchetypes": [
          "Survival Adventure",
          "Great Journey",
          "Rescue Mission",
          "Discovery Journey",
          "Nature's Balance",
          "Time Adventure"
        ]
      },
      {
        "id": 40,
        "slug": "snowy-highlands",
        "name": "Snowy Highlands",
        "bestAdventureArchetypes": [
          "Survival Adventure",
          "Rescue Mission",
          "Great Journey",
          "Hero's Trial",
          "Time Adventure",
          "Build & Repair"
        ]
      },
      {
        "id": 41,
        "slug": "volcano-valley",
        "name": "Volcano Valley",
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Survival Adventure",
          "Hero's Trial",
          "Time Adventure",
          "Build & Repair",
          "Great Journey"
        ]
      },
      {
        "id": 42,
        "slug": "sky-islands",
        "name": "Sky Islands",
        "bestAdventureArchetypes": [
          "Great Journey",
          "Discovery Journey",
          "Magical Quest",
          "Rescue Mission",
          "Time Adventure",
          "Team Adventure"
        ]
      },
      {
        "id": 44,
        "slug": "dream-world",
        "name": "Dream World",
        "bestAdventureArchetypes": [
          "Dream Adventure",
          "Wisdom Challenge",
          "Choice & Consequence",
          "Ancient Secret",
          "Discovery Journey",
          "Mentor Journey"
        ]
      },
      {
        "id": 45,
        "slug": "toy-kingdom",
        "name": "Toy Kingdom",
        "bestAdventureArchetypes": [
          "Creative Quest",
          "Build & Repair",
          "Helping Hand",
          "Friendship Repair",
          "Community Project",
          "Magical Discovery"
        ]
      },
      {
        "id": 46,
        "slug": "story-house",
        "name": "Story House",
        "bestAdventureArchetypes": [
          "Ancient Secret",
          "Discovery Journey",
          "Mentor Journey",
          "Learning Quest",
          "Wisdom Challenge",
          "Teaching Adventure"
        ]
      }
    ],
    "storyWorldPacks": [
      {
        "id": 1,
        "slug": "whispering-forest",
        "name": "Whispering Forest",
        "theme": "Discovery, kindness and courage",
        "mainCharacters": [
          "Chinu",
          "Mira",
          "Arin",
          "Bodhi"
        ],
        "supportingCharacters": [
          "Birds",
          "squirrels",
          "rabbits",
          "butterflies",
          "bees"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Caregiver",
          "Mentor"
        ],
        "settings": [
          "Banyan Tree",
          "Meadow",
          "River Bend",
          "Hollow Log",
          "Cave Entrance",
          "Vine Bridge"
        ],
        "natureMechanics": [
          "Birds guide",
          "leaves reveal clues",
          "rivers change routes",
          "vines block paths"
        ],
        "props": [
          "Rope",
          "Basket",
          "Lantern",
          "Leaf Boat",
          "Map"
        ],
        "typicalMissions": [
          "Rescue",
          "Find & Discover",
          "Explore",
          "Help"
        ],
        "typicalObstacles": [
          "Physical",
          "Nature",
          "Puzzle"
        ],
        "bestLifeDomains": [
          "Exploring & Nature",
          "Helping & Caring",
          "Friendship & Sharing"
        ],
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Mystery to Solve",
          "Great Journey",
          "Secret Discovery"
        ],
        "bestEmotionalArcs": [
          "Fear→Courage",
          "Curiosity→Confidence",
          "Loneliness→Belonging"
        ],
        "bestWisdomElements": [
          "Big Ears",
          "Eyes",
          "Trunk",
          "Mouse"
        ],
        "notes": "Introductory world"
      },
      {
        "id": 2,
        "slug": "ancient-banyan-grove",
        "name": "Ancient Banyan Grove",
        "theme": "Wisdom, patience and reflection",
        "mainCharacters": [
          "Bodhi",
          "Ved",
          "Chinu"
        ],
        "supportingCharacters": [
          "Owls",
          "squirrels",
          "deer"
        ],
        "preferredCharacterTypes": [
          "Mentor",
          "Thinker",
          "Explorer"
        ],
        "settings": [
          "Giant Roots",
          "Meditation Circle",
          "Tree Library",
          "Hidden Hollow"
        ],
        "natureMechanics": [
          "Falling leaves reveal answers",
          "roots create paths"
        ],
        "props": [
          "Scrolls",
          "Lamp",
          "Seed Pods",
          "Prayer Bells"
        ],
        "typicalMissions": [
          "Learn & Grow",
          "Find & Discover"
        ],
        "typicalObstacles": [
          "Puzzle",
          "Emotional"
        ],
        "bestLifeDomains": [
          "Learning & Problem Solving",
          "Self-Care"
        ],
        "bestAdventureArchetypes": [
          "Mentor Journey",
          "Ancient Secret",
          "Training Journey"
        ],
        "bestEmotionalArcs": [
          "Confusion→Clarity",
          "Fear→Wisdom"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Big Ears",
          "Trunk"
        ],
        "notes": "Wisdom world"
      },
      {
        "id": 3,
        "slug": "whispering-meadow",
        "name": "Whispering Meadow",
        "theme": "Friendship and joyful play",
        "mainCharacters": [
          "Mira",
          "Chinu",
          "Anu"
        ],
        "supportingCharacters": [
          "Rabbits",
          "butterflies",
          "birds"
        ],
        "preferredCharacterTypes": [
          "Friend",
          "Caregiver"
        ],
        "settings": [
          "Flower Fields",
          "Picnic Hill",
          "Tall Grass",
          "Brook"
        ],
        "natureMechanics": [
          "Butterflies guide",
          "flowers bloom",
          "wind carries seeds"
        ],
        "props": [
          "Flowers",
          "Picnic Basket",
          "Kites",
          "Garlands"
        ],
        "typicalMissions": [
          "Help",
          "Celebrate",
          "Find & Discover"
        ],
        "typicalObstacles": [
          "Social",
          "Emotional"
        ],
        "bestLifeDomains": [
          "Friendship & Sharing",
          "Playing & Games"
        ],
        "bestAdventureArchetypes": [
          "New Friend",
          "Friendship Repair",
          "Gift of Giving"
        ],
        "bestEmotionalArcs": [
          "Shyness→Belonging",
          "Loneliness→Friendship"
        ],
        "bestWisdomElements": [
          "Mouse",
          "Modak",
          "Big Ears"
        ],
        "notes": "Gentle world"
      },
      {
        "id": 4,
        "slug": "crystal-river-valley",
        "name": "Crystal River Valley",
        "theme": "Flow, teamwork and perseverance",
        "mainCharacters": [
          "Arin",
          "Neel",
          "Bodhi"
        ],
        "supportingCharacters": [
          "Fish",
          "turtles",
          "otters"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Guide"
        ],
        "settings": [
          "River Crossing",
          "Waterfall",
          "Pebble Bank",
          "Wooden Bridge"
        ],
        "natureMechanics": [
          "River currents change routes",
          "fish reveal clues"
        ],
        "props": [
          "Raft",
          "Rope",
          "Fishing Net",
          "Water Pot"
        ],
        "typicalMissions": [
          "Rescue",
          "Deliver",
          "Explore"
        ],
        "typicalObstacles": [
          "Physical",
          "Nature",
          "Time"
        ],
        "bestLifeDomains": [
          "Exploring & Nature",
          "Responsibility"
        ],
        "bestAdventureArchetypes": [
          "Great Journey",
          "Escort Mission",
          "Rescue Mission"
        ],
        "bestEmotionalArcs": [
          "Worry→Confidence",
          "Fear→Courage"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Mouse",
          "Eyes"
        ],
        "notes": "Water adventures"
      },
      {
        "id": 5,
        "slug": "hidden-waterfall",
        "name": "Hidden Waterfall",
        "theme": "Wonder and discovery",
        "mainCharacters": [
          "Arin",
          "Mira"
        ],
        "supportingCharacters": [
          "Birds",
          "frogs",
          "dragonflies"
        ],
        "preferredCharacterTypes": [
          "Explorer"
        ],
        "settings": [
          "Waterfall Cave",
          "Secret Pool",
          "Moss Rocks"
        ],
        "natureMechanics": [
          "Rainbow mist reveals hidden paths"
        ],
        "props": [
          "Lantern",
          "Crystal",
          "Leaf Boat"
        ],
        "typicalMissions": [
          "Find & Discover",
          "Explore"
        ],
        "typicalObstacles": [
          "Puzzle",
          "Nature"
        ],
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Secret Discovery",
          "Treasure Hunt",
          "Hidden World"
        ],
        "bestEmotionalArcs": [
          "Curiosity→Wonder"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Trunk"
        ],
        "notes": "Mystery location"
      },
      {
        "id": 6,
        "slug": "sunny-orchard",
        "name": "Sunny Orchard",
        "theme": "Gratitude, sharing and community",
        "mainCharacters": [
          "Gauri",
          "Anu",
          "Chinu"
        ],
        "supportingCharacters": [
          "Birds",
          "bees",
          "cows"
        ],
        "preferredCharacterTypes": [
          "Caregiver",
          "Helper"
        ],
        "settings": [
          "Fruit Trees",
          "Barn",
          "Well",
          "Orchard Path"
        ],
        "natureMechanics": [
          "Trees bear fruit seasonally"
        ],
        "props": [
          "Basket",
          "Ladder",
          "Watering Can"
        ],
        "typicalMissions": [
          "Help",
          "Celebrate",
          "Deliver"
        ],
        "typicalObstacles": [
          "Social",
          "Physical"
        ],
        "bestLifeDomains": [
          "Helping & Caring",
          "Celebrations & Traditions"
        ],
        "bestAdventureArchetypes": [
          "Helping Hand",
          "Community Project"
        ],
        "bestEmotionalArcs": [
          "Gratitude→Joy"
        ],
        "bestWisdomElements": [
          "Modak",
          "Mouse"
        ],
        "notes": "Harvest stories"
      },
      {
        "id": 7,
        "slug": "flower-garden",
        "name": "Flower Garden",
        "theme": "Beauty, patience and care",
        "mainCharacters": [
          "Mira",
          "Gauri"
        ],
        "supportingCharacters": [
          "Bees",
          "butterflies",
          "ladybirds"
        ],
        "preferredCharacterTypes": [
          "Caregiver",
          "Creator"
        ],
        "settings": [
          "Rose Garden",
          "Lily Pond",
          "Butterfly Corner"
        ],
        "natureMechanics": [
          "Flowers bloom after kindness and care"
        ],
        "props": [
          "Water Can",
          "Seed Bag",
          "Garden Tools"
        ],
        "typicalMissions": [
          "Care & Restore",
          "Help"
        ],
        "typicalObstacles": [
          "Nature",
          "Emotional"
        ],
        "bestLifeDomains": [
          "Exploring & Nature",
          "Helping & Caring"
        ],
        "bestAdventureArchetypes": [
          "Nature's Balance",
          "Restoration Story"
        ],
        "bestEmotionalArcs": [
          "Impatience→Patience"
        ],
        "bestWisdomElements": [
          "Lotus",
          "Eyes"
        ],
        "notes": "Calm world"
      },
      {
        "id": 8,
        "slug": "bamboo-forest",
        "name": "Bamboo Forest",
        "theme": "Flexibility and resilience",
        "mainCharacters": [
          "Kavi",
          "Chinu"
        ],
        "supportingCharacters": [
          "Monkeys",
          "pandas",
          "birds"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Trickster"
        ],
        "settings": [
          "Bamboo Maze",
          "Rope Bridge",
          "Stream"
        ],
        "natureMechanics": [
          "Bamboo bends",
          "wind creates sounds"
        ],
        "props": [
          "Bamboo Staff",
          "Rope",
          "Basket"
        ],
        "typicalMissions": [
          "Explore",
          "Rescue"
        ],
        "typicalObstacles": [
          "Physical",
          "Puzzle"
        ],
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Expedition",
          "Escape Adventure",
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Fear→Confidence"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Big Ears"
        ],
        "notes": "Fast-moving adventures"
      },
      {
        "id": 9,
        "slug": "misty-mountains",
        "name": "Misty Mountains",
        "theme": "Determination and courage",
        "mainCharacters": [
          "Kabir",
          "Veer",
          "Bodhi"
        ],
        "supportingCharacters": [
          "Eagles",
          "mountain goats"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Mentor"
        ],
        "settings": [
          "Cliffs",
          "Snow Pass",
          "Stone Steps",
          "Peak"
        ],
        "natureMechanics": [
          "Mist hides paths",
          "echoes guide"
        ],
        "props": [
          "Walking Stick",
          "Rope",
          "Compass"
        ],
        "typicalMissions": [
          "Great Journey",
          "Learn & Grow"
        ],
        "typicalObstacles": [
          "Physical",
          "Time"
        ],
        "bestLifeDomains": [
          "Exploring & Nature",
          "Self-Care"
        ],
        "bestAdventureArchetypes": [
          "Hero's Trial",
          "Great Journey",
          "Training Journey"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt→Resilience"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Eyes"
        ],
        "notes": "Challenging world"
      },
      {
        "id": 10,
        "slug": "golden-grasslands",
        "name": "Golden Grasslands",
        "theme": "Freedom, teamwork and exploration",
        "mainCharacters": [
          "Simha",
          "Neel"
        ],
        "supportingCharacters": [
          "Deer",
          "birds",
          "rabbits"
        ],
        "preferredCharacterTypes": [
          "Leader",
          "Explorer"
        ],
        "settings": [
          "Open Plains",
          "Tall Grass",
          "Wind Hill"
        ],
        "natureMechanics": [
          "Wind reveals tracks",
          "grass hides clues"
        ],
        "props": [
          "Flag",
          "Binoculars",
          "Rope"
        ],
        "typicalMissions": [
          "Explore",
          "Protect",
          "Rescue"
        ],
        "typicalObstacles": [
          "Nature",
          "Social"
        ],
        "bestLifeDomains": [
          "Exploring & Nature",
          "Friendship & Sharing"
        ],
        "bestAdventureArchetypes": [
          "Great Journey",
          "Team Adventure",
          "Rescue Mission"
        ],
        "bestEmotionalArcs": [
          "Uncertainty→Confidence"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Big Ears"
        ],
        "notes": "Open-world adventures"
      },
      {
        "id": 11,
        "slug": "lotus-pond",
        "name": "Lotus Pond",
        "theme": "Peace, reflection and kindness",
        "mainCharacters": [
          "Gauri",
          "Mira",
          "Bodhi"
        ],
        "supportingCharacters": [
          "Frogs",
          "ducks",
          "dragonflies",
          "fish"
        ],
        "preferredCharacterTypes": [
          "Caregiver",
          "Mentor"
        ],
        "settings": [
          "Lotus Lake",
          "Lily Pads",
          "Wooden Jetty",
          "Reed Beds"
        ],
        "natureMechanics": [
          "Lotus blooms",
          "ripples reveal clues",
          "floating leaves create paths"
        ],
        "props": [
          "Lotus Flower",
          "Water Pot",
          "Small Boat",
          "Basket"
        ],
        "typicalMissions": [
          "Care & Restore",
          "Help",
          "Find & Discover"
        ],
        "typicalObstacles": [
          "Nature",
          "Emotional"
        ],
        "bestLifeDomains": [
          "Helping & Caring",
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Nature's Balance",
          "Restoration Story",
          "Secret Discovery"
        ],
        "bestEmotionalArcs": [
          "Worry → Peace",
          "Fear → Trust"
        ],
        "bestWisdomElements": [
          "Lotus",
          "Eyes",
          "Trunk"
        ],
        "notes": "Calm reflective world"
      },
      {
        "id": 12,
        "slug": "turtle-bay",
        "name": "Turtle Bay",
        "theme": "Patience and steady progress",
        "mainCharacters": [
          "Tara",
          "Neel",
          "Bodhi"
        ],
        "supportingCharacters": [
          "Turtles",
          "crabs",
          "seabirds"
        ],
        "preferredCharacterTypes": [
          "Guide",
          "Caregiver"
        ],
        "settings": [
          "Sandy Beach",
          "Rock Pools",
          "Wooden Pier",
          "Sea Caves"
        ],
        "natureMechanics": [
          "Tides change routes",
          "shells hide clues"
        ],
        "props": [
          "Shell",
          "Raft",
          "Fishing Net",
          "Compass"
        ],
        "typicalMissions": [
          "Rescue",
          "Deliver",
          "Explore"
        ],
        "typicalObstacles": [
          "Nature",
          "Time"
        ],
        "bestLifeDomains": [
          "Exploring & Nature",
          "Responsibility"
        ],
        "bestAdventureArchetypes": [
          "Escort Mission",
          "Delivery Quest",
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Impatience → Patience"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Mouse"
        ],
        "notes": "Coastal adventures"
      },
      {
        "id": 13,
        "slug": "mangrove-marsh",
        "name": "Mangrove Marsh",
        "theme": "Adaptability and teamwork",
        "mainCharacters": [
          "Arin",
          "Tara"
        ],
        "supportingCharacters": [
          "Cranes",
          "fish",
          "frogs"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Problem Solver"
        ],
        "settings": [
          "Mangrove Roots",
          "Mud Flats",
          "Narrow Streams"
        ],
        "natureMechanics": [
          "Rising tides",
          "tangled roots",
          "hidden waterways"
        ],
        "props": [
          "Pole Boat",
          "Rope",
          "Lantern"
        ],
        "typicalMissions": [
          "Explore",
          "Rescue",
          "Find & Discover"
        ],
        "typicalObstacles": [
          "Nature",
          "Puzzle",
          "Physical"
        ],
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Expedition",
          "Mystery to Solve",
          "Escape Adventure"
        ],
        "bestEmotionalArcs": [
          "Confusion → Confidence"
        ],
        "bestWisdomElements": [
          "Big Ears",
          "Trunk"
        ],
        "notes": "Navigation-focused"
      },
      {
        "id": 14,
        "slug": "waterfall-caves",
        "name": "Waterfall Caves",
        "theme": "Mystery beneath the surface",
        "mainCharacters": [
          "Kabir",
          "Arin"
        ],
        "supportingCharacters": [
          "Bats",
          "glowworms",
          "cave birds"
        ],
        "preferredCharacterTypes": [
          "Explorer"
        ],
        "settings": [
          "Crystal Caverns",
          "Hidden Chamber",
          "Underground Stream"
        ],
        "natureMechanics": [
          "Echoes guide",
          "crystals reflect light"
        ],
        "props": [
          "Lantern",
          "Rope",
          "Crystal",
          "Map"
        ],
        "typicalMissions": [
          "Treasure Hunt",
          "Explore"
        ],
        "typicalObstacles": [
          "Puzzle",
          "Physical"
        ],
        "bestLifeDomains": [
          "Learning & Problem Solving",
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Ancient Secret",
          "Hidden World",
          "Treasure Hunt"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Wonder"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Trunk"
        ],
        "notes": "Rich visual world"
      },
      {
        "id": 15,
        "slug": "woodland-village",
        "name": "Woodland Village",
        "theme": "Community and belonging",
        "mainCharacters": [
          "Chinu",
          "Gauri",
          "Anu"
        ],
        "supportingCharacters": [
          "Families",
          "birds",
          "woodland animals"
        ],
        "preferredCharacterTypes": [
          "Helper",
          "Community Builder"
        ],
        "settings": [
          "Village Square",
          "Market",
          "Bakery",
          "School",
          "Garden"
        ],
        "natureMechanics": [
          "Seasons change activities"
        ],
        "props": [
          "Basket",
          "Cart",
          "Toolbox",
          "Water Bucket"
        ],
        "typicalMissions": [
          "Help",
          "Deliver",
          "Celebrate"
        ],
        "typicalObstacles": [
          "Social",
          "Responsibility"
        ],
        "bestLifeDomains": [
          "School & Community",
          "Friendship & Sharing"
        ],
        "bestAdventureArchetypes": [
          "Community Project",
          "Helping Hand",
          "Celebration Preparation"
        ],
        "bestEmotionalArcs": [
          "Loneliness → Belonging"
        ],
        "bestWisdomElements": [
          "Modak",
          "Mouse"
        ],
        "notes": "Everyday stories"
      },
      {
        "id": 16,
        "slug": "treehouse-village",
        "name": "Treehouse Village",
        "theme": "Creativity and teamwork",
        "mainCharacters": [
          "Chinu",
          "Kavi",
          "Pihu"
        ],
        "supportingCharacters": [
          "Squirrels",
          "birds",
          "monkeys"
        ],
        "preferredCharacterTypes": [
          "Builder",
          "Explorer"
        ],
        "settings": [
          "Treehouses",
          "Rope Bridges",
          "Lookout Tower"
        ],
        "natureMechanics": [
          "Wind moves bridges",
          "birds carry messages"
        ],
        "props": [
          "Rope Ladder",
          "Hammer",
          "Basket",
          "Flags"
        ],
        "typicalMissions": [
          "Build",
          "Explore",
          "Help"
        ],
        "typicalObstacles": [
          "Physical",
          "Social"
        ],
        "bestLifeDomains": [
          "Building & Creating",
          "Friendship & Sharing"
        ],
        "bestAdventureArchetypes": [
          "Build Together",
          "Team Adventure",
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Confidence"
        ],
        "bestWisdomElements": [
          "Big Ears",
          "Trunk"
        ],
        "notes": "Vertical adventure world"
      },
      {
        "id": 17,
        "slug": "riverside-village",
        "name": "Riverside Village",
        "theme": "Cooperation and responsibility",
        "mainCharacters": [
          "Gauri",
          "Arin",
          "Neel"
        ],
        "supportingCharacters": [
          "Fisherfolk",
          "birds",
          "turtles"
        ],
        "preferredCharacterTypes": [
          "Helper",
          "Guide"
        ],
        "settings": [
          "Riverbank",
          "Docks",
          "Ferry Crossing",
          "Market"
        ],
        "natureMechanics": [
          "River levels change",
          "boats drift"
        ],
        "props": [
          "Boat",
          "Oars",
          "Rope",
          "Fishing Basket"
        ],
        "typicalMissions": [
          "Deliver",
          "Rescue",
          "Community Help"
        ],
        "typicalObstacles": [
          "Nature",
          "Time"
        ],
        "bestLifeDomains": [
          "Responsibility",
          "Helping & Caring"
        ],
        "bestAdventureArchetypes": [
          "Delivery Quest",
          "Journey Together",
          "Community Project"
        ],
        "bestEmotionalArcs": [
          "Responsibility → Pride"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Mouse"
        ],
        "notes": "River community"
      },
      {
        "id": 18,
        "slug": "hilltop-village",
        "name": "Hilltop Village",
        "theme": "Courage and leadership",
        "mainCharacters": [
          "Veer",
          "Kabir",
          "Simha"
        ],
        "supportingCharacters": [
          "Goats",
          "eagles",
          "shepherds"
        ],
        "preferredCharacterTypes": [
          "Leader",
          "Mentor"
        ],
        "settings": [
          "Hill Paths",
          "Watchtower",
          "Windmill",
          "Stone Homes"
        ],
        "natureMechanics": [
          "Strong winds",
          "steep climbs"
        ],
        "props": [
          "Walking Stick",
          "Flag",
          "Rope"
        ],
        "typicalMissions": [
          "Protect",
          "Guide",
          "Help"
        ],
        "typicalObstacles": [
          "Physical",
          "Time"
        ],
        "bestLifeDomains": [
          "Responsibility",
          "School & Community"
        ],
        "bestAdventureArchetypes": [
          "Leadership Challenge",
          "Hero's Trial",
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Fear → Courage"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Trunk"
        ],
        "notes": "Leadership stories"
      },
      {
        "id": 19,
        "slug": "magic-garden",
        "name": "Magic Garden",
        "theme": "Wonder through nature",
        "mainCharacters": [
          "Mira",
          "Pihu",
          "Gauri"
        ],
        "supportingCharacters": [
          "Butterflies",
          "hummingbirds",
          "rabbits"
        ],
        "preferredCharacterTypes": [
          "Caregiver",
          "Creator"
        ],
        "settings": [
          "Rainbow Flowers",
          "Crystal Pond",
          "Butterfly Grove"
        ],
        "natureMechanics": [
          "Flowers respond to care",
          "vines create paths"
        ],
        "props": [
          "Seeds",
          "Watering Can",
          "Crystal",
          "Garden Tools"
        ],
        "typicalMissions": [
          "Care & Restore",
          "Explore"
        ],
        "typicalObstacles": [
          "Nature",
          "Emotional"
        ],
        "bestLifeDomains": [
          "Art",
          "Music & Creativity",
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Magical Discovery",
          "Nature's Balance",
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "Wonder → Gratitude"
        ],
        "bestWisdomElements": [
          "Lotus",
          "Eyes"
        ],
        "notes": "Wonder comes from nature, not magic"
      },
      {
        "id": 20,
        "slug": "rainbow-kingdom",
        "name": "Rainbow Kingdom",
        "theme": "Joy, creativity and celebration",
        "mainCharacters": [
          "Mayur",
          "Vani",
          "Chinu"
        ],
        "supportingCharacters": [
          "Peacocks",
          "parrots",
          "artists"
        ],
        "preferredCharacterTypes": [
          "Creator",
          "Performer"
        ],
        "settings": [
          "Rainbow Plaza",
          "Music Hall",
          "Festival Street",
          "Colour Gardens"
        ],
        "natureMechanics": [
          "Rainbows appear after rain",
          "colours inspire ideas"
        ],
        "props": [
          "Paint Brushes",
          "Musical Instruments",
          "Festival Banners"
        ],
        "typicalMissions": [
          "Celebrate",
          "Perform",
          "Create"
        ],
        "typicalObstacles": [
          "Social",
          "Time"
        ],
        "bestLifeDomains": [
          "Art",
          "Music & Creativity",
          "Celebrations & Traditions"
        ],
        "bestAdventureArchetypes": [
          "Festival Adventure",
          "Performance Story",
          "Gift of Giving"
        ],
        "bestEmotionalArcs": [
          "Shyness → Confidence",
          "Joy → Belonging"
        ],
        "bestWisdomElements": [
          "Modak",
          "Eyes",
          "Big Ears"
        ],
        "notes": "Best festival world"
      },
      {
        "id": 21,
        "slug": "cloud-kingdom",
        "name": "Cloud Kingdom",
        "theme": "Imagination, hope and perspective",
        "mainCharacters": [
          "Mayur",
          "Vani",
          "Ved"
        ],
        "supportingCharacters": [
          "Birds",
          "cloud spirits",
          "butterflies"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Dreamer",
          "Mentor"
        ],
        "settings": [
          "Cloud Bridges",
          "Rainbow Gate",
          "Sky Garden",
          "Floating Islands"
        ],
        "natureMechanics": [
          "Clouds change shape",
          "winds create pathways"
        ],
        "props": [
          "Feather Glider",
          "Kite",
          "Wind Chimes",
          "Sky Map"
        ],
        "typicalMissions": [
          "Explore",
          "Deliver",
          "Discover"
        ],
        "typicalObstacles": [
          "Nature",
          "Time"
        ],
        "bestLifeDomains": [
          "Exploring & Nature",
          "Art",
          "Music & Creativity"
        ],
        "bestAdventureArchetypes": [
          "Great Journey",
          "Hidden World",
          "Magical Discovery"
        ],
        "bestEmotionalArcs": [
          "Doubt → Wonder",
          "Fear → Confidence"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Big Ears"
        ],
        "notes": "Inspires imagination"
      },
      {
        "id": 22,
        "slug": "moonlight-valley",
        "name": "Moonlight Valley",
        "theme": "Reflection and quiet courage",
        "mainCharacters": [
          "Ved",
          "Mira",
          "Bodhi"
        ],
        "supportingCharacters": [
          "Fireflies",
          "owls",
          "deer"
        ],
        "preferredCharacterTypes": [
          "Mentor",
          "Thinker"
        ],
        "settings": [
          "Moon Lake",
          "Silver Meadow",
          "Firefly Grove"
        ],
        "natureMechanics": [
          "Moonlight reveals hidden paths"
        ],
        "props": [
          "Moon Lantern",
          "Crystal Stone",
          "Telescope"
        ],
        "typicalMissions": [
          "Find & Discover",
          "Learn & Grow"
        ],
        "typicalObstacles": [
          "Emotional",
          "Puzzle"
        ],
        "bestLifeDomains": [
          "Self-Care",
          "Learning & Problem Solving"
        ],
        "bestAdventureArchetypes": [
          "Dream Adventure",
          "Ancient Secret",
          "Mystery to Solve"
        ],
        "bestEmotionalArcs": [
          "Worry → Peace",
          "Confusion → Clarity"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Lotus"
        ],
        "notes": "Calm nighttime world"
      },
      {
        "id": 23,
        "slug": "star-forest",
        "name": "Star Forest",
        "theme": "Wonder and curiosity",
        "mainCharacters": [
          "Chinu",
          "Pihu",
          "Ved"
        ],
        "supportingCharacters": [
          "Fireflies",
          "birds",
          "glowing insects"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Dreamer"
        ],
        "settings": [
          "Star Clearing",
          "Starlight Trail",
          "Ancient Trees"
        ],
        "natureMechanics": [
          "Falling stars reveal clues"
        ],
        "props": [
          "Star Compass",
          "Lantern",
          "Telescope"
        ],
        "typicalMissions": [
          "Explore",
          "Find & Discover"
        ],
        "typicalObstacles": [
          "Puzzle",
          "Nature"
        ],
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Expedition",
          "Hidden World",
          "Discovery Journey"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Wonder"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Trunk"
        ],
        "notes": "Excellent exploration world"
      },
      {
        "id": 24,
        "slug": "crystal-caverns",
        "name": "Crystal Caverns",
        "theme": "Discovery beneath the earth",
        "mainCharacters": [
          "Kabir",
          "Arin"
        ],
        "supportingCharacters": [
          "Bats",
          "glowworms"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Problem Solver"
        ],
        "settings": [
          "Crystal Hall",
          "Echo Tunnel",
          "Hidden Chamber"
        ],
        "natureMechanics": [
          "Light reflects through crystals"
        ],
        "props": [
          "Crystal",
          "Rope",
          "Pickaxe",
          "Lantern"
        ],
        "typicalMissions": [
          "Treasure Hunt",
          "Solve"
        ],
        "typicalObstacles": [
          "Physical",
          "Puzzle"
        ],
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestAdventureArchetypes": [
          "Treasure Hunt",
          "Mystery to Solve",
          "Ancient Secret"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Achievement"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Eyes"
        ],
        "notes": "Rich visual setting"
      },
      {
        "id": 25,
        "slug": "wishing-woods",
        "name": "Wishing Woods",
        "theme": "Hope, gratitude and possibility",
        "mainCharacters": [
          "Mira",
          "Gauri",
          "Chinu"
        ],
        "supportingCharacters": [
          "Birds",
          "rabbits",
          "butterflies"
        ],
        "preferredCharacterTypes": [
          "Caregiver",
          "Dreamer"
        ],
        "settings": [
          "Wish Tree",
          "Flower Circle",
          "Secret Grove"
        ],
        "natureMechanics": [
          "Leaves carry wishes",
          "flowers bloom with care"
        ],
        "props": [
          "Wish Leaf",
          "Ribbon",
          "Lantern"
        ],
        "typicalMissions": [
          "Help",
          "Care & Restore"
        ],
        "typicalObstacles": [
          "Emotional",
          "Nature"
        ],
        "bestLifeDomains": [
          "Helping & Caring",
          "Self-Care"
        ],
        "bestAdventureArchetypes": [
          "Wish or Blessing",
          "Transformation Story",
          "Gift of Giving"
        ],
        "bestEmotionalArcs": [
          "Hopelessness → Hope"
        ],
        "bestWisdomElements": [
          "Modak",
          "Lotus"
        ],
        "notes": "Wishes inspire action only"
      },
      {
        "id": 26,
        "slug": "secret-library",
        "name": "Secret Library",
        "theme": "Curiosity and wisdom",
        "mainCharacters": [
          "Ved",
          "Bodhi",
          "Vani"
        ],
        "supportingCharacters": [
          "Owls",
          "mice",
          "bookkeepers"
        ],
        "preferredCharacterTypes": [
          "Mentor",
          "Thinker"
        ],
        "settings": [
          "Reading Hall",
          "Scroll Room",
          "Hidden Shelves"
        ],
        "natureMechanics": [
          "Books reveal clues",
          "moving shelves create puzzles"
        ],
        "props": [
          "Scrolls",
          "Keys",
          "Magnifying Glass"
        ],
        "typicalMissions": [
          "Learn",
          "Solve",
          "Discover"
        ],
        "typicalObstacles": [
          "Puzzle",
          "Emotional"
        ],
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestAdventureArchetypes": [
          "Detective Story",
          "Heritage Journey",
          "Ancient Secret"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Understanding"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Big Ears"
        ],
        "notes": "Knowledge-centered world"
      },
      {
        "id": 27,
        "slug": "forgotten-ruins",
        "name": "Forgotten Ruins",
        "theme": "History and hidden wisdom",
        "mainCharacters": [
          "Kabir",
          "Ved",
          "Bodhi"
        ],
        "supportingCharacters": [
          "Lizards",
          "birds",
          "monkeys"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Mentor"
        ],
        "settings": [
          "Broken Temple",
          "Stone Arch",
          "Hidden Courtyard"
        ],
        "natureMechanics": [
          "Ancient carvings reveal clues"
        ],
        "props": [
          "Torch",
          "Ancient Tablet",
          "Rope"
        ],
        "typicalMissions": [
          "Treasure Hunt",
          "Explore"
        ],
        "typicalObstacles": [
          "Physical",
          "Puzzle"
        ],
        "bestLifeDomains": [
          "Exploring & Nature",
          "Learning & Problem Solving"
        ],
        "bestAdventureArchetypes": [
          "Ancient Secret",
          "Expedition",
          "Mystery to Solve"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Wisdom"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Eyes"
        ],
        "notes": "Ancient Indian feel"
      },
      {
        "id": 28,
        "slug": "hidden-cave-network",
        "name": "Hidden Cave Network",
        "theme": "Courage and perseverance",
        "mainCharacters": [
          "Arin",
          "Kabir"
        ],
        "supportingCharacters": [
          "Bats",
          "cave insects"
        ],
        "preferredCharacterTypes": [
          "Explorer"
        ],
        "settings": [
          "Maze Tunnel",
          "Underground Lake",
          "Crystal Chamber"
        ],
        "natureMechanics": [
          "Echoes guide the way"
        ],
        "props": [
          "Rope",
          "Lantern",
          "Map"
        ],
        "typicalMissions": [
          "Explore",
          "Rescue"
        ],
        "typicalObstacles": [
          "Physical",
          "Puzzle"
        ],
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Escape Adventure",
          "Survival Adventure",
          "Expedition"
        ],
        "bestEmotionalArcs": [
          "Fear → Courage"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Big Ears"
        ],
        "notes": "Adventure-heavy"
      },
      {
        "id": 29,
        "slug": "lost-island",
        "name": "Lost Island",
        "theme": "Survival and teamwork",
        "mainCharacters": [
          "Veer",
          "Neel",
          "Arin"
        ],
        "supportingCharacters": [
          "Birds",
          "turtles",
          "monkeys"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Leader"
        ],
        "settings": [
          "Beach",
          "Jungle",
          "Cliffs",
          "Hidden Lagoon"
        ],
        "natureMechanics": [
          "Tides reshape paths",
          "storms change terrain"
        ],
        "props": [
          "Raft",
          "Compass",
          "Fishing Net"
        ],
        "typicalMissions": [
          "Rescue",
          "Explore",
          "Build"
        ],
        "typicalObstacles": [
          "Nature",
          "Physical",
          "Time"
        ],
        "bestLifeDomains": [
          "Exploring & Nature",
          "Helping & Caring"
        ],
        "bestAdventureArchetypes": [
          "Survival Adventure",
          "Great Journey",
          "Rescue Mission"
        ],
        "bestEmotionalArcs": [
          "Fear → Resilience"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Mouse"
        ],
        "notes": "Survival world"
      },
      {
        "id": 30,
        "slug": "treasure-cliffs",
        "name": "Treasure Cliffs",
        "theme": "Adventure and perseverance",
        "mainCharacters": [
          "Kabir",
          "Simha",
          "Chinu"
        ],
        "supportingCharacters": [
          "Eagles",
          "mountain goats"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Leader"
        ],
        "settings": [
          "Cliff Trail",
          "Hidden Cave",
          "Rope Bridge"
        ],
        "natureMechanics": [
          "Falling rocks",
          "strong winds"
        ],
        "props": [
          "Rope",
          "Climbing Gear",
          "Treasure Map"
        ],
        "typicalMissions": [
          "Treasure Hunt",
          "Explore"
        ],
        "typicalObstacles": [
          "Physical",
          "Time"
        ],
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Treasure Hunt",
          "Hero's Trial",
          "Race Against Time"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Achievement"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Eyes"
        ],
        "notes": "High-energy adventure world"
      },
      {
        "id": 31,
        "slug": "great-caravan-trail",
        "name": "Great Caravan Trail",
        "theme": "Journey, cooperation and perseverance",
        "mainCharacters": [
          "Veer",
          "Kabir",
          "Mitra"
        ],
        "supportingCharacters": [
          "Camels",
          "traders",
          "birds"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Guide",
          "Helper"
        ],
        "settings": [
          "Caravan Camp",
          "Sand Dunes",
          "Oasis Stop",
          "Trading Post"
        ],
        "natureMechanics": [
          "Sandstorms change routes",
          "stars guide travellers"
        ],
        "props": [
          "Compass",
          "Water Bag",
          "Cart",
          "Map"
        ],
        "typicalMissions": [
          "Deliver",
          "Escort",
          "Explore"
        ],
        "typicalObstacles": [
          "Nature",
          "Time",
          "Physical"
        ],
        "bestLifeDomains": [
          "Responsibility",
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Great Journey",
          "Delivery Quest",
          "Escort Mission"
        ],
        "bestEmotionalArcs": [
          "Uncertainty → Confidence"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Big Ears"
        ],
        "notes": "Travel-focused world"
      },
      {
        "id": 32,
        "slug": "desert-oasis",
        "name": "Desert Oasis",
        "theme": "Hope and resilience",
        "mainCharacters": [
          "Veer",
          "Kabir",
          "Gauri"
        ],
        "supportingCharacters": [
          "Camels",
          "desert foxes",
          "birds"
        ],
        "preferredCharacterTypes": [
          "Survivor",
          "Caregiver"
        ],
        "settings": [
          "Oasis",
          "Palm Grove",
          "Sand Dunes",
          "Desert Cave"
        ],
        "natureMechanics": [
          "Mirage",
          "shifting dunes",
          "scarce water"
        ],
        "props": [
          "Water Flask",
          "Rope",
          "Shade Tent"
        ],
        "typicalMissions": [
          "Rescue",
          "Care & Restore",
          "Explore"
        ],
        "typicalObstacles": [
          "Nature",
          "Time",
          "Physical"
        ],
        "bestLifeDomains": [
          "Self-Care",
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Survival Adventure",
          "Nature's Balance",
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Hopelessness → Hope"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Lotus"
        ],
        "notes": "Resilience stories"
      },
      {
        "id": 33,
        "slug": "snowy-highlands",
        "name": "Snowy Highlands",
        "theme": "Endurance and courage",
        "mainCharacters": [
          "Neel",
          "Kabir",
          "Veer"
        ],
        "supportingCharacters": [
          "Snow hares",
          "mountain birds",
          "yaks"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Leader"
        ],
        "settings": [
          "Snow Trail",
          "Frozen Lake",
          "Ice Cave",
          "Pine Forest"
        ],
        "natureMechanics": [
          "Snowfall changes paths",
          "frozen rivers become bridges"
        ],
        "props": [
          "Snow Boots",
          "Sled",
          "Lantern",
          "Rope"
        ],
        "typicalMissions": [
          "Rescue",
          "Explore",
          "Learn"
        ],
        "typicalObstacles": [
          "Physical",
          "Nature",
          "Time"
        ],
        "bestLifeDomains": [
          "Self-Care",
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Hero's Trial",
          "Survival Adventure",
          "Training Journey"
        ],
        "bestEmotionalArcs": [
          "Fear → Resilience"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Trunk"
        ],
        "notes": "Winter adventures"
      },
      {
        "id": 34,
        "slug": "volcano-valley",
        "name": "Volcano Valley",
        "theme": "Bravery under pressure",
        "mainCharacters": [
          "Simha",
          "Kabir",
          "Veer"
        ],
        "supportingCharacters": [
          "Eagles",
          "mountain goats"
        ],
        "preferredCharacterTypes": [
          "Leader",
          "Protector"
        ],
        "settings": [
          "Lava Ridge",
          "Ash Valley",
          "Stone Bridge",
          "Cave Shelter"
        ],
        "natureMechanics": [
          "Heat creates urgency",
          "ash hides clues"
        ],
        "props": [
          "Heat Shield",
          "Rope",
          "Water Flask"
        ],
        "typicalMissions": [
          "Rescue",
          "Protect",
          "Escape"
        ],
        "typicalObstacles": [
          "Physical",
          "Time",
          "Nature"
        ],
        "bestLifeDomains": [
          "Responsibility",
          "Exploring & Nature"
        ],
        "bestAdventureArchetypes": [
          "Escape Adventure",
          "Race Against Time",
          "Hero's Trial"
        ],
        "bestEmotionalArcs": [
          "Panic → Courage"
        ],
        "bestWisdomElements": [
          "Trunk",
          "Eyes"
        ],
        "notes": "High-stakes world"
      },
      {
        "id": 35,
        "slug": "sky-islands",
        "name": "Sky Islands",
        "theme": "Wonder and exploration",
        "mainCharacters": [
          "Mayur",
          "Vani",
          "Pihu"
        ],
        "supportingCharacters": [
          "Birds",
          "butterflies",
          "cloud creatures"
        ],
        "preferredCharacterTypes": [
          "Explorer",
          "Dreamer"
        ],
        "settings": [
          "Floating Islands",
          "Sky Bridge",
          "Wind Garden"
        ],
        "natureMechanics": [
          "Wind currents connect islands"
        ],
        "props": [
          "Glider",
          "Feather",
          "Wind Compass"
        ],
        "typicalMissions": [
          "Explore",
          "Discover"
        ],
        "typicalObstacles": [
          "Nature",
          "Puzzle"
        ],
        "bestLifeDomains": [
          "Exploring & Nature",
          "Art",
          "Music & Creativity"
        ],
        "bestAdventureArchetypes": [
          "Hidden World",
          "Expedition",
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Wonder"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Big Ears"
        ],
        "notes": "Fantasy without magic solving problems"
      },
      {
        "id": 36,
        "slug": "dream-world",
        "name": "Dream World",
        "theme": "Reflection and imagination",
        "mainCharacters": [
          "Ved",
          "Bodhi",
          "Pihu"
        ],
        "supportingCharacters": [
          "Fireflies",
          "dream animals"
        ],
        "preferredCharacterTypes": [
          "Mentor",
          "Thinker"
        ],
        "settings": [
          "Dream Forest",
          "Floating Steps",
          "Moon Garden"
        ],
        "natureMechanics": [
          "Dreams mirror emotions and reveal insights"
        ],
        "props": [
          "Dream Journal",
          "Lantern",
          "Feather"
        ],
        "typicalMissions": [
          "Learn",
          "Discover"
        ],
        "typicalObstacles": [
          "Emotional",
          "Puzzle"
        ],
        "bestLifeDomains": [
          "Self-Care",
          "Learning & Problem Solving"
        ],
        "bestAdventureArchetypes": [
          "Dream Adventure",
          "Transformation Story",
          "Wish or Blessing"
        ],
        "bestEmotionalArcs": [
          "Confusion → Clarity"
        ],
        "bestWisdomElements": [
          "Eyes",
          "Lotus"
        ],
        "notes": "Insight comes from reflection"
      },
      {
        "id": 37,
        "slug": "toy-kingdom",
        "name": "Toy Kingdom",
        "theme": "Play, creativity and teamwork",
        "mainCharacters": [
          "Chinu",
          "Kavi",
          "Anu"
        ],
        "supportingCharacters": [
          "Toy animals",
          "dolls",
          "wooden soldiers"
        ],
        "preferredCharacterTypes": [
          "Creator",
          "Friend"
        ],
        "settings": [
          "Toy Workshop",
          "Block City",
          "Puppet Theatre"
        ],
        "natureMechanics": [
          "Toys move through imagination and cooperation"
        ],
        "props": [
          "Blocks",
          "Puzzle Pieces",
          "Toy Cart",
          "Strings"
        ],
        "typicalMissions": [
          "Build",
          "Create",
          "Help"
        ],
        "typicalObstacles": [
          "Social",
          "Puzzle"
        ],
        "bestLifeDomains": [
          "Playing & Games",
          "Building & Creating"
        ],
        "bestAdventureArchetypes": [
          "Build Together",
          "Performance Story",
          "Team Adventure"
        ],
        "bestEmotionalArcs": [
          "Frustration → Creativity"
        ],
        "bestWisdomElements": [
          "Mouse",
          "Modak"
        ],
        "notes": "Play-based learning"
      },
      {
        "id": 38,
        "slug": "celebration-village",
        "name": "Celebration Village",
        "theme": "Joy, gratitude and community",
        "mainCharacters": [
          "Mayur",
          "Gauri",
          "Vani"
        ],
        "supportingCharacters": [
          "Musicians",
          "dancers",
          "villagers"
        ],
        "preferredCharacterTypes": [
          "Organizer",
          "Performer"
        ],
        "settings": [
          "Festival Square",
          "Food Stalls",
          "Temple Courtyard"
        ],
        "natureMechanics": [
          "Flowers bloom",
          "bells ring",
          "lamps light pathways"
        ],
        "props": [
          "Garlands",
          "Drums",
          "Diyas",
          "Modaks"
        ],
        "typicalMissions": [
          "Celebrate",
          "Organize",
          "Help"
        ],
        "typicalObstacles": [
          "Time",
          "Social"
        ],
        "bestLifeDomains": [
          "Celebrations & Traditions",
          "School & Community"
        ],
        "bestAdventureArchetypes": [
          "Festival Adventure",
          "Celebration Preparation",
          "Community Project"
        ],
        "bestEmotionalArcs": [
          "Excitement → Belonging"
        ],
        "bestWisdomElements": [
          "Modak",
          "Lotus"
        ],
        "notes": "Ideal for Ganesh Chaturthi stories"
      },
      {
        "id": 39,
        "slug": "temple-courtyard",
        "name": "Temple Courtyard",
        "theme": "Wisdom, respect and gratitude",
        "mainCharacters": [
          "Bodhi",
          "Ved",
          "Gauri"
        ],
        "supportingCharacters": [
          "Peacocks",
          "squirrels",
          "temple helpers"
        ],
        "preferredCharacterTypes": [
          "Mentor",
          "Caregiver"
        ],
        "settings": [
          "Temple Steps",
          "Bell Tower",
          "Sacred Tree",
          "Courtyard"
        ],
        "natureMechanics": [
          "Bells signal moments",
          "breeze carries prayers"
        ],
        "props": [
          "Bell",
          "Lamp",
          "Prayer Mat",
          "Flowers"
        ],
        "typicalMissions": [
          "Learn",
          "Help",
          "Discover"
        ],
        "typicalObstacles": [
          "Emotional",
          "Puzzle"
        ],
        "bestLifeDomains": [
          "Self-Care",
          "Celebrations & Traditions"
        ],
        "bestAdventureArchetypes": [
          "Heritage Journey",
          "Ancient Secret",
          "Promise Keeper"
        ],
        "bestEmotionalArcs": [
          "Restlessness → Peace"
        ],
        "bestWisdomElements": [
          "Lotus",
          "Eyes",
          "Trunk"
        ],
        "notes": "Quiet wisdom stories"
      },
      {
        "id": 40,
        "slug": "story-house",
        "name": "Story House",
        "theme": "Stories, imagination and learning",
        "mainCharacters": [
          "Ved",
          "Chinu",
          "Pihu"
        ],
        "supportingCharacters": [
          "Storytellers",
          "birds",
          "mice"
        ],
        "preferredCharacterTypes": [
          "Mentor",
          "Creator"
        ],
        "settings": [
          "Reading Corner",
          "Story Hall",
          "Attic",
          "Secret Bookshelf"
        ],
        "natureMechanics": [
          "Stories reveal clues",
          "books inspire adventures"
        ],
        "props": [
          "Story Scrolls",
          "Books",
          "Magnifying Glass",
          "Story Chest"
        ],
        "typicalMissions": [
          "Learn",
          "Solve",
          "Find & Discover"
        ],
        "typicalObstacles": [
          "Puzzle",
          "Emotional"
        ],
        "bestLifeDomains": [
          "Learning & Problem Solving",
          "Art",
          "Music & Creativity"
        ],
        "bestAdventureArchetypes": [
          "Heritage Journey",
          "Mystery to Solve",
          "Secret Discovery"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Understanding"
        ],
        "bestWisdomElements": [
          "Big Ears",
          "Eyes"
        ],
        "notes": "Gateway to storytelling adventures"
      }
    ],
    "missions": [
      {
        "id": 1,
        "slug": "rescue-a-lost-friend",
        "name": "Rescue a Lost Friend",
        "missionGroup": "Find and safely bring back a missing friend.",
        "description": "Friendship & Sharing, Exploring & Nature",
        "bestLifeDomains": [
          "Search",
          "Help"
        ],
        "bestStoryActions": [
          "Forest",
          "Meadow",
          "Cave"
        ],
        "bestStoryWorlds": [
          "Rescue Mission",
          "Great Journey"
        ],
        "bestAdventureArchetypes": [
          "Belonging",
          "Courage"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Classic friendship story",
        "notes": null
      },
      {
        "id": 2,
        "slug": "rescue-a-trapped-animal",
        "name": "Rescue a Trapped Animal",
        "missionGroup": "Free an animal that cannot escape.",
        "description": "Helping & Caring, Exploring & Nature",
        "bestLifeDomains": [
          "Rescue",
          "Help"
        ],
        "bestStoryActions": [
          "Forest",
          "River",
          "Mountain"
        ],
        "bestStoryWorlds": [
          "Rescue Mission"
        ],
        "bestAdventureArchetypes": [
          "Compassion",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Nature-focused",
        "notes": null
      },
      {
        "id": 3,
        "slug": "rescue-a-baby-creature",
        "name": "Rescue a Baby Creature",
        "missionGroup": "Help a baby animal reunite with its family.",
        "description": "Helping & Caring, Family & Daily Life",
        "bestLifeDomains": [
          "Rescue",
          "Care For"
        ],
        "bestStoryActions": [
          "Forest",
          "Meadow",
          "Pond"
        ],
        "bestStoryWorlds": [
          "Rescue Mission"
        ],
        "bestAdventureArchetypes": [
          "Empathy",
          "Nurturing"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Good for younger readers",
        "notes": null
      },
      {
        "id": 4,
        "slug": "rescue-an-elder",
        "name": "Rescue an Elder",
        "missionGroup": "Help an older character reach safety.",
        "description": "Helping & Caring, School & Community",
        "bestLifeDomains": [
          "Help",
          "Guide"
        ],
        "bestStoryActions": [
          "Village",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Rescue Mission",
          "Community Project"
        ],
        "bestAdventureArchetypes": [
          "Respect",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Encourages kindness",
        "notes": null
      },
      {
        "id": 5,
        "slug": "rescue-someone-before-sunset",
        "name": "Rescue Someone Before Sunset",
        "missionGroup": "Complete the rescue before time runs out.",
        "description": "Helping & Caring, Exploring & Nature",
        "bestLifeDomains": [
          "Rescue",
          "Search"
        ],
        "bestStoryActions": [
          "Forest",
          "River"
        ],
        "bestStoryWorlds": [
          "Rescue Mission",
          "Race Against Time"
        ],
        "bestAdventureArchetypes": [
          "Courage",
          "Perseverance"
        ],
        "bestCoreNeeds": [
          "Hard"
        ],
        "difficulty": "Time-pressure story",
        "notes": null
      },
      {
        "id": 6,
        "slug": "bring-help",
        "name": "Bring Help",
        "missionGroup": "Find someone who can solve the problem.",
        "description": "Helping & Caring, School & Community",
        "bestLifeDomains": [
          "Help",
          "Deliver"
        ],
        "bestStoryActions": [
          "Village",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Helping Hand"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Courage"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Teamwork works well",
        "notes": null
      },
      {
        "id": 7,
        "slug": "find-a-safe-route",
        "name": "Find a Safe Route",
        "missionGroup": "Discover a safe path for everyone.",
        "description": "Exploring & Nature, Responsibility",
        "bestLifeDomains": [
          "Explore",
          "Solve"
        ],
        "bestStoryActions": [
          "Forest",
          "Mountain",
          "River"
        ],
        "bestStoryWorlds": [
          "Great Journey"
        ],
        "bestAdventureArchetypes": [
          "Leadership",
          "Confidence"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Good for problem solving",
        "notes": null
      },
      {
        "id": 8,
        "slug": "lead-everyone-to-safety",
        "name": "Lead Everyone to Safety",
        "missionGroup": "Guide a group safely through danger.",
        "description": "School & Community, Helping & Caring",
        "bestLifeDomains": [
          "Guide",
          "Protect"
        ],
        "bestStoryActions": [
          "Forest",
          "River",
          "Village"
        ],
        "bestStoryWorlds": [
          "Great Journey",
          "Rescue Mission"
        ],
        "bestAdventureArchetypes": [
          "Leadership",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Hard"
        ],
        "difficulty": "Best with group stories",
        "notes": null
      },
      {
        "id": 9,
        "slug": "rescue-a-special-object",
        "name": "Rescue a Special Object",
        "missionGroup": "Recover something important before it is lost forever.",
        "description": "Responsibility, Family & Daily Life",
        "bestLifeDomains": [
          "Search",
          "Rescue"
        ],
        "bestStoryActions": [
          "Forest",
          "Village"
        ],
        "bestStoryWorlds": [
          "Treasure Hunt"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Perseverance"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Can connect to festivals",
        "notes": null
      },
      {
        "id": 10,
        "slug": "rescue-a-family-of-animals",
        "name": "Rescue a Family of Animals",
        "missionGroup": "Help an entire animal family escape danger.",
        "description": "Helping & Caring, Exploring & Nature",
        "bestLifeDomains": [
          "Rescue",
          "Protect"
        ],
        "bestStoryActions": [
          "Forest",
          "Meadow"
        ],
        "bestStoryWorlds": [
          "Rescue Mission"
        ],
        "bestAdventureArchetypes": [
          "Compassion",
          "Teamwork"
        ],
        "bestCoreNeeds": [
          "Hard"
        ],
        "difficulty": "Good for multiple supporting characters",
        "notes": null
      },
      {
        "id": 11,
        "slug": "find-a-missing-object",
        "name": "Find a Missing Object",
        "missionGroup": "Locate an important lost object.",
        "description": "Responsibility, Family & Daily Life, Learning & Problem Solving",
        "bestLifeDomains": [
          "Search",
          "Discover"
        ],
        "bestStoryActions": [
          "Forest",
          "Village",
          "Home"
        ],
        "bestStoryWorlds": [
          "Treasure Hunt",
          "Mystery to Solve"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Confidence"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Classic search story",
        "notes": null
      },
      {
        "id": 12,
        "slug": "find-a-hidden-place",
        "name": "Find a Hidden Place",
        "missionGroup": "Discover a secret location.",
        "description": "Exploring & Nature, Playing & Games",
        "bestLifeDomains": [
          "Explore",
          "Discover"
        ],
        "bestStoryActions": [
          "Forest",
          "Cave",
          "Mountain"
        ],
        "bestStoryWorlds": [
          "Secret Discovery",
          "Hidden World"
        ],
        "bestAdventureArchetypes": [
          "Curiosity",
          "Confidence"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Great for exploration",
        "notes": null
      },
      {
        "id": 13,
        "slug": "find-a-rare-flower",
        "name": "Find a Rare Flower",
        "missionGroup": "Search for a special flower needed for a purpose.",
        "description": "Exploring & Nature, Helping & Caring",
        "bestLifeDomains": [
          "Search",
          "Explore"
        ],
        "bestStoryActions": [
          "Meadow",
          "Forest",
          "Mountain"
        ],
        "bestStoryWorlds": [
          "Treasure Hunt"
        ],
        "bestAdventureArchetypes": [
          "Perseverance",
          "Appreciation"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Nature-focused",
        "notes": null
      },
      {
        "id": 14,
        "slug": "find-the-last-clue",
        "name": "Find the Last Clue",
        "missionGroup": "Locate the final clue to solve a mystery.",
        "description": "Learning & Problem Solving",
        "bestLifeDomains": [
          "Search",
          "Solve"
        ],
        "bestStoryActions": [
          "Forest",
          "Village",
          "Cave"
        ],
        "bestStoryWorlds": [
          "Mystery to Solve"
        ],
        "bestAdventureArchetypes": [
          "Curiosity",
          "Problem Solving"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Works well with puzzles",
        "notes": null
      },
      {
        "id": 15,
        "slug": "find-the-right-path",
        "name": "Find the Right Path",
        "missionGroup": "Discover the correct route when lost.",
        "description": "Exploring & Nature, Responsibility",
        "bestLifeDomains": [
          "Explore",
          "Solve"
        ],
        "bestStoryActions": [
          "Forest",
          "River",
          "Mountain"
        ],
        "bestStoryWorlds": [
          "Great Journey"
        ],
        "bestAdventureArchetypes": [
          "Confidence",
          "Adaptability"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Encourages flexibility",
        "notes": null
      },
      {
        "id": 16,
        "slug": "find-the-truth",
        "name": "Find the Truth",
        "missionGroup": "Discover what really happened.",
        "description": "Communication, Friendship & Sharing",
        "bestLifeDomains": [
          "Observe",
          "Communicate"
        ],
        "bestStoryActions": [
          "Village",
          "School",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Mystery to Solve"
        ],
        "bestAdventureArchetypes": [
          "Honesty",
          "Empathy"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Good for misunderstandings",
        "notes": null
      },
      {
        "id": 17,
        "slug": "find-a-forgotten-story",
        "name": "Find a Forgotten Story",
        "missionGroup": "Uncover an old tale or memory.",
        "description": "Learning & Problem Solving, Celebrations & Traditions",
        "bestLifeDomains": [
          "Explore",
          "Learn"
        ],
        "bestStoryActions": [
          "Banyan Tree",
          "Story House",
          "Village"
        ],
        "bestStoryWorlds": [
          "Heritage Journey"
        ],
        "bestAdventureArchetypes": [
          "Curiosity",
          "Identity"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Connects well with wisdom",
        "notes": null
      },
      {
        "id": 18,
        "slug": "find-the-secret-entrance",
        "name": "Find the Secret Entrance",
        "missionGroup": "Discover a hidden way into a special place.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Search",
          "Explore"
        ],
        "bestStoryActions": [
          "Cave",
          "Forest",
          "Mountain"
        ],
        "bestStoryWorlds": [
          "Hidden World"
        ],
        "bestAdventureArchetypes": [
          "Courage",
          "Curiosity"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Adventure-driven",
        "notes": null
      },
      {
        "id": 19,
        "slug": "discover-a-hidden-treasure",
        "name": "Discover a Hidden Treasure",
        "missionGroup": "Find something valuable through effort.",
        "description": "Exploring & Nature, Playing & Games",
        "bestLifeDomains": [
          "Search",
          "Discover"
        ],
        "bestStoryActions": [
          "Forest",
          "Cave",
          "River"
        ],
        "bestStoryWorlds": [
          "Treasure Hunt"
        ],
        "bestAdventureArchetypes": [
          "Perseverance",
          "Gratitude"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Treasure need not be material",
        "notes": null
      },
      {
        "id": 20,
        "slug": "discover-an-old-map",
        "name": "Discover an Old Map",
        "missionGroup": "Find a forgotten map leading to a new adventure.",
        "description": "Learning & Problem Solving, Exploring & Nature",
        "bestLifeDomains": [
          "Discover",
          "Explore"
        ],
        "bestStoryActions": [
          "Story House",
          "Forest",
          "Village"
        ],
        "bestStoryWorlds": [
          "Discovery Journey",
          "Great Journey"
        ],
        "bestAdventureArchetypes": [
          "Curiosity",
          "Confidence"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Excellent story starter",
        "notes": null
      },
      {
        "id": 21,
        "slug": "deliver-medicine",
        "name": "Deliver Medicine",
        "missionGroup": "Take important medicine safely to someone in need.",
        "description": "Helping & Caring, Responsibility",
        "bestLifeDomains": [
          "Deliver",
          "Help"
        ],
        "bestStoryActions": [
          "Village",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Delivery Quest",
          "Great Journey"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Compassion"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Time pressure works well",
        "notes": null
      },
      {
        "id": 22,
        "slug": "deliver-an-invitation",
        "name": "Deliver an Invitation",
        "missionGroup": "Personally invite someone to a special event.",
        "description": "Celebrations & Traditions, Family & Daily Life",
        "bestLifeDomains": [
          "Deliver",
          "Communicate"
        ],
        "bestStoryActions": [
          "Village",
          "Meadow"
        ],
        "bestStoryWorlds": [
          "Delivery Quest"
        ],
        "bestAdventureArchetypes": [
          "Belonging",
          "Confidence"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Great festival story",
        "notes": null
      },
      {
        "id": 23,
        "slug": "deliver-an-important-message",
        "name": "Deliver an Important Message",
        "missionGroup": "Carry an urgent message to the right person.",
        "description": "Communication, Responsibility",
        "bestLifeDomains": [
          "Deliver",
          "Communicate"
        ],
        "bestStoryActions": [
          "Forest",
          "Village"
        ],
        "bestStoryWorlds": [
          "Delivery Quest",
          "Great Journey"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Courage"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Can involve misunderstandings",
        "notes": null
      },
      {
        "id": 24,
        "slug": "return-a-borrowed-item",
        "name": "Return a Borrowed Item",
        "missionGroup": "Return something that belongs to someone else.",
        "description": "Responsibility, Friendship & Sharing",
        "bestLifeDomains": [
          "Deliver"
        ],
        "bestStoryActions": [
          "Village",
          "Home"
        ],
        "bestStoryWorlds": [
          "Responsibility Quest"
        ],
        "bestAdventureArchetypes": [
          "Honesty",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Encourages integrity",
        "notes": null
      },
      {
        "id": 25,
        "slug": "deliver-food",
        "name": "Deliver Food",
        "missionGroup": "Take food safely to someone waiting.",
        "description": "Helping & Caring, Family & Daily Life",
        "bestLifeDomains": [
          "Deliver",
          "Help"
        ],
        "bestStoryActions": [
          "Village",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Delivery Quest"
        ],
        "bestAdventureArchetypes": [
          "Kindness",
          "Generosity"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Good community story",
        "notes": null
      },
      {
        "id": 26,
        "slug": "deliver-a-gift",
        "name": "Deliver a Gift",
        "missionGroup": "Deliver a thoughtful gift to brighten someone's day.",
        "description": "Friendship & Sharing, Celebrations & Traditions",
        "bestLifeDomains": [
          "Deliver",
          "Share"
        ],
        "bestStoryActions": [
          "Village",
          "Meadow"
        ],
        "bestStoryWorlds": [
          "Delivery Quest",
          "Gift of Giving"
        ],
        "bestAdventureArchetypes": [
          "Gratitude",
          "Generosity"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Works well with Modak stories",
        "notes": null
      },
      {
        "id": 27,
        "slug": "deliver-a-sacred-object",
        "name": "Deliver a Sacred Object",
        "missionGroup": "Safely carry an important sacred object to its destination.",
        "description": "Celebrations & Traditions, Responsibility",
        "bestLifeDomains": [
          "Deliver",
          "Protect"
        ],
        "bestStoryActions": [
          "Temple",
          "Village",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Delivery Quest"
        ],
        "bestAdventureArchetypes": [
          "Respect",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Can connect with Ganesha celebrations",
        "notes": null
      },
      {
        "id": 28,
        "slug": "keep-a-promise",
        "name": "Keep a Promise",
        "missionGroup": "Fulfil an important promise made to someone.",
        "description": "Friendship & Sharing, Responsibility",
        "bestLifeDomains": [
          "Deliver",
          "Help"
        ],
        "bestStoryActions": [
          "Any Story World"
        ],
        "bestStoryWorlds": [
          "Promise Keeper"
        ],
        "bestAdventureArchetypes": [
          "Trust",
          "Integrity"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Emotional mission",
        "notes": null
      },
      {
        "id": 29,
        "slug": "return-something-precious",
        "name": "Return Something Precious",
        "missionGroup": "Return a valuable item to its rightful owner.",
        "description": "Responsibility, Helping & Caring",
        "bestLifeDomains": [
          "Search",
          "Deliver"
        ],
        "bestStoryActions": [
          "Forest",
          "Village"
        ],
        "bestStoryWorlds": [
          "Delivery Quest"
        ],
        "bestAdventureArchetypes": [
          "Honesty",
          "Empathy"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Encourages selflessness",
        "notes": null
      },
      {
        "id": 30,
        "slug": "deliver-supplies-before-sunset",
        "name": "Deliver Supplies Before Sunset",
        "missionGroup": "Reach the destination before time runs out.",
        "description": "Responsibility, Helping & Caring",
        "bestLifeDomains": [
          "Deliver",
          "Journey"
        ],
        "bestStoryActions": [
          "Forest",
          "River",
          "Mountain"
        ],
        "bestStoryWorlds": [
          "Delivery Quest",
          "Race Against Time"
        ],
        "bestAdventureArchetypes": [
          "Perseverance",
          "Courage"
        ],
        "bestCoreNeeds": [
          "Hard"
        ],
        "difficulty": "Excellent for escalating tension",
        "notes": null
      },
      {
        "id": 31,
        "slug": "build-a-bridge",
        "name": "Build a Bridge",
        "missionGroup": "Build a bridge so everyone can cross safely.",
        "description": "Building & Creating, Helping & Caring",
        "bestLifeDomains": [
          "Build"
        ],
        "bestStoryActions": [
          "River",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Build Together",
          "Community Project"
        ],
        "bestAdventureArchetypes": [
          "Cooperation",
          "Confidence"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Teamwork mission",
        "notes": null
      },
      {
        "id": 32,
        "slug": "repair-a-cart",
        "name": "Repair a Cart",
        "missionGroup": "Fix a broken cart needed for the journey.",
        "description": "Responsibility, Building & Creating",
        "bestLifeDomains": [
          "Repair",
          "Build"
        ],
        "bestStoryActions": [
          "Village",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Build & Repair"
        ],
        "bestAdventureArchetypes": [
          "Perseverance",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Problem-solving",
        "notes": null
      },
      {
        "id": 33,
        "slug": "fix-a-broken-nest",
        "name": "Fix a Broken Nest",
        "missionGroup": "Repair an animal's damaged home.",
        "description": "Helping & Caring, Exploring & Nature",
        "bestLifeDomains": [
          "Repair",
          "Help"
        ],
        "bestStoryActions": [
          "Forest",
          "Meadow"
        ],
        "bestStoryWorlds": [
          "Restoration Story"
        ],
        "bestAdventureArchetypes": [
          "Compassion",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Great for younger children",
        "notes": null
      },
      {
        "id": 34,
        "slug": "build-a-shelter",
        "name": "Build a Shelter",
        "missionGroup": "Create a safe shelter before bad weather arrives.",
        "description": "Helping & Caring, Building & Creating",
        "bestLifeDomains": [
          "Build"
        ],
        "bestStoryActions": [
          "Forest",
          "Mountain"
        ],
        "bestStoryWorlds": [
          "Survival Adventure",
          "Build & Repair"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Courage"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Nature-based",
        "notes": null
      },
      {
        "id": 35,
        "slug": "restore-a-garden",
        "name": "Restore a Garden",
        "missionGroup": "Bring a neglected garden back to life.",
        "description": "Exploring & Nature, Helping & Caring",
        "bestLifeDomains": [
          "Restore",
          "Care For"
        ],
        "bestStoryActions": [
          "Garden",
          "Village"
        ],
        "bestStoryWorlds": [
          "Restoration Story"
        ],
        "bestAdventureArchetypes": [
          "Patience",
          "Hope"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Nature theme",
        "notes": null
      },
      {
        "id": 36,
        "slug": "repair-a-pathway",
        "name": "Repair a Pathway",
        "missionGroup": "Make a dangerous path safe again.",
        "description": "Responsibility, School & Community",
        "bestLifeDomains": [
          "Repair"
        ],
        "bestStoryActions": [
          "Forest",
          "Mountain"
        ],
        "bestStoryWorlds": [
          "Build & Repair"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Teamwork"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Community benefit",
        "notes": null
      },
      {
        "id": 37,
        "slug": "rebuild-a-playground",
        "name": "Rebuild a Playground",
        "missionGroup": "Work together to rebuild a place for everyone.",
        "description": "Building & Creating, Friendship & Sharing",
        "bestLifeDomains": [
          "Build"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Build Together",
          "Community Project"
        ],
        "bestAdventureArchetypes": [
          "Cooperation",
          "Belonging"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Group activity",
        "notes": null
      },
      {
        "id": 38,
        "slug": "create-something-together",
        "name": "Create Something Together",
        "missionGroup": "Make something useful as a team.",
        "description": "Building & Creating, Art, Music & Creativity",
        "bestLifeDomains": [
          "Create",
          "Build"
        ],
        "bestStoryActions": [
          "Any"
        ],
        "bestStoryWorlds": [
          "Creative Quest"
        ],
        "bestAdventureArchetypes": [
          "Teamwork",
          "Creativity"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Flexible mission",
        "notes": null
      },
      {
        "id": 39,
        "slug": "build-a-raft",
        "name": "Build a Raft",
        "missionGroup": "Construct a raft to continue the journey.",
        "description": "Exploring & Nature, Building & Creating",
        "bestLifeDomains": [
          "Build"
        ],
        "bestStoryActions": [
          "River"
        ],
        "bestStoryWorlds": [
          "Build & Repair",
          "Great Journey"
        ],
        "bestAdventureArchetypes": [
          "Confidence",
          "Problem Solving"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Adventure story",
        "notes": null
      },
      {
        "id": 40,
        "slug": "repair-festival-decorations",
        "name": "Repair Festival Decorations",
        "missionGroup": "Fix decorations before the celebration begins.",
        "description": "Celebrations & Traditions, Building & Creating",
        "bestLifeDomains": [
          "Repair",
          "Create"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Build & Repair",
          "Festival Adventure"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Pride"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Festival setting",
        "notes": null
      },
      {
        "id": 41,
        "slug": "protect-a-young-animal",
        "name": "Protect a Young Animal",
        "missionGroup": "Keep a young animal safe from danger.",
        "description": "Helping & Caring, Exploring & Nature",
        "bestLifeDomains": [
          "Protect",
          "Help"
        ],
        "bestStoryActions": [
          "Forest",
          "Meadow"
        ],
        "bestStoryWorlds": [
          "Guardian Adventure"
        ],
        "bestAdventureArchetypes": [
          "Compassion",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Nature-based",
        "notes": null
      },
      {
        "id": 42,
        "slug": "protect-a-sacred-tree",
        "name": "Protect a Sacred Tree",
        "missionGroup": "Care for a tree important to everyone.",
        "description": "Exploring & Nature, Responsibility",
        "bestLifeDomains": [
          "Protect"
        ],
        "bestStoryActions": [
          "Forest"
        ],
        "bestStoryWorlds": [
          "Guardian Adventure"
        ],
        "bestAdventureArchetypes": [
          "Respect",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Environmental story",
        "notes": null
      },
      {
        "id": 43,
        "slug": "protect-the-harvest",
        "name": "Protect the Harvest",
        "missionGroup": "Save food that the community depends on.",
        "description": "School & Community, Responsibility",
        "bestLifeDomains": [
          "Protect",
          "Organize"
        ],
        "bestStoryActions": [
          "Farm",
          "Village"
        ],
        "bestStoryWorlds": [
          "Guardian Adventure",
          "Community Project"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Gratitude"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Seasonal story",
        "notes": null
      },
      {
        "id": 44,
        "slug": "protect-a-celebration",
        "name": "Protect a Celebration",
        "missionGroup": "Ensure an important celebration happens safely.",
        "description": "Celebrations & Traditions",
        "bestLifeDomains": [
          "Protect",
          "Organize"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Guardian Adventure",
          "Festival Adventure"
        ],
        "bestAdventureArchetypes": [
          "Belonging",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Festival stories",
        "notes": null
      },
      {
        "id": 45,
        "slug": "protect-a-secret",
        "name": "Protect a Secret",
        "missionGroup": "Keep an important secret until the right time.",
        "description": "Friendship & Sharing, Communication",
        "bestLifeDomains": [
          "Protect"
        ],
        "bestStoryActions": [
          "Any"
        ],
        "bestStoryWorlds": [
          "Guardian Adventure"
        ],
        "bestAdventureArchetypes": [
          "Trust",
          "Integrity"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Emotional story",
        "notes": null
      },
      {
        "id": 46,
        "slug": "guard-an-important-object",
        "name": "Guard an Important Object",
        "missionGroup": "Keep a valuable object safe.",
        "description": "Responsibility",
        "bestLifeDomains": [
          "Protect"
        ],
        "bestStoryActions": [
          "Temple",
          "Village"
        ],
        "bestStoryWorlds": [
          "Guardian Adventure"
        ],
        "bestAdventureArchetypes": [
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Can use sacred objects",
        "notes": null
      },
      {
        "id": 47,
        "slug": "keep-everyone-safe",
        "name": "Keep Everyone Safe",
        "missionGroup": "Help a group avoid danger.",
        "description": "Helping & Caring, School & Community",
        "bestLifeDomains": [
          "Protect",
          "Guide"
        ],
        "bestStoryActions": [
          "Forest",
          "River"
        ],
        "bestStoryWorlds": [
          "Guardian Adventure"
        ],
        "bestAdventureArchetypes": [
          "Leadership",
          "Courage"
        ],
        "bestCoreNeeds": [
          "Hard"
        ],
        "difficulty": "Group story",
        "notes": null
      },
      {
        "id": 48,
        "slug": "protect-a-friendship",
        "name": "Protect a Friendship",
        "missionGroup": "Prevent a friendship from falling apart.",
        "description": "Friendship & Sharing",
        "bestLifeDomains": [
          "Communicate",
          "Help"
        ],
        "bestStoryActions": [
          "Any"
        ],
        "bestStoryWorlds": [
          "Friendship Repair"
        ],
        "bestAdventureArchetypes": [
          "Belonging",
          "Empathy"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Emotional conflict",
        "notes": null
      },
      {
        "id": 49,
        "slug": "protect-a-home",
        "name": "Protect a Home",
        "missionGroup": "Keep someone's home safe from harm.",
        "description": "Family & Daily Life, Helping & Caring",
        "bestLifeDomains": [
          "Protect",
          "Repair"
        ],
        "bestStoryActions": [
          "Village",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Guardian Adventure"
        ],
        "bestAdventureArchetypes": [
          "Safety",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Home-centered",
        "notes": null
      },
      {
        "id": 50,
        "slug": "protect-nature",
        "name": "Protect Nature",
        "missionGroup": "Care for the environment and its creatures.",
        "description": "Exploring & Nature, Responsibility",
        "bestLifeDomains": [
          "Protect",
          "Care For"
        ],
        "bestStoryActions": [
          "Forest",
          "River",
          "Garden"
        ],
        "bestStoryWorlds": [
          "Guardian Adventure",
          "Nature's Balance"
        ],
        "bestAdventureArchetypes": [
          "Stewardship",
          "Gratitude"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Nature conservation",
        "notes": null
      },
      {
        "id": 51,
        "slug": "learn-a-new-skill",
        "name": "Learn a New Skill",
        "missionGroup": "Master a skill through practice.",
        "description": "Learning & Problem Solving",
        "bestLifeDomains": [
          "Learn"
        ],
        "bestStoryActions": [
          "School",
          "Village"
        ],
        "bestStoryWorlds": [
          "Learning Quest"
        ],
        "bestAdventureArchetypes": [
          "Confidence",
          "Perseverance"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Everyday learning",
        "notes": null
      },
      {
        "id": 52,
        "slug": "solve-a-puzzle",
        "name": "Solve a Puzzle",
        "missionGroup": "Solve a puzzle to move forward.",
        "description": "Learning & Problem Solving",
        "bestLifeDomains": [
          "Solve"
        ],
        "bestStoryActions": [
          "Cave",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Mystery to Solve"
        ],
        "bestAdventureArchetypes": [
          "Curiosity",
          "Problem Solving"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Good for clue stories",
        "notes": null
      },
      {
        "id": 53,
        "slug": "understand-a-mystery",
        "name": "Understand a Mystery",
        "missionGroup": "Discover why something unusual happened.",
        "description": "Learning & Problem Solving",
        "bestLifeDomains": [
          "Discover",
          "Observe"
        ],
        "bestStoryActions": [
          "Forest",
          "Village"
        ],
        "bestStoryWorlds": [
          "Mystery to Solve"
        ],
        "bestAdventureArchetypes": [
          "Curiosity",
          "Wisdom"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Observation skills",
        "notes": null
      },
      {
        "id": 54,
        "slug": "learn-from-a-mentor",
        "name": "Learn from a Mentor",
        "missionGroup": "Gain wisdom from a guide.",
        "description": "Learning & Problem Solving",
        "bestLifeDomains": [
          "Learn"
        ],
        "bestStoryActions": [
          "Banyan Tree",
          "Story House"
        ],
        "bestStoryWorlds": [
          "Mentor Journey"
        ],
        "bestAdventureArchetypes": [
          "Humility",
          "Growth"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Bodhi or Ved stories",
        "notes": null
      },
      {
        "id": 55,
        "slug": "teach-someone-else",
        "name": "Teach Someone Else",
        "missionGroup": "Help another character learn a skill.",
        "description": "Helping & Caring, Learning & Problem Solving",
        "bestLifeDomains": [
          "Teach",
          "Help"
        ],
        "bestStoryActions": [
          "Village",
          "School"
        ],
        "bestStoryWorlds": [
          "Teaching Adventure"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Empathy"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Reinforces learning",
        "notes": null
      },
      {
        "id": 56,
        "slug": "complete-training",
        "name": "Complete Training",
        "missionGroup": "Finish a period of practice successfully.",
        "description": "Learning & Problem Solving",
        "bestLifeDomains": [
          "Practice"
        ],
        "bestStoryActions": [
          "Mountain",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Training Journey"
        ],
        "bestAdventureArchetypes": [
          "Perseverance",
          "Discipline"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Character growth",
        "notes": null
      },
      {
        "id": 57,
        "slug": "face-a-fear",
        "name": "Face a Fear",
        "missionGroup": "Overcome a personal fear.",
        "description": "Self-Care, Learning & Problem Solving",
        "bestLifeDomains": [
          "Try",
          "Learn"
        ],
        "bestStoryActions": [
          "Any"
        ],
        "bestStoryWorlds": [
          "Hero's Trial"
        ],
        "bestAdventureArchetypes": [
          "Courage",
          "Confidence"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Strong emotional arc",
        "notes": null
      },
      {
        "id": 58,
        "slug": "earn-someone-s-trust",
        "name": "Earn Someone's Trust",
        "missionGroup": "Show through actions that you can be trusted.",
        "description": "Friendship & Sharing, Responsibility",
        "bestLifeDomains": [
          "Help",
          "Keep Promise"
        ],
        "bestStoryActions": [
          "Village",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Friendship Repair"
        ],
        "bestAdventureArchetypes": [
          "Trust",
          "Integrity"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Relationship-focused",
        "notes": null
      },
      {
        "id": 59,
        "slug": "discover-a-hidden-talent",
        "name": "Discover a Hidden Talent",
        "missionGroup": "Realize a unique strength.",
        "description": "Art, Music & Creativity, Learning & Problem Solving",
        "bestLifeDomains": [
          "Explore",
          "Create"
        ],
        "bestStoryActions": [
          "Any"
        ],
        "bestStoryWorlds": [
          "Discovery Journey"
        ],
        "bestAdventureArchetypes": [
          "Self-Worth",
          "Confidence"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Identity stories",
        "notes": null
      },
      {
        "id": 60,
        "slug": "practice-until-successful",
        "name": "Practice Until Successful",
        "missionGroup": "Keep trying until improvement happens.",
        "description": "Learning & Problem Solving, Self-Care",
        "bestLifeDomains": [
          "Practice"
        ],
        "bestStoryActions": [
          "Any"
        ],
        "bestStoryWorlds": [
          "Training Journey"
        ],
        "bestAdventureArchetypes": [
          "Perseverance",
          "Confidence"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Excellent with Growth Edge",
        "notes": null
      },
      {
        "id": 61,
        "slug": "help-someone-finish-a-task",
        "name": "Help Someone Finish a Task",
        "missionGroup": "Assist someone in completing an important task.",
        "description": "Helping & Caring, Friendship & Sharing",
        "bestLifeDomains": [
          "Help"
        ],
        "bestStoryActions": [
          "Village",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Helping Hand"
        ],
        "bestAdventureArchetypes": [
          "Cooperation",
          "Kindness"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Great teamwork story",
        "notes": null
      },
      {
        "id": 62,
        "slug": "help-a-lonely-friend",
        "name": "Help a Lonely Friend",
        "missionGroup": "Include and support someone feeling left out.",
        "description": "Friendship & Sharing",
        "bestLifeDomains": [
          "Help",
          "Communicate"
        ],
        "bestStoryActions": [
          "Meadow",
          "School",
          "Village"
        ],
        "bestStoryWorlds": [
          "New Friend"
        ],
        "bestAdventureArchetypes": [
          "Belonging",
          "Empathy"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Emotional story",
        "notes": null
      },
      {
        "id": 63,
        "slug": "help-the-community",
        "name": "Help the Community",
        "missionGroup": "Work together to solve a community problem.",
        "description": "School & Community, Helping & Caring",
        "bestLifeDomains": [
          "Help",
          "Organize"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Community Project"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Cooperation"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Group effort",
        "notes": null
      },
      {
        "id": 64,
        "slug": "help-prepare-a-celebration",
        "name": "Help Prepare a Celebration",
        "missionGroup": "Get everything ready before the celebration begins.",
        "description": "Celebrations & Traditions",
        "bestLifeDomains": [
          "Help",
          "Organize"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Celebration Preparation"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Belonging"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Festival stories",
        "notes": null
      },
      {
        "id": 65,
        "slug": "help-nature-recover",
        "name": "Help Nature Recover",
        "missionGroup": "Restore balance after nature is damaged.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Care For",
          "Restore"
        ],
        "bestStoryActions": [
          "Forest",
          "River",
          "Garden"
        ],
        "bestStoryWorlds": [
          "Nature's Balance"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Gratitude"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Environmental focus",
        "notes": null
      },
      {
        "id": 66,
        "slug": "help-someone-believe-in-themselves",
        "name": "Help Someone Believe in Themselves",
        "missionGroup": "Encourage another character to try again.",
        "description": "Helping & Caring, Friendship & Sharing",
        "bestLifeDomains": [
          "Encourage",
          "Help"
        ],
        "bestStoryActions": [
          "Any"
        ],
        "bestStoryWorlds": [
          "Helping Hand"
        ],
        "bestAdventureArchetypes": [
          "Confidence",
          "Self-Worth"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Strong emotional growth",
        "notes": null
      },
      {
        "id": 67,
        "slug": "help-settle-a-disagreement",
        "name": "Help Settle a Disagreement",
        "missionGroup": "Bring peace between two characters.",
        "description": "Communication, Friendship & Sharing",
        "bestLifeDomains": [
          "Communicate"
        ],
        "bestStoryActions": [
          "Village",
          "Meadow"
        ],
        "bestStoryWorlds": [
          "Friendship Repair"
        ],
        "bestAdventureArchetypes": [
          "Empathy",
          "Understanding"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Listening stories",
        "notes": null
      },
      {
        "id": 68,
        "slug": "help-clean-a-place",
        "name": "Help Clean a Place",
        "missionGroup": "Work together to clean and restore a place.",
        "description": "Responsibility, School & Community",
        "bestLifeDomains": [
          "Organize",
          "Care For"
        ],
        "bestStoryActions": [
          "School",
          "Village",
          "Forest"
        ],
        "bestStoryWorlds": [
          "Community Project"
        ],
        "bestAdventureArchetypes": [
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Service learning",
        "notes": null
      },
      {
        "id": 69,
        "slug": "help-organize-an-event",
        "name": "Help Organize an Event",
        "missionGroup": "Make sure an important event runs smoothly.",
        "description": "Celebrations & Traditions, School & Community",
        "bestLifeDomains": [
          "Organize"
        ],
        "bestStoryActions": [
          "Village",
          "School"
        ],
        "bestStoryWorlds": [
          "Celebration Preparation"
        ],
        "bestAdventureArchetypes": [
          "Responsibility",
          "Teamwork"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Group coordination",
        "notes": null
      },
      {
        "id": 70,
        "slug": "help-care-for-an-animal",
        "name": "Help Care for an Animal",
        "missionGroup": "Look after an animal until it is safe again.",
        "description": "Helping & Caring, Exploring & Nature",
        "bestLifeDomains": [
          "Care For"
        ],
        "bestStoryActions": [
          "Forest",
          "Meadow"
        ],
        "bestStoryWorlds": [
          "Helping Hand"
        ],
        "bestAdventureArchetypes": [
          "Compassion",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Younger audience",
        "notes": null
      },
      {
        "id": 71,
        "slug": "prepare-a-festival",
        "name": "Prepare a Festival",
        "missionGroup": "Get everything ready for a joyful celebration.",
        "description": "Celebrations & Traditions",
        "bestLifeDomains": [
          "Organize",
          "Create"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Festival Adventure"
        ],
        "bestAdventureArchetypes": [
          "Belonging",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Ganesh Chaturthi friendly",
        "notes": null
      },
      {
        "id": 72,
        "slug": "organize-a-surprise",
        "name": "Organize a Surprise",
        "missionGroup": "Plan a surprise for someone special.",
        "description": "Friendship & Sharing",
        "bestLifeDomains": [
          "Organize"
        ],
        "bestStoryActions": [
          "Village",
          "Home"
        ],
        "bestStoryWorlds": [
          "Unexpected Surprise"
        ],
        "bestAdventureArchetypes": [
          "Kindness",
          "Generosity"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Happy ending",
        "notes": null
      },
      {
        "id": 73,
        "slug": "decorate-a-village",
        "name": "Decorate a Village",
        "missionGroup": "Work together to decorate for an event.",
        "description": "Celebrations & Traditions, School & Community",
        "bestLifeDomains": [
          "Create",
          "Organize"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Celebration Preparation"
        ],
        "bestAdventureArchetypes": [
          "Cooperation"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Creative mission",
        "notes": null
      },
      {
        "id": 74,
        "slug": "welcome-guests",
        "name": "Welcome Guests",
        "missionGroup": "Make visitors feel included and comfortable.",
        "description": "Family & Daily Life, Celebrations & Traditions",
        "bestLifeDomains": [
          "Help",
          "Welcome"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Celebration Preparation"
        ],
        "bestAdventureArchetypes": [
          "Belonging",
          "Kindness"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Social skills",
        "notes": null
      },
      {
        "id": 75,
        "slug": "plan-a-performance",
        "name": "Plan a Performance",
        "missionGroup": "Prepare a dance, play or music performance.",
        "description": "Art, Music & Creativity",
        "bestLifeDomains": [
          "Perform",
          "Practice"
        ],
        "bestStoryActions": [
          "Village",
          "School"
        ],
        "bestStoryWorlds": [
          "Performance Story"
        ],
        "bestAdventureArchetypes": [
          "Confidence",
          "Creativity"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Great for stage fright stories",
        "notes": null
      },
      {
        "id": 76,
        "slug": "celebrate-a-milestone",
        "name": "Celebrate a Milestone",
        "missionGroup": "Mark an important achievement together.",
        "description": "Family & Daily Life",
        "bestLifeDomains": [
          "Celebrate"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Festival Adventure"
        ],
        "bestAdventureArchetypes": [
          "Gratitude",
          "Self-Worth"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Emotional ending",
        "notes": null
      },
      {
        "id": 77,
        "slug": "thank-the-helpers",
        "name": "Thank the Helpers",
        "missionGroup": "Show appreciation to those who helped.",
        "description": "Helping & Caring",
        "bestLifeDomains": [
          "Thank",
          "Share"
        ],
        "bestStoryActions": [
          "Any"
        ],
        "bestStoryWorlds": [
          "Gift of Giving"
        ],
        "bestAdventureArchetypes": [
          "Gratitude",
          "Kindness"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Works with Modak",
        "notes": null
      },
      {
        "id": 78,
        "slug": "share-the-harvest",
        "name": "Share the Harvest",
        "missionGroup": "Share food and joy with the community.",
        "description": "Celebrations & Traditions, Helping & Caring",
        "bestLifeDomains": [
          "Share"
        ],
        "bestStoryActions": [
          "Village",
          "Farm"
        ],
        "bestStoryWorlds": [
          "Gift of Giving"
        ],
        "bestAdventureArchetypes": [
          "Generosity",
          "Gratitude"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Community values",
        "notes": null
      },
      {
        "id": 79,
        "slug": "celebrate-a-friendship",
        "name": "Celebrate a Friendship",
        "missionGroup": "Honour a special friendship.",
        "description": "Friendship & Sharing",
        "bestLifeDomains": [
          "Celebrate"
        ],
        "bestStoryActions": [
          "Meadow",
          "Village"
        ],
        "bestStoryWorlds": [
          "Journey Together"
        ],
        "bestAdventureArchetypes": [
          "Belonging"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Heartwarming story",
        "notes": null
      },
      {
        "id": 80,
        "slug": "prepare-a-community-feast",
        "name": "Prepare a Community Feast",
        "missionGroup": "Work together to prepare food for everyone.",
        "description": "Celebrations & Traditions",
        "bestLifeDomains": [
          "Cook",
          "Organize",
          "Share"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Celebration Preparation"
        ],
        "bestAdventureArchetypes": [
          "Cooperation",
          "Generosity"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Team effort",
        "notes": null
      },
      {
        "id": 81,
        "slug": "explore-a-mysterious-forest",
        "name": "Explore a Mysterious Forest",
        "missionGroup": "Discover what lies inside an unknown forest.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Explore"
        ],
        "bestStoryActions": [
          "Forest"
        ],
        "bestStoryWorlds": [
          "Expedition"
        ],
        "bestAdventureArchetypes": [
          "Curiosity",
          "Courage"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Classic adventure",
        "notes": null
      },
      {
        "id": 82,
        "slug": "explore-a-hidden-cave",
        "name": "Explore a Hidden Cave",
        "missionGroup": "Carefully investigate a secret cave.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Explore"
        ],
        "bestStoryActions": [
          "Cave"
        ],
        "bestStoryWorlds": [
          "Hidden World"
        ],
        "bestAdventureArchetypes": [
          "Confidence",
          "Curiosity"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Mystery potential",
        "notes": null
      },
      {
        "id": 83,
        "slug": "explore-a-forgotten-trail",
        "name": "Explore a Forgotten Trail",
        "missionGroup": "Rediscover an old pathway.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Explore"
        ],
        "bestStoryActions": [
          "Forest",
          "Mountain"
        ],
        "bestStoryWorlds": [
          "Expedition"
        ],
        "bestAdventureArchetypes": [
          "Perseverance"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Great with maps",
        "notes": null
      },
      {
        "id": 84,
        "slug": "explore-a-mountain-path",
        "name": "Explore a Mountain Path",
        "missionGroup": "Reach a destination high in the mountains.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Explore",
          "Climb"
        ],
        "bestStoryActions": [
          "Mountain"
        ],
        "bestStoryWorlds": [
          "Great Journey"
        ],
        "bestAdventureArchetypes": [
          "Confidence"
        ],
        "bestCoreNeeds": [
          "Hard"
        ],
        "difficulty": "Physical challenge",
        "notes": null
      },
      {
        "id": 85,
        "slug": "explore-a-new-island",
        "name": "Explore a New Island",
        "missionGroup": "Discover an unfamiliar place.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Explore"
        ],
        "bestStoryActions": [
          "Island",
          "River"
        ],
        "bestStoryWorlds": [
          "Expedition"
        ],
        "bestAdventureArchetypes": [
          "Curiosity"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Discovery story",
        "notes": null
      },
      {
        "id": 86,
        "slug": "explore-an-ancient-garden",
        "name": "Explore an Ancient Garden",
        "missionGroup": "Search a forgotten garden for hidden wonders.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Explore",
          "Observe"
        ],
        "bestStoryActions": [
          "Garden"
        ],
        "bestStoryWorlds": [
          "Secret Discovery"
        ],
        "bestAdventureArchetypes": [
          "Appreciation"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Peaceful exploration",
        "notes": null
      },
      {
        "id": 87,
        "slug": "explore-a-secret-meadow",
        "name": "Explore a Secret Meadow",
        "missionGroup": "Find a magical hidden meadow.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Explore"
        ],
        "bestStoryActions": [
          "Meadow"
        ],
        "bestStoryWorlds": [
          "Secret Discovery"
        ],
        "bestAdventureArchetypes": [
          "Wonder"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Gentle adventure",
        "notes": null
      },
      {
        "id": 88,
        "slug": "explore-the-riverside",
        "name": "Explore the Riverside",
        "missionGroup": "Discover what the river has to teach.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Explore"
        ],
        "bestStoryActions": [
          "River"
        ],
        "bestStoryWorlds": [
          "Expedition"
        ],
        "bestAdventureArchetypes": [
          "Curiosity"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Nature stories",
        "notes": null
      },
      {
        "id": 89,
        "slug": "explore-after-a-storm",
        "name": "Explore After a Storm",
        "missionGroup": "Discover what has changed after bad weather.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Explore",
          "Help"
        ],
        "bestStoryActions": [
          "Forest",
          "River"
        ],
        "bestStoryWorlds": [
          "Nature's Balance"
        ],
        "bestAdventureArchetypes": [
          "Adaptability"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Recovery theme",
        "notes": null
      },
      {
        "id": 90,
        "slug": "explore-an-unvisited-place",
        "name": "Explore an Unvisited Place",
        "missionGroup": "Be the first to safely explore somewhere new.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Explore"
        ],
        "bestStoryActions": [
          "Any"
        ],
        "bestStoryWorlds": [
          "Discovery Journey"
        ],
        "bestAdventureArchetypes": [
          "Courage",
          "Curiosity"
        ],
        "bestCoreNeeds": [
          "Hard"
        ],
        "difficulty": "Open-ended adventure",
        "notes": null
      },
      {
        "id": 91,
        "slug": "care-for-an-injured-animal",
        "name": "Care for an Injured Animal",
        "missionGroup": "Help an injured animal recover.",
        "description": "Helping & Caring",
        "bestLifeDomains": [
          "Care For"
        ],
        "bestStoryActions": [
          "Forest",
          "Meadow"
        ],
        "bestStoryWorlds": [
          "Helping Hand"
        ],
        "bestAdventureArchetypes": [
          "Compassion"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Gentle emotional story",
        "notes": null
      },
      {
        "id": 92,
        "slug": "care-for-a-young-plant",
        "name": "Care for a Young Plant",
        "missionGroup": "Help a plant grow strong and healthy.",
        "description": "Exploring & Nature, Self-Care",
        "bestLifeDomains": [
          "Care For"
        ],
        "bestStoryActions": [
          "Garden"
        ],
        "bestStoryWorlds": [
          "Nature's Balance"
        ],
        "bestAdventureArchetypes": [
          "Patience",
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Nature metaphor",
        "notes": null
      },
      {
        "id": 93,
        "slug": "restore-a-polluted-pond",
        "name": "Restore a Polluted Pond",
        "missionGroup": "Clean and restore a damaged pond.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Restore"
        ],
        "bestStoryActions": [
          "Pond"
        ],
        "bestStoryWorlds": [
          "Nature's Balance",
          "Restoration Story"
        ],
        "bestAdventureArchetypes": [
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Environmental story",
        "notes": null
      },
      {
        "id": 94,
        "slug": "restore-a-damaged-home",
        "name": "Restore a Damaged Home",
        "missionGroup": "Help rebuild a home after damage.",
        "description": "Family & Daily Life",
        "bestLifeDomains": [
          "Repair",
          "Build"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Restoration Story"
        ],
        "bestAdventureArchetypes": [
          "Safety",
          "Belonging"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Community effort",
        "notes": null
      },
      {
        "id": 95,
        "slug": "restore-a-friendship",
        "name": "Restore a Friendship",
        "missionGroup": "Heal a friendship after conflict.",
        "description": "Friendship & Sharing",
        "bestLifeDomains": [
          "Communicate"
        ],
        "bestStoryActions": [
          "Any"
        ],
        "bestStoryWorlds": [
          "Friendship Repair"
        ],
        "bestAdventureArchetypes": [
          "Forgiveness",
          "Empathy"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Emotional arc",
        "notes": null
      },
      {
        "id": 96,
        "slug": "care-for-an-elder",
        "name": "Care for an Elder",
        "missionGroup": "Support an older character with kindness.",
        "description": "Helping & Caring, Family & Daily Life",
        "bestLifeDomains": [
          "Help",
          "Care For"
        ],
        "bestStoryActions": [
          "Village"
        ],
        "bestStoryWorlds": [
          "Helping Hand"
        ],
        "bestAdventureArchetypes": [
          "Respect",
          "Compassion"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Nurturing story",
        "notes": null
      },
      {
        "id": 97,
        "slug": "care-for-a-community-space",
        "name": "Care for a Community Space",
        "missionGroup": "Improve a place everyone shares.",
        "description": "School & Community",
        "bestLifeDomains": [
          "Organize",
          "Restore"
        ],
        "bestStoryActions": [
          "School",
          "Village"
        ],
        "bestStoryWorlds": [
          "Community Project"
        ],
        "bestAdventureArchetypes": [
          "Responsibility"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Shared ownership",
        "notes": null
      },
      {
        "id": 98,
        "slug": "restore-balance-to-nature",
        "name": "Restore Balance to Nature",
        "missionGroup": "Help nature recover from disruption.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Restore"
        ],
        "bestStoryActions": [
          "Forest",
          "River"
        ],
        "bestStoryWorlds": [
          "Nature's Balance"
        ],
        "bestAdventureArchetypes": [
          "Stewardship"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Conservation theme",
        "notes": null
      },
      {
        "id": 99,
        "slug": "help-a-tree-grow-again",
        "name": "Help a Tree Grow Again",
        "missionGroup": "Nurse a damaged tree back to health.",
        "description": "Exploring & Nature",
        "bestLifeDomains": [
          "Care For"
        ],
        "bestStoryActions": [
          "Forest"
        ],
        "bestStoryWorlds": [
          "Nature's Balance"
        ],
        "bestAdventureArchetypes": [
          "Hope",
          "Patience"
        ],
        "bestCoreNeeds": [
          "Easy"
        ],
        "difficulty": "Symbolic growth",
        "notes": null
      },
      {
        "id": 100,
        "slug": "bring-life-back-to-a-forgotten-place",
        "name": "Bring Life Back to a Forgotten Place",
        "missionGroup": "Transform an abandoned place into something beautiful.",
        "description": "Building & Creating, Exploring & Nature",
        "bestLifeDomains": [
          "Restore",
          "Create"
        ],
        "bestStoryActions": [
          "Garden",
          "Village"
        ],
        "bestStoryWorlds": [
          "Restoration Story"
        ],
        "bestAdventureArchetypes": [
          "Hope",
          "Creativity"
        ],
        "bestCoreNeeds": [
          "Medium"
        ],
        "difficulty": "Strong visual transformation",
        "notes": null
      }
    ],
    "obstacles": [
      {
        "id": 1,
        "slug": "broken-bridge",
        "name": "Broken Bridge",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "The bridge cannot be crossed.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore",
          "Rescue"
        ],
        "bestStoryWorlds": [
          "Crystal River Valley"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": "Requires creative solution"
      },
      {
        "id": 2,
        "slug": "fallen-tree",
        "name": "Fallen Tree",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "A tree blocks the path.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore",
          "Help"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Immediate",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 3,
        "slug": "flooded-path",
        "name": "Flooded Path",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "Water covers the trail.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Crystal River Valley"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 4,
        "slug": "thick-fog",
        "name": "Thick Fog",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "It's difficult to see the way.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 5,
        "slug": "storm",
        "name": "Storm",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "Bad weather interrupts the mission.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Rescue",
          "Deliver"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Progressive",
        "difficulty": "Hard",
        "notes": null
      },
      {
        "id": 6,
        "slug": "strong-wind",
        "name": "Strong Wind",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "Wind makes travelling difficult.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Deliver"
        ],
        "bestStoryWorlds": [
          "Misty Mountains"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 7,
        "slug": "darkness",
        "name": "Darkness",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "The hero cannot see clearly.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Hidden Cave Network"
        ],
        "escalationType": "Emotional",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 8,
        "slug": "rocky-climb",
        "name": "Rocky Climb",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "The path is steep and difficult.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Misty Mountains"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 9,
        "slug": "deep-river",
        "name": "Deep River",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "The river blocks the journey.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Rescue",
          "Explore"
        ],
        "bestStoryWorlds": [
          "Crystal River Valley"
        ],
        "escalationType": "Progressive",
        "difficulty": "Hard",
        "notes": null
      },
      {
        "id": 10,
        "slug": "slippery-trail",
        "name": "Slippery Trail",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "The ground is difficult to walk on.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Progressive",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 11,
        "slug": "lost-map",
        "name": "Lost Map",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "The directions are missing.",
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Mystery",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 12,
        "slug": "broken-cart",
        "name": "Broken Cart",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "Transport cannot continue.",
        "bestLifeDomains": [
          "Responsibility"
        ],
        "bestStoryActions": [
          "Deliver"
        ],
        "bestStoryWorlds": [
          "Woodland Village"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 13,
        "slug": "closed-gate",
        "name": "Closed Gate",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "The destination is blocked.",
        "bestLifeDomains": [
          "School & Community"
        ],
        "bestStoryActions": [
          "Deliver"
        ],
        "bestStoryWorlds": [
          "Woodland Village"
        ],
        "escalationType": "Immediate",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 14,
        "slug": "maze",
        "name": "Maze",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "The hero cannot find the exit.",
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Hidden Cave Network"
        ],
        "escalationType": "Mystery",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 15,
        "slug": "steep-hill",
        "name": "Steep Hill",
        "obstacleGroup": "Physical",
        "type": "External",
        "description": "The climb requires persistence.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Misty Mountains"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 16,
        "slug": "heavy-rain",
        "name": "Heavy Rain",
        "obstacleGroup": "Nature",
        "type": "External",
        "description": "Rain slows the journey.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 17,
        "slug": "drought",
        "name": "Drought",
        "obstacleGroup": "Nature",
        "type": "External",
        "description": "Water is scarce.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Help"
        ],
        "bestStoryWorlds": [
          "Whispering Meadow"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 18,
        "slug": "snow",
        "name": "Snow",
        "obstacleGroup": "Nature",
        "type": "External",
        "description": "Snow makes movement difficult.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Misty Mountains"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 19,
        "slug": "sandstorm",
        "name": "Sandstorm",
        "obstacleGroup": "Nature",
        "type": "External",
        "description": "Wind and sand reduce visibility.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Desert Oasis"
        ],
        "escalationType": "Progressive",
        "difficulty": "Hard",
        "notes": null
      },
      {
        "id": 20,
        "slug": "rising-tide",
        "name": "Rising Tide",
        "obstacleGroup": "Nature",
        "type": "External",
        "description": "Water levels keep increasing.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Rescue"
        ],
        "bestStoryWorlds": [
          "Crystal River Valley"
        ],
        "escalationType": "Time Pressure",
        "difficulty": "Hard",
        "notes": null
      },
      {
        "id": 21,
        "slug": "wild-vines",
        "name": "Wild Vines",
        "obstacleGroup": "Nature",
        "type": "External",
        "description": "Plants block the path.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Immediate",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 22,
        "slug": "bees",
        "name": "Bees",
        "obstacleGroup": "Nature",
        "type": "External",
        "description": "Bees guard the area.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Whispering Meadow"
        ],
        "escalationType": "Immediate",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 23,
        "slug": "thorn-bushes",
        "name": "Thorn Bushes",
        "obstacleGroup": "Nature",
        "type": "External",
        "description": "Sharp plants slow progress.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Progressive",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 24,
        "slug": "fast-current",
        "name": "Fast Current",
        "obstacleGroup": "Nature",
        "type": "External",
        "description": "Water moves too quickly.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Rescue"
        ],
        "bestStoryWorlds": [
          "Crystal River Valley"
        ],
        "escalationType": "Progressive",
        "difficulty": "Hard",
        "notes": null
      },
      {
        "id": 25,
        "slug": "dense-forest",
        "name": "Dense Forest",
        "obstacleGroup": "Nature",
        "type": "External",
        "description": "The forest is confusing to navigate.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Mystery",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 26,
        "slug": "friends-disagree",
        "name": "Friends Disagree",
        "obstacleGroup": "Social",
        "type": "Social",
        "description": "Friends cannot agree.",
        "bestLifeDomains": [
          "Friendship & Sharing"
        ],
        "bestStoryActions": [
          "Communicate"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 27,
        "slug": "someone-refuses-to-help",
        "name": "Someone Refuses to Help",
        "obstacleGroup": "Social",
        "type": "Social",
        "description": "Support is unavailable.",
        "bestLifeDomains": [
          "Helping & Caring"
        ],
        "bestStoryActions": [
          "Help"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 28,
        "slug": "someone-lies",
        "name": "Someone Lies",
        "obstacleGroup": "Social",
        "type": "Social",
        "description": "False information causes problems.",
        "bestLifeDomains": [
          "Communication"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Woodland Village"
        ],
        "escalationType": "Mystery",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 29,
        "slug": "rival-team",
        "name": "Rival Team",
        "obstacleGroup": "Social",
        "type": "Social",
        "description": "Another group competes.",
        "bestLifeDomains": [
          "Playing & Games"
        ],
        "bestStoryActions": [
          "Perform"
        ],
        "bestStoryWorlds": [
          "Whispering Meadow"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 30,
        "slug": "misunderstanding",
        "name": "Misunderstanding",
        "obstacleGroup": "Social",
        "type": "Social",
        "description": "Characters misinterpret each other.",
        "bestLifeDomains": [
          "Communication"
        ],
        "bestStoryActions": [
          "Communicate"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 31,
        "slug": "broken-promise",
        "name": "Broken Promise",
        "obstacleGroup": "Social",
        "type": "Social",
        "description": "Trust has been damaged.",
        "bestLifeDomains": [
          "Friendship & Sharing"
        ],
        "bestStoryActions": [
          "Help"
        ],
        "bestStoryWorlds": [
          "Woodland Village"
        ],
        "escalationType": "Emotional",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 32,
        "slug": "nobody-believes-the-hero",
        "name": "Nobody Believes the Hero",
        "obstacleGroup": "Social",
        "type": "Social",
        "description": "Others doubt the hero.",
        "bestLifeDomains": [
          "School & Community"
        ],
        "bestStoryActions": [
          "Communicate"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 33,
        "slug": "someone-quits",
        "name": "Someone Quits",
        "obstacleGroup": "Social",
        "type": "Social",
        "description": "A teammate gives up.",
        "bestLifeDomains": [
          "Helping & Caring"
        ],
        "bestStoryActions": [
          "Help"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 34,
        "slug": "pride",
        "name": "Pride",
        "obstacleGroup": "Social",
        "type": "Social",
        "description": "Someone refuses help.",
        "bestLifeDomains": [
          "Communication"
        ],
        "bestStoryActions": [
          "Communicate"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 35,
        "slug": "poor-communication",
        "name": "Poor Communication",
        "obstacleGroup": "Social",
        "type": "Social",
        "description": "Important information is missed.",
        "bestLifeDomains": [
          "Communication"
        ],
        "bestStoryActions": [
          "Communicate"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Progressive",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 36,
        "slug": "fear",
        "name": "Fear",
        "obstacleGroup": "Emotional",
        "type": "Internal",
        "description": "Fear prevents action.",
        "bestLifeDomains": [
          "Self-Care"
        ],
        "bestStoryActions": [
          "Practice"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 37,
        "slug": "self-doubt",
        "name": "Self-Doubt",
        "obstacleGroup": "Emotional",
        "type": "Internal",
        "description": "The hero questions themselves.",
        "bestLifeDomains": [
          "Self-Care"
        ],
        "bestStoryActions": [
          "Learn"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 38,
        "slug": "anger",
        "name": "Anger",
        "obstacleGroup": "Emotional",
        "type": "Internal",
        "description": "Anger clouds judgement.",
        "bestLifeDomains": [
          "Communication"
        ],
        "bestStoryActions": [
          "Practice"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 39,
        "slug": "jealousy",
        "name": "Jealousy",
        "obstacleGroup": "Emotional",
        "type": "Internal",
        "description": "Comparison causes conflict.",
        "bestLifeDomains": [
          "Friendship & Sharing"
        ],
        "bestStoryActions": [
          "Share"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 40,
        "slug": "impatience",
        "name": "Impatience",
        "obstacleGroup": "Emotional",
        "type": "Internal",
        "description": "The hero rushes.",
        "bestLifeDomains": [
          "Self-Care"
        ],
        "bestStoryActions": [
          "Practice"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Progressive",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 41,
        "slug": "embarrassment",
        "name": "Embarrassment",
        "obstacleGroup": "Emotional",
        "type": "Internal",
        "description": "Fear of being judged.",
        "bestLifeDomains": [
          "School & Community"
        ],
        "bestStoryActions": [
          "Perform"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 42,
        "slug": "loneliness",
        "name": "Loneliness",
        "obstacleGroup": "Emotional",
        "type": "Internal",
        "description": "Feeling left out.",
        "bestLifeDomains": [
          "Friendship & Sharing"
        ],
        "bestStoryActions": [
          "Share"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 43,
        "slug": "guilt",
        "name": "Guilt",
        "obstacleGroup": "Emotional",
        "type": "Internal",
        "description": "Regret makes progress difficult.",
        "bestLifeDomains": [
          "Responsibility"
        ],
        "bestStoryActions": [
          "Communicate"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 44,
        "slug": "worry",
        "name": "Worry",
        "obstacleGroup": "Emotional",
        "type": "Internal",
        "description": "Constant worrying blocks action.",
        "bestLifeDomains": [
          "Self-Care"
        ],
        "bestStoryActions": [
          "Practice"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Emotional",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 45,
        "slug": "perfectionism",
        "name": "Perfectionism",
        "obstacleGroup": "Emotional",
        "type": "Internal",
        "description": "Fear of making mistakes.",
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestStoryActions": [
          "Practice"
        ],
        "bestStoryWorlds": [
          "Any Story World"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 46,
        "slug": "hidden-clue",
        "name": "Hidden Clue",
        "obstacleGroup": "Puzzle",
        "type": "External",
        "description": "An important clue is difficult to find.",
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Mystery",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 47,
        "slug": "secret-code",
        "name": "Secret Code",
        "obstacleGroup": "Puzzle",
        "type": "External",
        "description": "A coded message must be solved.",
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestStoryActions": [
          "Solve"
        ],
        "bestStoryWorlds": [
          "Story House"
        ],
        "escalationType": "Mystery",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 48,
        "slug": "locked-door",
        "name": "Locked Door",
        "obstacleGroup": "Puzzle",
        "type": "External",
        "description": "The hero must find a way inside.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Hidden Cave Network"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 49,
        "slug": "missing-key",
        "name": "Missing Key",
        "obstacleGroup": "Puzzle",
        "type": "External",
        "description": "The key is lost.",
        "bestLifeDomains": [
          "Responsibility"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Woodland Village"
        ],
        "escalationType": "Mystery",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 50,
        "slug": "wrong-clue",
        "name": "Wrong Clue",
        "obstacleGroup": "Puzzle",
        "type": "External",
        "description": "A clue leads in the wrong direction.",
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 51,
        "slug": "riddle",
        "name": "Riddle",
        "obstacleGroup": "Puzzle",
        "type": "External",
        "description": "A riddle blocks progress.",
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestStoryActions": [
          "Solve"
        ],
        "bestStoryWorlds": [
          "Ancient Banyan Grove"
        ],
        "escalationType": "Mystery",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 52,
        "slug": "strange-footprints",
        "name": "Strange Footprints",
        "obstacleGroup": "Puzzle",
        "type": "External",
        "description": "Tracks must be followed correctly.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Mystery",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 53,
        "slug": "ancient-symbol",
        "name": "Ancient Symbol",
        "obstacleGroup": "Puzzle",
        "type": "External",
        "description": "A symbol must be understood.",
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Temple Courtyard"
        ],
        "escalationType": "Mystery",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 54,
        "slug": "invisible-path",
        "name": "Invisible Path",
        "obstacleGroup": "Puzzle",
        "type": "External",
        "description": "The correct route is hidden.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 55,
        "slug": "pattern-to-solve",
        "name": "Pattern to Solve",
        "obstacleGroup": "Puzzle",
        "type": "External",
        "description": "A sequence must be recognised.",
        "bestLifeDomains": [
          "Learning & Problem Solving"
        ],
        "bestStoryActions": [
          "Solve"
        ],
        "bestStoryWorlds": [
          "Story House"
        ],
        "escalationType": "Mystery",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 56,
        "slug": "before-sunset",
        "name": "Before Sunset",
        "obstacleGroup": "Time",
        "type": "External",
        "description": "Finish before the sun sets.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Time Pressure",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 57,
        "slug": "before-the-rain-arrives",
        "name": "Before the Rain Arrives",
        "obstacleGroup": "Time",
        "type": "External",
        "description": "Complete the mission before rain starts.",
        "bestLifeDomains": [
          "Helping & Caring"
        ],
        "bestStoryActions": [
          "Build"
        ],
        "bestStoryWorlds": [
          "Woodland Village"
        ],
        "escalationType": "Time Pressure",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 58,
        "slug": "festival-begins-soon",
        "name": "Festival Begins Soon",
        "obstacleGroup": "Time",
        "type": "External",
        "description": "Prepare everything before the celebration.",
        "bestLifeDomains": [
          "Celebrations & Traditions"
        ],
        "bestStoryActions": [
          "Organize"
        ],
        "bestStoryWorlds": [
          "Woodland Village"
        ],
        "escalationType": "Time Pressure",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 59,
        "slug": "river-is-rising",
        "name": "River is Rising",
        "obstacleGroup": "Time",
        "type": "External",
        "description": "Cross before the river becomes dangerous.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Rescue"
        ],
        "bestStoryWorlds": [
          "Crystal River Valley"
        ],
        "escalationType": "Time Pressure",
        "difficulty": "Hard",
        "notes": null
      },
      {
        "id": 60,
        "slug": "moon-will-disappear",
        "name": "Moon Will Disappear",
        "obstacleGroup": "Time",
        "type": "External",
        "description": "Finish before moonlight is gone.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Search"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Time Pressure",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 61,
        "slug": "guests-are-arriving",
        "name": "Guests Are Arriving",
        "obstacleGroup": "Time",
        "type": "External",
        "description": "Everything must be ready in time.",
        "bestLifeDomains": [
          "Family & Daily Life"
        ],
        "bestStoryActions": [
          "Organize"
        ],
        "bestStoryWorlds": [
          "Woodland Village"
        ],
        "escalationType": "Time Pressure",
        "difficulty": "Easy",
        "notes": null
      },
      {
        "id": 62,
        "slug": "supplies-are-running-out",
        "name": "Supplies Are Running Out",
        "obstacleGroup": "Time",
        "type": "External",
        "description": "Resources are almost finished.",
        "bestLifeDomains": [
          "Responsibility"
        ],
        "bestStoryActions": [
          "Deliver"
        ],
        "bestStoryWorlds": [
          "Woodland Village"
        ],
        "escalationType": "Progressive",
        "difficulty": "Medium",
        "notes": null
      },
      {
        "id": 63,
        "slug": "daylight-is-fading",
        "name": "Daylight is Fading",
        "obstacleGroup": "Time",
        "type": "External",
        "description": "Darkness is approaching quickly.",
        "bestLifeDomains": [
          "Exploring & Nature"
        ],
        "bestStoryActions": [
          "Explore"
        ],
        "bestStoryWorlds": [
          "Whispering Forest"
        ],
        "escalationType": "Time Pressure",
        "difficulty": "Medium",
        "notes": null
      }
    ],
    "storyStructures": [
      {
        "id": 1,
        "slug": "clever-underdog",
        "name": "Clever Underdog",
        "number": 1,
        "corePattern": "Small Hero → Danger → Clever Invention → Twist → Adapt → Triumph",
        "description": "A small hero overcomes a bigger challenge through intelligence.",
        "whyItWorks": "Builds confidence and creative problem-solving.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Hero → Problem → Clever Attempt → Twist → New Plan → Success → Celebration",
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Mystery to Solve",
          "Problem Solver"
        ],
        "bestOpening": "The Unexpected Interruption",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Sound Words (Onomatopoeia)"
        ]
      },
      {
        "id": 2,
        "slug": "emotional-harbor",
        "name": "Emotional Harbor",
        "number": 2,
        "corePattern": "Outburst → Symbol World → Exploration → Mastery → Realization → Return",
        "description": "Big emotions become a safe inner adventure.",
        "whyItWorks": "Helps children process emotions safely.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Emotion → New World → Explore → Reflection → Insight → Return",
        "bestAdventureArchetypes": [
          "Dream Adventure",
          "Restoration Story",
          "Discovery Journey"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 3,
        "slug": "rhythmic-growth",
        "name": "Rhythmic Growth",
        "number": 3,
        "corePattern": "Need → Sequential Steps → Overreach → Setback → Stillness → Bloom",
        "description": "Growth happens through patience and mistakes.",
        "whyItWorks": "Mirrors natural development.",
        "bestAge": "5–6",
        "sceneFlowTemplate": "Goal → Progress → Mistake → Pause → Growth → Transformation",
        "bestAdventureArchetypes": [
          "Nature's Balance",
          "Transformation Story"
        ],
        "bestOpening": "The Everyday Wonder",
        "bestEnding": "Nature Responds",
        "bestReplayHooks": [
          "Nature Cycle"
        ],
        "bestReadAloudDevices": [
          "Musical Sentence"
        ]
      },
      {
        "id": 4,
        "slug": "mindful-catalog",
        "name": "Mindful Catalog",
        "number": 4,
        "corePattern": "Sanctuary → Observation → Acknowledgment → Dimming → Stillness",
        "description": "Calm is found by slowly noticing the world.",
        "whyItWorks": "Encourages mindfulness and emotional regulation.",
        "bestAge": "5–6",
        "sceneFlowTemplate": "Safe Place → Observe → Slow Down → Quiet → Peace",
        "bestAdventureArchetypes": [
          "Dream Adventure"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 5,
        "slug": "playful-comparison",
        "name": "Playful Comparison",
        "number": 5,
        "corePattern": "Intimacy → Challenge → Escalation → Nature Vista → Infinite Reassurance",
        "description": "A playful comparison reveals limitless love.",
        "whyItWorks": "Makes abstract emotions tangible.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Conversation → Comparison → Bigger Comparison → Beautiful Reveal → Comfort",
        "bestAdventureArchetypes": [
          "Promise Keeper",
          "New Friend"
        ],
        "bestOpening": "The Promise",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 6,
        "slug": "shared-wait",
        "name": "Shared Wait",
        "number": 6,
        "corePattern": "Departure → Uncertainty → Different Responses → Mutual Comfort → Return → Relief",
        "description": "Friends wait together until someone they love returns.",
        "whyItWorks": "Supports separation anxiety and trust.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Goodbye → Waiting → Different Reactions → Comfort → Reunion",
        "bestAdventureArchetypes": [
          "Race Against Time",
          "Journey Together"
        ],
        "bestOpening": "The Unexpected Interruption",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Heartbeat Moment"
        ]
      },
      {
        "id": 7,
        "slug": "interactive-guardrail",
        "name": "Interactive Guardrail",
        "number": 7,
        "corePattern": "Assignment → Temptation → Negotiation → Escalation → Boundary Holds → New Focus",
        "description": "A playful character tries to break an important rule.",
        "whyItWorks": "Builds impulse control through humour.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Rule → Temptation → Funny Excuses → Decision → Respect Rule",
        "bestAdventureArchetypes": [
          "Choice & Consequence",
          "Unexpected Surprise"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Choice Reflection"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 8,
        "slug": "unstoppable-chain",
        "name": "Unstoppable Chain",
        "number": 8,
        "corePattern": "Trigger → Logical Demand → Action → New Need → Escalation → Loop",
        "description": "One small action creates a growing chain of consequences.",
        "whyItWorks": "Teaches logical cause and effect.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Small Event → Bigger Event → Bigger Event → Circular Finish",
        "bestAdventureArchetypes": [
          "Problem Solver",
          "Unexpected Surprise"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 9,
        "slug": "solo-sensory-trek",
        "name": "Solo Sensory Trek",
        "number": 9,
        "corePattern": "Waking → Discovery → Exploration → Sensory Wonder → Reflection",
        "description": "Quiet exploration leads to wonder.",
        "whyItWorks": "Encourages observation and curiosity.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Wake → Explore → Discover → Reflect → Peaceful Ending",
        "bestAdventureArchetypes": [
          "Secret Discovery",
          "Nature's Balance"
        ],
        "bestOpening": "The Tiny Mystery",
        "bestEnding": "The Gentle Surprise",
        "bestReplayHooks": [
          "Foreshadowed Prop"
        ],
        "bestReadAloudDevices": [
          "Point-and-Find"
        ]
      },
      {
        "id": 10,
        "slug": "flaw-as-quest",
        "name": "Flaw as Quest",
        "number": 10,
        "corePattern": "Longing → Perceived Flaw → Determination → Mishap → Discovery → Acceptance",
        "description": "A character learns they never needed to change to be worthy.",
        "whyItWorks": "Builds self-worth.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Wish → Try to Change → Fail → Discovery → Acceptance",
        "bestAdventureArchetypes": [
          "Coming of Age"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Circular Return",
        "bestReplayHooks": [
          "Echo Scene"
        ],
        "bestReadAloudDevices": [
          "Silent Spread"
        ]
      },
      {
        "id": 11,
        "slug": "validated-grump",
        "name": "Validated Grump",
        "number": 11,
        "corePattern": "Bad Start → Setbacks → Emotional Overflow → Being Heard → Soft Acceptance",
        "description": "A terrible day becomes easier because someone understands.",
        "whyItWorks": "Validates emotions instead of fixing them.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Bad Day → More Problems → Emotional Peak → Comfort → Calm Ending",
        "bestAdventureArchetypes": [
          "Training Journey",
          "Community Project"
        ],
        "bestOpening": "The Impossible Task",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Repeated Action"
        ]
      },
      {
        "id": 12,
        "slug": "surprise-visitor",
        "name": "Surprise Visitor",
        "number": 12,
        "corePattern": "Routine → Unexpected Visitor → Escalating Disruption → Adaptation → Farewell",
        "description": "A surprising guest changes everyone's plans.",
        "whyItWorks": "Encourages flexibility and acceptance.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Quiet Routine → Visitor → Chaos → Adapt → Happy Goodbye",
        "bestAdventureArchetypes": [
          "Unexpected Surprise"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 13,
        "slug": "world-creator",
        "name": "World Creator",
        "number": 13,
        "corePattern": "Decision → World Building → Exploration → Hurdle → Creative Escape → Home",
        "description": "Imagination creates the adventure itself.",
        "whyItWorks": "Encourages creativity and agency.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Imagine → Build → Explore → Solve → Return Home",
        "bestAdventureArchetypes": [
          "Magical Discovery",
          "Expedition"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 14,
        "slug": "call-and-response",
        "name": "Call-and-Response",
        "number": 14,
        "corePattern": "Question → Answer → New Question → Growing Chain → Group Finale",
        "description": "Repeating questions build rhythm and joyful anticipation.",
        "whyItWorks": "Builds participation and prediction.",
        "bestAge": "5–6",
        "sceneFlowTemplate": "Question → Answer → Repeat → Group Celebration",
        "bestAdventureArchetypes": [
          "Community Project",
          "Team Adventure"
        ],
        "bestOpening": "The Invitation",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Background Story"
        ],
        "bestReadAloudDevices": [
          "Call and Response"
        ]
      },
      {
        "id": 15,
        "slug": "portable-anchor",
        "name": "Portable Anchor",
        "number": 15,
        "corePattern": "Anxiety → Ritual → Practice → Challenge → Confidence → Reunion",
        "description": "A simple ritual gives courage during change.",
        "whyItWorks": "Helps children cope with transitions.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Fear → Learn Ritual → Practice → Brave Moment → Success",
        "bestAdventureArchetypes": [
          "Hero's Trial"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Parallel Action"
        ],
        "bestReadAloudDevices": [
          "Rule of Three"
        ]
      },
      {
        "id": 16,
        "slug": "hospitality-chain",
        "name": "Hospitality Chain",
        "number": 16,
        "corePattern": "Journey → Invitation → Growing Team → Threat → Teamwork → Celebration",
        "description": "Every new friend strengthens the group.",
        "whyItWorks": "Reinforces inclusion and teamwork.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Journey → Meet Friends → Bigger Team → Problem → Team Victory",
        "bestAdventureArchetypes": [
          "New Friend",
          "Community Project"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Friendship Moments"
        ],
        "bestReadAloudDevices": [
          "Character Catchphrase"
        ]
      },
      {
        "id": 17,
        "slug": "perspective-reframe",
        "name": "Perspective Reframe",
        "number": 17,
        "corePattern": "Complaint → Journey → Mentor → New Perspective → Gratitude",
        "description": "Seeing the world differently changes the hero.",
        "whyItWorks": "Encourages gratitude and empathy.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Complaint → Adventure → Observe → Realize → Appreciate",
        "bestAdventureArchetypes": [
          "Heritage Journey"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Mentor Clue"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 18,
        "slug": "secret-witness",
        "name": "Secret Witness",
        "number": 18,
        "corePattern": "Simple Mission → Hidden Parallel Story → Escalation → Safe Finish",
        "description": "Readers know something the hero doesn't.",
        "whyItWorks": "Creates dramatic irony and replay value.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Mission → Hidden Events → Escalation → Hero Unaware → Finish",
        "bestAdventureArchetypes": [
          "Unexpected Surprise",
          "Mystery to Solve"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 19,
        "slug": "copycat-mirror",
        "name": "Copycat Mirror",
        "number": 19,
        "corePattern": "Routine → Loss → Mimicry → Observation → Trick → Recovery",
        "description": "A repeating pattern becomes the solution.",
        "whyItWorks": "Develops observation and problem-solving.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Loss → Frustration → Notice Pattern → Clever Trick → Success",
        "bestAdventureArchetypes": [
          "Problem Solver",
          "Unexpected Surprise"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 20,
        "slug": "tiny-spark",
        "name": "Tiny Spark",
        "number": 20,
        "corePattern": "Paralysis → Tiny Step → Experiment → Confidence → Mentorship",
        "description": "One tiny action grows into confidence.",
        "whyItWorks": "Teaches growth mindset and persistence.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Fear → First Step → Practice → Success → Inspire Others",
        "bestAdventureArchetypes": [
          "Transformation Story",
          "Build Together"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 21,
        "slug": "separation-anxiety",
        "name": "Separation Anxiety",
        "number": 21,
        "corePattern": "Home → Separation → Parallel Routine → Near Miss → Reunion",
        "description": "Two sides experience the same separation until they're reunited.",
        "whyItWorks": "Reassures children that love continues even when apart.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Goodbye → Parallel Lives → Missing Each Other → Reunion",
        "bestAdventureArchetypes": [
          "Journey Together",
          "Transformation Story"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 22,
        "slug": "city-crossing",
        "name": "City Crossing",
        "number": 22,
        "corePattern": "Safe Place → Journey → Big Obstacle → Helper → Arrival",
        "description": "A small hero safely navigates a much bigger world.",
        "whyItWorks": "Builds courage for unfamiliar environments.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Home → Travel → Major Obstacle → Help → Destination",
        "bestAdventureArchetypes": [
          "Great Journey",
          "Expedition"
        ],
        "bestOpening": "The Unexpected Interruption",
        "bestEnding": "The Circular Return",
        "bestReplayHooks": [
          "Secret Path"
        ],
        "bestReadAloudDevices": [
          "Repeated Phrase"
        ]
      },
      {
        "id": 23,
        "slug": "shifting-world",
        "name": "Shifting World",
        "number": 23,
        "corePattern": "Peace → Change → Loss → Discovery → Restoration",
        "description": "A changing world creates loss before a hopeful renewal.",
        "whyItWorks": "Helps children process change and transition.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Happy Beginning → Disruption → Sadness → Hope → Renewal",
        "bestAdventureArchetypes": [
          "Transformation Story",
          "Nature's Balance"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 24,
        "slug": "mirror-mistake",
        "name": "Mirror Mistake",
        "number": 24,
        "corePattern": "Discovery → Ambition → Fail → Fail Again → Disappointment → Surprise Success",
        "description": "Repeated failures unexpectedly lead to success.",
        "whyItWorks": "Encourages persistence after mistakes.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Goal → Try → Fail → Learn → Unexpected Reward",
        "bestAdventureArchetypes": [
          "Transformation Story",
          "Unexpected Surprise"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 25,
        "slug": "absurd-extraction",
        "name": "Absurd Extraction",
        "number": 25,
        "corePattern": "Problem → Routine → Strange Discovery → Bigger Discovery → Resolution",
        "description": "A normal situation becomes increasingly ridiculous.",
        "whyItWorks": "Creates humor through escalating surprise.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Small Problem → Weird Discovery → Bigger Surprise → Funny Ending",
        "bestAdventureArchetypes": [
          "Unexpected Surprise",
          "Mystery to Solve"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 26,
        "slug": "surreal-night",
        "name": "Surreal Night",
        "number": 26,
        "corePattern": "Night → Transformation → Exploration → Close Call → Morning",
        "description": "An ordinary night becomes a magical adventure.",
        "whyItWorks": "Balances imagination with emotional safety.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Bedtime → Magic → Adventure → Escape → Wake Up",
        "bestAdventureArchetypes": [
          "Magical Quest"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 27,
        "slug": "mirror-invitation",
        "name": "Mirror Invitation",
        "number": 27,
        "corePattern": "Question → Introductions → Growing Chain → Community",
        "description": "One invitation grows into a joyful gathering.",
        "whyItWorks": "Celebrates belonging and inclusion.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Invitation → Meet Others → Bigger Group → Celebration",
        "bestAdventureArchetypes": [
          "New Friend",
          "Community Project"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Friendship Moments"
        ],
        "bestReadAloudDevices": [
          "Character Catchphrase"
        ]
      },
      {
        "id": 28,
        "slug": "subversive-princess",
        "name": "Subversive Princess",
        "number": 28,
        "corePattern": "Peril → Humility → Clever Thinking → Victory → Healthy Boundary",
        "description": "Expectations are overturned through wit instead of force.",
        "whyItWorks": "Challenges stereotypes and rewards intelligence.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Danger → Underestimated Hero → Clever Plan → Victory",
        "bestAdventureArchetypes": [
          "Hero's Trial",
          "Problem Solver"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Parallel Action"
        ],
        "bestReadAloudDevices": [
          "Rule of Three"
        ]
      },
      {
        "id": 29,
        "slug": "unique-eye",
        "name": "Unique Eye",
        "number": 29,
        "corePattern": "Group → Difference → Solitary Discovery → Leadership → Unity",
        "description": "A unique perspective becomes everyone's strength.",
        "whyItWorks": "Celebrates individuality.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Different Hero → Discovery → Others Learn → Shared Success",
        "bestAdventureArchetypes": [
          "Leadership Challenge",
          "Secret Discovery"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 30,
        "slug": "functional-shift",
        "name": "Functional Shift",
        "number": 30,
        "corePattern": "Ordinary Object → Innovation → Mockery → Proof → Acceptance",
        "description": "A strange idea becomes obviously useful.",
        "whyItWorks": "Encourages creativity despite criticism.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "New Idea → Others Laugh → Demonstration → Acceptance",
        "bestAdventureArchetypes": [
          "Problem Solver"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 31,
        "slug": "shared-scale",
        "name": "Shared Scale",
        "number": 31,
        "corePattern": "Vanity → Request → Isolation → Advice → Sharing → Belonging",
        "description": "Happiness grows through sharing instead of keeping.",
        "whyItWorks": "Builds generosity and empathy.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Wants More → Feels Alone → Learns → Shares → Friends Return",
        "bestAdventureArchetypes": [
          "Community Project",
          "Helping Hand"
        ],
        "bestOpening": "The Invitation",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Background Story"
        ],
        "bestReadAloudDevices": [
          "Call and Response"
        ]
      },
      {
        "id": 32,
        "slug": "disguise-trap",
        "name": "Disguise Trap",
        "number": 32,
        "corePattern": "Difference → Hide → Pretend → Unhappiness → Reveal → Acceptance",
        "description": "Pretending to fit in prevents true belonging.",
        "whyItWorks": "Reinforces authenticity.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Feel Different → Hide → Problems Grow → Reveal → Accepted",
        "bestAdventureArchetypes": [
          "Coming of Age"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Circular Return",
        "bestReplayHooks": [
          "Echo Scene"
        ],
        "bestReadAloudDevices": [
          "Silent Spread"
        ]
      },
      {
        "id": 33,
        "slug": "role-reversal",
        "name": "Role Reversal",
        "number": 33,
        "corePattern": "Helper Gives → Helper Needs Help → Friends Respond → Balance Restored",
        "description": "Today's helper becomes tomorrow's receiver.",
        "whyItWorks": "Teaches interdependence and gratitude.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Helping Others → Needs Help → Community Helps Back",
        "bestAdventureArchetypes": [
          "New Friend",
          "Community Project"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Friendship Moments"
        ],
        "bestReadAloudDevices": [
          "Character Catchphrase"
        ]
      },
      {
        "id": 34,
        "slug": "perspective-bus",
        "name": "Perspective Bus",
        "number": 34,
        "corePattern": "Complaint → Journey → Gentle Guide → New Eyes → Joy",
        "description": "A mentor changes how the hero sees everyday life.",
        "whyItWorks": "Encourages gratitude without preaching.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Complaint → Observe → Notice Beauty → Appreciate",
        "bestAdventureArchetypes": [
          "Heritage Journey"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Mentor Clue"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 35,
        "slug": "secret-skill",
        "name": "Secret Skill",
        "number": 35,
        "corePattern": "Teaching → Rival Success → Conflict → Realization → Teamwork",
        "description": "Competition becomes collaboration.",
        "whyItWorks": "Shows everyone has different strengths.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Teach → Conflict → Separation → Reconcile → Team Victory",
        "bestAdventureArchetypes": [
          "Friendship Repair",
          "Team Adventure"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 36,
        "slug": "silent-secret",
        "name": "Silent Secret",
        "number": 36,
        "corePattern": "Ordinary Routine → Hidden Chaos → Escalation → Peaceful Ending",
        "description": "Readers discover the hidden story while the hero never does.",
        "whyItWorks": "Creates replay value through dramatic irony.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Hero Walks → Secret Events → Escalation → Hero Returns",
        "bestAdventureArchetypes": [
          "Unexpected Surprise",
          "Mystery to Solve"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 37,
        "slug": "echo-puzzle",
        "name": "Echo Puzzle",
        "number": 37,
        "corePattern": "Loss → Sound Clue → Frustration → Careful Listening → Discovery",
        "description": "Listening solves the mystery.",
        "whyItWorks": "Reinforces observation and patience.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Problem → Hear Clue → Wrong Guess → Listen Better → Solve",
        "bestAdventureArchetypes": [
          "Mystery to Solve",
          "Detective Story"
        ],
        "bestOpening": "The Tiny Mystery",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Object Hunt"
        ],
        "bestReadAloudDevices": [
          "Prediction Pause"
        ]
      },
      {
        "id": 38,
        "slug": "first-seed",
        "name": "First Seed",
        "number": 38,
        "corePattern": "Fear → Tiny Step → Repetition → Growth → Sharing",
        "description": "Small actions grow into lasting confidence.",
        "whyItWorks": "Excellent for growth mindset stories.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Fear → First Step → Progress → Success → Help Others",
        "bestAdventureArchetypes": [
          "Transformation Story",
          "Hero's Trial"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 39,
        "slug": "mystery-friend",
        "name": "Mystery Friend",
        "number": 39,
        "corePattern": "Strange Sign → Fear → Investigation → Helpful Truth",
        "description": "Something frightening becomes something wonderful.",
        "whyItWorks": "Reframes fear through curiosity.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Strange Event → Investigation → Discovery → Friendship",
        "bestAdventureArchetypes": [
          "Mystery to Solve",
          "Secret Discovery"
        ],
        "bestOpening": "The Tiny Mystery",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Object Hunt"
        ],
        "bestReadAloudDevices": [
          "Prediction Pause"
        ]
      },
      {
        "id": 40,
        "slug": "echo-cave",
        "name": "Echo Cave",
        "number": 40,
        "corePattern": "Anger → Loud Reaction → Wise Advice → Gentle Response → Light",
        "description": "Calm words change the outcome.",
        "whyItWorks": "Teaches emotional regulation naturally.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Anger → Consequences → Reflection → Calm Choice → Resolution",
        "bestAdventureArchetypes": [
          "Transformation Story",
          "Heritage Journey"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 41,
        "slug": "shared-light",
        "name": "Shared Light",
        "number": 41,
        "corePattern": "Question → Demonstration → Multiplication → Shared Peace",
        "description": "Kindness grows when it is shared.",
        "whyItWorks": "Demonstrates that goodness multiplies.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Question → Demonstration → Others Join → Community Joy",
        "bestAdventureArchetypes": [
          "Helping Hand",
          "Community Project"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 42,
        "slug": "lantern-wait",
        "name": "Lantern Wait",
        "number": 42,
        "corePattern": "Mission → Waiting → Different Coping Styles → Reunion",
        "description": "Waiting becomes easier through hope and togetherness.",
        "whyItWorks": "Helps children handle uncertainty.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Mission → Wait → Different Reactions → Reunion",
        "bestAdventureArchetypes": [
          "Race Against Time",
          "Journey Together"
        ],
        "bestOpening": "The Unexpected Interruption",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Heartbeat Moment"
        ]
      },
      {
        "id": 43,
        "slug": "impulse-bell",
        "name": "Impulse Bell",
        "number": 43,
        "corePattern": "Rule → Temptation → Excuses → Wise Choice → Reward",
        "description": "The hero resists temptation through self-control.",
        "whyItWorks": "Builds impulse control.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Rule → Temptation → Internal Conflict → Good Choice → Success",
        "bestAdventureArchetypes": [
          "Choice & Consequence",
          "Responsibility Quest"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Choice Reflection"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 44,
        "slug": "banyan-seed-chain",
        "name": "Banyan Seed Chain",
        "number": 44,
        "corePattern": "Plant → Care → New Need → Growth → Bigger Chain",
        "description": "One good deed creates another.",
        "whyItWorks": "Shows ripple effects of kindness.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Plant → Care → More Help Needed → Growth → Celebration",
        "bestAdventureArchetypes": [
          "Problem Solver",
          "Community Project"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 45,
        "slug": "lotus-watch",
        "name": "Lotus Watch",
        "number": 45,
        "corePattern": "Bloom → Observation → Discovery → Reflection",
        "description": "Watching nature leads to inner wisdom.",
        "whyItWorks": "Encourages mindfulness and patience.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Observe → Explore → Realize → Quiet Ending",
        "bestAdventureArchetypes": [
          "Nature's Balance",
          "Dream Adventure"
        ],
        "bestOpening": "The Everyday Wonder",
        "bestEnding": "Nature Responds",
        "bestReplayHooks": [
          "Nature Cycle"
        ],
        "bestReadAloudDevices": [
          "Musical Sentence"
        ]
      },
      {
        "id": 46,
        "slug": "crooked-shape",
        "name": "Crooked Shape",
        "number": 46,
        "corePattern": "Flaw → Try to Fix → Bigger Problem → Wisdom → Joy",
        "description": "Imperfection becomes the character's strength.",
        "whyItWorks": "Builds self-acceptance.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Feel Flawed → Fix Attempts → Failure → Acceptance → Happiness",
        "bestAdventureArchetypes": [
          "Coming of Age"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Circular Return",
        "bestReplayHooks": [
          "Echo Scene"
        ],
        "bestReadAloudDevices": [
          "Silent Spread"
        ]
      },
      {
        "id": 47,
        "slug": "muddy-day",
        "name": "Muddy Day",
        "number": 47,
        "corePattern": "Setbacks → More Setbacks → Silence → Reframe → Fresh Start",
        "description": "A difficult day ends with a healthier perspective.",
        "whyItWorks": "Normalizes bad days.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Bad Events → Emotional Low → Reflection → Hope",
        "bestAdventureArchetypes": [
          "Training Journey",
          "Transformation Story"
        ],
        "bestOpening": "The Impossible Task",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Repeated Action"
        ]
      },
      {
        "id": 48,
        "slug": "cloud-guest",
        "name": "Cloud Guest",
        "number": 48,
        "corePattern": "Celebration → Unexpected Change → Adaptation → New Joy",
        "description": "Unexpected disruptions become opportunities.",
        "whyItWorks": "Encourages flexibility.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Plan → Disruption → Adapt → Better Outcome",
        "bestAdventureArchetypes": [
          "Unexpected Surprise"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 49,
        "slug": "golden-path",
        "name": "Golden Path",
        "number": 49,
        "corePattern": "Tool → Creative Journey → Adventure → Home",
        "description": "A simple tool unlocks imagination.",
        "whyItWorks": "Celebrates creativity.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Tool Found → Adventure → Problem Solved → Return",
        "bestAdventureArchetypes": [
          "Magical Discovery",
          "Expedition"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 50,
        "slug": "smile-chain",
        "name": "Smile Chain",
        "number": 50,
        "corePattern": "Question → Nature Answers → Community Answers → Personal Discovery",
        "description": "Happiness is discovered everywhere.",
        "whyItWorks": "Reinforces optimism.",
        "bestAge": "5–6",
        "sceneFlowTemplate": "Question → Discover → Share → Joyful Ending",
        "bestAdventureArchetypes": [
          "Secret Discovery",
          "Community Project"
        ],
        "bestOpening": "The Tiny Mystery",
        "bestEnding": "The Gentle Surprise",
        "bestReplayHooks": [
          "Foreshadowed Prop"
        ],
        "bestReadAloudDevices": [
          "Point-and-Find"
        ]
      },
      {
        "id": 51,
        "slug": "spiral-breath",
        "name": "Spiral Breath",
        "number": 51,
        "corePattern": "Fear → Restlessness → Guided Breath → Self-Regulation → Success",
        "description": "Breathing transforms fear into courage.",
        "whyItWorks": "Excellent emotional regulation model.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Fear → Learn Breathing → Practice → Brave Action",
        "bestAdventureArchetypes": [
          "Hero's Trial",
          "Transformation Story"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Parallel Action"
        ],
        "bestReadAloudDevices": [
          "Rule of Three"
        ]
      },
      {
        "id": 52,
        "slug": "nest-build",
        "name": "Nest Build",
        "number": 52,
        "corePattern": "Gather → Invite → Danger → Team Solution → Bigger Home",
        "description": "Working together creates something stronger.",
        "whyItWorks": "Reinforces teamwork.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Build → Friends Join → Threat → Solve Together",
        "bestAdventureArchetypes": [
          "Community Project",
          "Build Together"
        ],
        "bestOpening": "The Invitation",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Background Story"
        ],
        "bestReadAloudDevices": [
          "Call and Response"
        ]
      },
      {
        "id": 53,
        "slug": "hidden-lamp",
        "name": "Hidden Lamp",
        "number": 53,
        "corePattern": "Difference → Hide → Inner Light → Recognition → Shared Glow",
        "description": "Hidden strengths become visible.",
        "whyItWorks": "Encourages authenticity.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Hide → Discover Strength → Share → Inspire Others",
        "bestAdventureArchetypes": [
          "Coming of Age"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Circular Return",
        "bestReplayHooks": [
          "Echo Scene"
        ],
        "bestReadAloudDevices": [
          "Silent Spread"
        ]
      },
      {
        "id": 54,
        "slug": "silent-flower",
        "name": "Silent Flower",
        "number": 54,
        "corePattern": "Hurt → Advice → Quiet Presence → Healing",
        "description": "Healing happens through companionship rather than fixing.",
        "whyItWorks": "Models empathy.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Problem → Advice Fails → Stay Together → Recovery",
        "bestAdventureArchetypes": [
          "Restoration Story",
          "New Friend"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 55,
        "slug": "forest-helper",
        "name": "Forest Helper",
        "number": 55,
        "corePattern": "Complaint → Discovery → Listening → Creative Solution → Appreciation",
        "description": "The ordinary helper becomes extraordinary.",
        "whyItWorks": "Builds gratitude and observation.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Complaint → Explore → Discover Value → Gratitude",
        "bestAdventureArchetypes": [
          "Secret Discovery",
          "Heritage Journey"
        ],
        "bestOpening": "The Tiny Mystery",
        "bestEnding": "The Gentle Surprise",
        "bestReplayHooks": [
          "Foreshadowed Prop"
        ],
        "bestReadAloudDevices": [
          "Point-and-Find"
        ]
      },
      {
        "id": 56,
        "slug": "flying-leaf",
        "name": "Flying Leaf",
        "number": 56,
        "corePattern": "Ordinary Object → Small Adventure → Bigger Adventure → Wisdom",
        "description": "An everyday object becomes the centre of an adventure.",
        "whyItWorks": "Encourages imagination.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Discover Object → Adventure → Discovery → Reflection",
        "bestAdventureArchetypes": [
          "Expedition",
          "Magical Discovery"
        ],
        "bestOpening": "The Invitation",
        "bestEnding": "The New Beginning",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Cumulative Build"
        ]
      },
      {
        "id": 57,
        "slug": "muddy-shield",
        "name": "Muddy Shield",
        "number": 57,
        "corePattern": "Mockery → Challenge → Action → Respect",
        "description": "Character matters more than appearance.",
        "whyItWorks": "Encourages courage and resilience.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Mocked → Opportunity → Brave Action → Acceptance",
        "bestAdventureArchetypes": [
          "Hero's Trial"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Parallel Action"
        ],
        "bestReadAloudDevices": [
          "Rule of Three"
        ]
      },
      {
        "id": 58,
        "slug": "quiet-story",
        "name": "Quiet Story",
        "number": 58,
        "corePattern": "Passion → Doubt → Stillness → Authentic Expression → Success",
        "description": "Quiet confidence replaces the need to impress.",
        "whyItWorks": "Builds authenticity.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Dream → Doubt → Reflection → Try Again → Success",
        "bestAdventureArchetypes": [
          "Performance Story",
          "Transformation Story"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Tiny Visual Joke"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 59,
        "slug": "banyan-wind",
        "name": "Banyan Wind",
        "number": 59,
        "corePattern": "Hurry → Failure → Observe → Better Solution → Success",
        "description": "Slowing down produces better results.",
        "whyItWorks": "Reinforces patience and observation.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Rush → Mistake → Observe → Adapt → Win",
        "bestAdventureArchetypes": [
          "Heritage Journey",
          "Problem Solver"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Mentor Clue"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 60,
        "slug": "floating-seed",
        "name": "Floating Seed",
        "number": 60,
        "corePattern": "Separation → Adaptation → Identity → Bloom",
        "description": "Change becomes part of personal growth.",
        "whyItWorks": "Helps children embrace transitions.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Separation → New Environment → Growth → Belonging",
        "bestAdventureArchetypes": [
          "Transformation Story",
          "Nature's Balance"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 61,
        "slug": "lantern-circle",
        "name": "Lantern Circle",
        "number": 61,
        "corePattern": "Storm → Solo Wonder → Fearful Friends → Unity",
        "description": "One brave child helps everyone discover courage together.",
        "whyItWorks": "Shows courage is contagious.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Storm → Discovery → Friends Join → Safe Together",
        "bestAdventureArchetypes": [
          "Hero's Trial",
          "Community Project"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Parallel Action"
        ],
        "bestReadAloudDevices": [
          "Rule of Three"
        ]
      },
      {
        "id": 62,
        "slug": "yellow-ring",
        "name": "Yellow Ring",
        "number": 62,
        "corePattern": "Discovery → Mockery → Unexpected Use → Acceptance",
        "description": "An unusual idea proves surprisingly valuable.",
        "whyItWorks": "Encourages innovation despite criticism.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Find → Ridiculed → Demonstrate → Community Accepts",
        "bestAdventureArchetypes": [
          "Problem Solver"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 63,
        "slug": "seed-basket",
        "name": "Seed Basket",
        "number": 63,
        "corePattern": "Hoarding → Isolation → Wise Advice → Sharing → Abundance",
        "description": "Sharing creates more happiness than keeping everything.",
        "whyItWorks": "Teaches generosity through experience.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Collect → Alone → Learn → Share → Community Joy",
        "bestAdventureArchetypes": [
          "Helping Hand",
          "Community Project"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 64,
        "slug": "rhythmic-log",
        "name": "Rhythmic Log",
        "number": 64,
        "corePattern": "Talent → Hiding → Silence → Discovery → Celebration",
        "description": "Hidden talents emerge naturally.",
        "whyItWorks": "Encourages authentic self-expression.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Hide Talent → Quiet Moment → Discovery → Celebrate",
        "bestAdventureArchetypes": [
          "Performance Story",
          "Transformation Story"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Tiny Visual Joke"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 65,
        "slug": "ankle-sprain",
        "name": "Ankle Sprain",
        "number": 65,
        "corePattern": "Helper → Injury → Others Help → Gratitude",
        "description": "Even helpers sometimes need help.",
        "whyItWorks": "Teaches interdependence and humility.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Helping → Problem → Friends Return → Appreciation",
        "bestAdventureArchetypes": [
          "New Friend",
          "Community Project"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Friendship Moments"
        ],
        "bestReadAloudDevices": [
          "Character Catchphrase"
        ]
      },
      {
        "id": 66,
        "slug": "village-path",
        "name": "Village Path",
        "number": 66,
        "corePattern": "Journey → Observation → Gathering → Giving → Joy",
        "description": "Everyday kindness transforms a community.",
        "whyItWorks": "Shows small acts matter.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Walk → Notice Needs → Help → Community Celebration",
        "bestAdventureArchetypes": [
          "Community Project",
          "Helping Hand"
        ],
        "bestOpening": "The Invitation",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Background Story"
        ],
        "bestReadAloudDevices": [
          "Call and Response"
        ]
      },
      {
        "id": 67,
        "slug": "garden-song",
        "name": "Garden Song",
        "number": 67,
        "corePattern": "Expert → Mimic → Conflict → Teamwork → Harmony",
        "description": "Individual strengths become stronger together.",
        "whyItWorks": "Encourages collaboration over competition.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Success → Rivalry → Conflict → Cooperation → Performance",
        "bestAdventureArchetypes": [
          "Team Adventure",
          "Friendship Repair"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Running Joke"
        ],
        "bestReadAloudDevices": [
          "Predictable Pattern"
        ]
      },
      {
        "id": 68,
        "slug": "butterfly-walk",
        "name": "Butterfly Walk",
        "number": 68,
        "corePattern": "Mission → Hidden Events → Hero Unaware → Success",
        "description": "The hero unknowingly succeeds while hidden events unfold.",
        "whyItWorks": "Creates dramatic irony and replay value.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Mission → Secret Events → Escalation → Happy Ending",
        "bestAdventureArchetypes": [
          "Unexpected Surprise",
          "Mystery to Solve"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 69,
        "slug": "sound-thief",
        "name": "Sound Thief",
        "number": 69,
        "corePattern": "Gathering → Loss → Listening → Recovery",
        "description": "Careful listening solves the mystery.",
        "whyItWorks": "Reinforces observation skills.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Loss → Search → Listen → Discovery",
        "bestAdventureArchetypes": [
          "Detective Story",
          "Mystery to Solve"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 70,
        "slug": "mirror-reflection",
        "name": "Mirror Reflection",
        "number": 70,
        "corePattern": "Search → False Success → Disappointment → True Discovery",
        "description": "Early answers are misleading; persistence reveals the truth.",
        "whyItWorks": "Builds perseverance and critical thinking.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Search → Wrong Answer → Try Again → Correct Solution",
        "bestAdventureArchetypes": [
          "Mystery to Solve",
          "Secret Discovery"
        ],
        "bestOpening": "The Tiny Mystery",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Object Hunt"
        ],
        "bestReadAloudDevices": [
          "Prediction Pause"
        ]
      },
      {
        "id": 71,
        "slug": "human-bark",
        "name": "Human Bark",
        "number": 71,
        "corePattern": "Problem → Strange Discovery → Normalization → Funny Twist",
        "description": "An absurd situation becomes surprisingly ordinary.",
        "whyItWorks": "Uses surprise to create humour.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Problem → Weird Event → Bigger Surprise → Laugh",
        "bestAdventureArchetypes": [
          "Unexpected Surprise"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 72,
        "slug": "pig-flight",
        "name": "Pig Flight",
        "number": 72,
        "corePattern": "Ordinary Night → Impossible Adventure → Morning Return",
        "description": "Fantasy adventure safely ends back in reality.",
        "whyItWorks": "Encourages imagination while preserving security.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Night → Adventure → Close Call → Wake Up",
        "bestAdventureArchetypes": [
          "Magical Quest"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 73,
        "slug": "button-loop",
        "name": "Button Loop",
        "number": 73,
        "corePattern": "Rule → Small Choice → Consequence → Escalation → Restart",
        "description": "Tiny decisions create repeating consequences.",
        "whyItWorks": "Teaches responsibility and cause-and-effect.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Rule → Break Rule → Consequences → Learn → Restart",
        "bestAdventureArchetypes": [
          "Problem Solver",
          "Choice & Consequence"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 74,
        "slug": "first-mark",
        "name": "First Mark",
        "number": 74,
        "corePattern": "Fear → Tiny Beginning → Experimentation → Confidence → Inspire Others",
        "description": "Starting small leads to mastery.",
        "whyItWorks": "Excellent for growth mindset.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Hesitation → First Try → Practice → Success → Mentor Others",
        "bestAdventureArchetypes": [
          "Transformation Story",
          "Build Together"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 75,
        "slug": "secret-map",
        "name": "Secret Map",
        "number": 75,
        "corePattern": "Ordinary Place → Hidden Discovery → Adventure → Home Revealed",
        "description": "Adventure begins in familiar surroundings.",
        "whyItWorks": "Encourages curiosity about everyday places.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Discover Map → Adventure → Explore → Home Reimagined",
        "bestAdventureArchetypes": [
          "Treasure Hunt",
          "Secret Discovery"
        ],
        "bestOpening": "The Tiny Mystery",
        "bestEnding": "The Gentle Surprise",
        "bestReplayHooks": [
          "Hidden Object Hunt"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 76,
        "slug": "heavy-suitcase",
        "name": "Heavy Suitcase",
        "number": 76,
        "corePattern": "Choice → Burden → Persistence → Wisdom",
        "description": "Carrying unnecessary burdens leads to an important lesson.",
        "whyItWorks": "Helps children recognize emotional and physical burdens.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Choose → Struggle → Reflect → Let Go",
        "bestAdventureArchetypes": [
          "Heritage Journey",
          "Transformation Story"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Mentor Clue"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 77,
        "slug": "steep-slide",
        "name": "Steep Slide",
        "number": 77,
        "corePattern": "Challenge → Fear → Observation → Small Step → Triumph",
        "description": "Courage begins with one manageable action.",
        "whyItWorks": "Breaks overwhelming challenges into small steps.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Fear → Observe → Tiny Step → Success",
        "bestAdventureArchetypes": [
          "Hero's Trial"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Parallel Action"
        ],
        "bestReadAloudDevices": [
          "Rule of Three"
        ]
      },
      {
        "id": 78,
        "slug": "mixed-foods",
        "name": "Mixed Foods",
        "number": 78,
        "corePattern": "Rigidity → Disruption → Reflection → Flexibility",
        "description": "Trying something different leads to growth.",
        "whyItWorks": "Encourages openness to change.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Resistance → New Experience → Reflection → Acceptance",
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 79,
        "slug": "stuck-zipper",
        "name": "Stuck Zipper",
        "number": 79,
        "corePattern": "Goal → Obstacle → Frustration → Calm → Persistence",
        "description": "Calm thinking solves frustrating problems.",
        "whyItWorks": "Models emotional regulation during setbacks.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Goal → Problem → Frustration → Calm → Success",
        "bestAdventureArchetypes": [
          "Problem Solver",
          "Transformation Story"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 80,
        "slug": "missing-piece",
        "name": "Missing Piece",
        "number": 80,
        "corePattern": "Achievement → Imperfection → Sadness → Acceptance",
        "description": "Something incomplete is still valuable.",
        "whyItWorks": "Reinforces self-acceptance over perfection.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Success → Missing Part → Grief → Wholeness",
        "bestAdventureArchetypes": [
          "Coming of Age",
          "Transformation Story"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Circular Return",
        "bestReplayHooks": [
          "Echo Scene"
        ],
        "bestReadAloudDevices": [
          "Silent Spread"
        ]
      },
      {
        "id": 81,
        "slug": "empty-chair",
        "name": "Empty Chair",
        "number": 81,
        "corePattern": "Loss → Remembering → Sharing Memories → New Tradition",
        "description": "Love continues through memories and shared rituals.",
        "whyItWorks": "Helps children process absence and change.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Loss → Remember → Share → New Beginning",
        "bestAdventureArchetypes": [
          "Restoration Story",
          "Promise Keeper"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 82,
        "slug": "borrowed-shoes",
        "name": "Borrowed Shoes",
        "number": 82,
        "corePattern": "Judgment → Walking Another's Path → Understanding → Kindness",
        "description": "Experiencing another's perspective builds empathy.",
        "whyItWorks": "Develops compassion and perspective-taking.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Misjudge → Experience → Understand → Reconcile",
        "bestAdventureArchetypes": [
          "Transformation Story",
          "New Friend"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 83,
        "slug": "broken-kite",
        "name": "Broken Kite",
        "number": 83,
        "corePattern": "Excitement → Failure → Persistence → Better Creation",
        "description": "Failure becomes the beginning of something better.",
        "whyItWorks": "Encourages resilience after disappointment.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Build → Break → Learn → Rebuild → Fly",
        "bestAdventureArchetypes": [
          "Transformation Story",
          "Build Together"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 84,
        "slug": "whisper-tree",
        "name": "Whisper Tree",
        "number": 84,
        "corePattern": "Confusion → Listening → Discovery → Wise Decision",
        "description": "Quiet listening reveals the answer.",
        "whyItWorks": "Reinforces patience and attentive listening.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Problem → Listen → Discover → Act",
        "bestAdventureArchetypes": [
          "Heritage Journey",
          "Secret Discovery"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Mentor Clue"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 85,
        "slug": "hidden-door",
        "name": "Hidden Door",
        "number": 85,
        "corePattern": "Curiosity → Search → Puzzle → Secret Place",
        "description": "Curiosity unlocks a hidden adventure.",
        "whyItWorks": "Rewards exploration and observation.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Wonder → Explore → Solve → Discover",
        "bestAdventureArchetypes": [
          "Mystery to Solve",
          "Treasure Hunt"
        ],
        "bestOpening": "The Tiny Mystery",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Object Hunt"
        ],
        "bestReadAloudDevices": [
          "Prediction Pause"
        ]
      },
      {
        "id": 86,
        "slug": "lost-melody",
        "name": "Lost Melody",
        "number": 86,
        "corePattern": "Loss → Searching → Unexpected Helper → Recovery",
        "description": "Something precious is found through cooperation.",
        "whyItWorks": "Builds teamwork and gratitude.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Lose → Search → Help → Recover",
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "New Friend"
        ],
        "bestOpening": "The Unexpected Interruption",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Sound Words (Onomatopoeia)"
        ]
      },
      {
        "id": 87,
        "slug": "tiny-bridge",
        "name": "Tiny Bridge",
        "number": 87,
        "corePattern": "Division → Cooperation → Connection",
        "description": "Working together bridges differences.",
        "whyItWorks": "Encourages inclusion and collaboration.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Conflict → Build → Connect → Celebrate",
        "bestAdventureArchetypes": [
          "Community Project",
          "Build Together"
        ],
        "bestOpening": "The Invitation",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Background Story"
        ],
        "bestReadAloudDevices": [
          "Call and Response"
        ]
      },
      {
        "id": 88,
        "slug": "brave-echo",
        "name": "Brave Echo",
        "number": 88,
        "corePattern": "Fear → First Attempt → Echo of Success → Confidence",
        "description": "One brave act inspires the next.",
        "whyItWorks": "Demonstrates how confidence grows gradually.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Fear → Try → Small Success → Bigger Success",
        "bestAdventureArchetypes": [
          "Hero's Trial"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Parallel Action"
        ],
        "bestReadAloudDevices": [
          "Rule of Three"
        ]
      },
      {
        "id": 89,
        "slug": "forgotten-gift",
        "name": "Forgotten Gift",
        "number": 89,
        "corePattern": "Giving → Forgotten Value → Rediscovery → Gratitude",
        "description": "The greatest gifts are often the simplest.",
        "whyItWorks": "Reinforces appreciation and generosity.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Give → Forget → Rediscover → Appreciate",
        "bestAdventureArchetypes": [
          "Helping Hand",
          "Festival Adventure"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 90,
        "slug": "gentle-giant",
        "name": "Gentle Giant",
        "number": 90,
        "corePattern": "Strength → Misunderstanding → Kind Action → Respect",
        "description": "True strength is shown through kindness.",
        "whyItWorks": "Redefines courage and leadership.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Misjudged → Opportunity → Kind Choice → Acceptance",
        "bestAdventureArchetypes": [
          "Leadership Challenge",
          "New Friend"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 91,
        "slug": "river-promise",
        "name": "River Promise",
        "number": 91,
        "corePattern": "Promise → Challenge → Temptation → Keeping the Promise",
        "description": "Integrity is tested through action.",
        "whyItWorks": "Develops responsibility and trustworthiness.",
        "bestAge": "6–8",
        "sceneFlowTemplate": "Promise → Obstacle → Choice → Honour Promise",
        "bestAdventureArchetypes": [
          "Responsibility Quest",
          "Great Journey"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 92,
        "slug": "moon-garden",
        "name": "Moon Garden",
        "number": 92,
        "corePattern": "Wish → Patience → Quiet Growth → Bloom",
        "description": "Beautiful things take time.",
        "whyItWorks": "Reinforces delayed gratification and hope.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Wish → Wait → Care → Bloom",
        "bestAdventureArchetypes": [
          "Nature's Balance",
          "Transformation Story"
        ],
        "bestOpening": "The Everyday Wonder",
        "bestEnding": "Nature Responds",
        "bestReplayHooks": [
          "Nature Cycle"
        ],
        "bestReadAloudDevices": [
          "Musical Sentence"
        ]
      },
      {
        "id": 93,
        "slug": "puzzle-trail",
        "name": "Puzzle Trail",
        "number": 93,
        "corePattern": "Clue → Wrong Turn → New Clue → Final Discovery",
        "description": "Every mistake reveals another clue.",
        "whyItWorks": "Encourages persistence and logical thinking.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Clue → Mistake → Learn → Solve",
        "bestAdventureArchetypes": [
          "Detective Story",
          "Mystery to Solve"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 94,
        "slug": "kindness-ripple",
        "name": "Kindness Ripple",
        "number": 94,
        "corePattern": "Small Kind Act → Inspires Another → Chain Reaction",
        "description": "One act of kindness spreads through a community.",
        "whyItWorks": "Shows the ripple effect of positive actions.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Help One → Others Help → Community Changes",
        "bestAdventureArchetypes": [
          "Community Project",
          "Problem Solver"
        ],
        "bestOpening": "The Invitation",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Background Story"
        ],
        "bestReadAloudDevices": [
          "Call and Response"
        ]
      },
      {
        "id": 95,
        "slug": "quiet-hero",
        "name": "Quiet Hero",
        "number": 95,
        "corePattern": "Opportunity → Helping Without Recognition → Quiet Satisfaction",
        "description": "Heroism doesn't require applause.",
        "whyItWorks": "Promotes intrinsic motivation.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Notice Need → Help Quietly → Move On → Community Benefits",
        "bestAdventureArchetypes": [
          "Helping Hand",
          "Rescue Mission"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 96,
        "slug": "festival-lantern",
        "name": "Festival Lantern",
        "number": 96,
        "corePattern": "Preparation → Problems → Community Effort → Celebration",
        "description": "Shared effort makes celebrations meaningful.",
        "whyItWorks": "Reinforces teamwork and gratitude.",
        "bestAge": "5–7",
        "sceneFlowTemplate": "Prepare → Problems → Everyone Helps → Festival",
        "bestAdventureArchetypes": [
          "Festival Adventure",
          "Community Project"
        ],
        "bestOpening": "The Race Against Time",
        "bestEnding": "The Shared Celebration",
        "bestReplayHooks": [
          "Festival Detail"
        ],
        "bestReadAloudDevices": [
          "Rhyme Burst"
        ]
      },
      {
        "id": 97,
        "slug": "golden-feather",
        "name": "Golden Feather",
        "number": 97,
        "corePattern": "Impossible Goal → Mentor → Practice → Achievement",
        "description": "Success comes from steady effort.",
        "whyItWorks": "Encourages perseverance and learning.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Dream → Learn → Practice → Achieve",
        "bestAdventureArchetypes": [
          "Training Journey",
          "Transformation Story"
        ],
        "bestOpening": "The Impossible Task",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Repeated Action"
        ]
      },
      {
        "id": 98,
        "slug": "last-seed",
        "name": "Last Seed",
        "number": 98,
        "corePattern": "Scarcity → Sharing → Unexpected Abundance",
        "description": "Generosity creates hope even during difficult times.",
        "whyItWorks": "Builds trust and abundance thinking.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Scarcity → Share → Hope → Reward",
        "bestAdventureArchetypes": [
          "Helping Hand",
          "Survival Adventure"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Ripple Effect",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Page-Turn Sentence"
        ]
      },
      {
        "id": 99,
        "slug": "new-sunrise",
        "name": "New Sunrise",
        "number": 99,
        "corePattern": "Failure → Reflection → Fresh Start → Success",
        "description": "Every day is another opportunity to begin again.",
        "whyItWorks": "Reinforces resilience and optimism.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Fail → Reflect → Try Again → Succeed",
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Hidden Symbol"
        ],
        "bestReadAloudDevices": [
          "Echo Line"
        ]
      },
      {
        "id": 100,
        "slug": "circle-complete",
        "name": "Circle Complete",
        "number": 100,
        "corePattern": "Journey → Return → New Understanding → Peace",
        "description": "The hero returns home transformed.",
        "whyItWorks": "Provides emotional closure and reinforces growth.",
        "bestAge": "5–8",
        "sceneFlowTemplate": "Adventure → Return → Reflection → Peaceful Ending",
        "bestAdventureArchetypes": [
          "Hero's Trial",
          "Transformation Story"
        ],
        "bestOpening": "The Emotional Spark",
        "bestEnding": "The Quiet Internal Victory",
        "bestReplayHooks": [
          "Parallel Action"
        ],
        "bestReadAloudDevices": [
          "Rule of Three"
        ]
      }
    ],
    "emotionalArcs": [
      {
        "id": 1,
        "slug": "1-radical-self-acceptance",
        "name": "1. Radical Self-Acceptance",
        "journey": [
          "Hopeful Longing",
          "Curious Determination",
          "Accidental Panic",
          "Relieved Wonder",
          "Deep Belonging"
        ],
        "description": "A child believes something is wrong with them but discovers they are loved exactly as they are.",
        "whyItWorks": "Builds deep self-worth and belonging.",
        "whenToUse": "Feeling different, self-doubt, insecurity.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Quiet longing",
          "Trying to change",
          "Vulnerability",
          "Unexpected acceptance",
          "Belonging"
        ],
        "avoid": "Fixing the flaw instead of accepting it.",
        "shortForm": "Insecurity → Belonging"
      },
      {
        "id": 2,
        "slug": "2-circle-of-safety",
        "name": "2. Circle of Safety",
        "journey": [
          "Surprise",
          "Hope",
          "Worry",
          "Comfort",
          "Relief",
          "Security"
        ],
        "description": "Temporary separation becomes an opportunity to build trust and reassurance.",
        "whyItWorks": "Helps children process separation anxiety safely.",
        "whenToUse": "Waiting, school, caregiver separation.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Goodbye",
          "Waiting",
          "Comfort from others",
          "Safe reunion",
          "Emotional security"
        ],
        "avoid": "Turning it into a dangerous rescue.",
        "shortForm": "Worry → Security"
      },
      {
        "id": 3,
        "slug": "3-empathetic-witness",
        "name": "3. Empathetic Witness",
        "journey": [
          "Devastation",
          "Frustration",
          "Isolation",
          "Calm Safety",
          "Healing"
        ],
        "description": "Healing begins when someone quietly listens instead of trying to solve the problem.",
        "whyItWorks": "Validates feelings before solutions.",
        "whenToUse": "Disappointment, grief, losing, failure.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Meaningful loss",
          "Unhelpful advice",
          "Withdrawal",
          "Quiet presence",
          "Emotional release"
        ],
        "avoid": "Mentor fixing everything immediately.",
        "shortForm": "Devastation → Healing"
      },
      {
        "id": 4,
        "slug": "4-sensory-discovery",
        "name": "4. Sensory Discovery",
        "journey": [
          "Wonder",
          "Freedom",
          "Curiosity",
          "Gentle Satisfaction",
          "Warm Nostalgia"
        ],
        "description": "Exploring nature creates emotional growth through experience.",
        "whyItWorks": "Encourages mindfulness and observation.",
        "whenToUse": "Nature stories, quiet adventures, curiosity.",
        "bestAge": "5–7",
        "buildingBlocks": [
          "Morning discovery",
          "Solo exploration",
          "Sensory play",
          "Reflection",
          "Warm memory"
        ],
        "avoid": "Villains or high-stakes conflict.",
        "shortForm": "Wonder → Nostalgia"
      },
      {
        "id": 5,
        "slug": "5-triumphant-teamwork",
        "name": "5. Triumphant Teamwork",
        "journey": [
          "Belonging",
          "Shock",
          "Leadership",
          "Hope",
          "Shared Triumph"
        ],
        "description": "Friends combine different strengths to solve a problem together.",
        "whyItWorks": "Reinforces cooperation and inclusion.",
        "whenToUse": "Friendship, community, rescue missions.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Peaceful beginning",
          "Threat",
          "Gathering helpers",
          "Everyone contributes",
          "Shared celebration"
        ],
        "avoid": "One hero doing everything.",
        "shortForm": "Shock → Triumph"
      },
      {
        "id": 6,
        "slug": "6-mindful-de-escalation",
        "name": "6. Mindful De-escalation",
        "journey": [
          "Safe",
          "Curious",
          "Relaxed",
          "Peaceful Rest"
        ],
        "description": "A child gradually slows down until they feel calm and secure.",
        "whyItWorks": "Excellent for bedtime and emotional regulation.",
        "whenToUse": "Bedtime, overstimulation, anxiety.",
        "bestAge": "5–6",
        "buildingBlocks": [
          "Safe place",
          "Familiar objects",
          "Gentle repetition",
          "Slowing rhythm",
          "Stillness"
        ],
        "avoid": "Introducing excitement near the end.",
        "shortForm": "Restlessness → Peace"
      },
      {
        "id": 7,
        "slug": "7-rhythmic-growth",
        "name": "7. Rhythmic Growth",
        "journey": [
          "Wonder",
          "Excitement",
          "Overwhelm",
          "Relief",
          "Patience",
          "Joy"
        ],
        "description": "Growth happens through effort, mistakes, rest and transformation.",
        "whyItWorks": "Teaches patience and healthy development.",
        "whenToUse": "Growth, learning, perseverance.",
        "bestAge": "5–6",
        "buildingBlocks": [
          "Small beginning",
          "Gradual progress",
          "Too much",
          "Rest",
          "Transformation"
        ],
        "avoid": "Skipping the recovery phase.",
        "shortForm": "Wonder → Joy"
      },
      {
        "id": 8,
        "slug": "8-underdog-s-wit",
        "name": "8. Underdog's Wit",
        "journey": [
          "Cautious Curiosity",
          "Calm Confidence",
          "Shock",
          "Creative Thinking",
          "Triumph"
        ],
        "description": "A small hero succeeds through intelligence instead of strength.",
        "whyItWorks": "Builds confidence and problem-solving.",
        "whenToUse": "Courage, mystery, adventure.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Small hero",
          "Bigger challenge",
          "Twist",
          "Clever solution",
          "Quiet victory"
        ],
        "avoid": "Winning through luck or magic.",
        "shortForm": "Self-Doubt → Triumph"
      },
      {
        "id": 9,
        "slug": "9-empowered-boundary",
        "name": "9. Empowered Boundary",
        "journey": [
          "Responsibility",
          "Temptation",
          "Pressure",
          "Confidence",
          "Pride"
        ],
        "description": "Holding a healthy boundary becomes a joyful achievement.",
        "whyItWorks": "Builds impulse control and self-confidence.",
        "whenToUse": "Rules, self-control, everyday life.",
        "bestAge": "5–7",
        "buildingBlocks": [
          "Important task",
          "Funny persuasion",
          "Firm decision",
          "Success",
          "New focus"
        ],
        "avoid": "Punishing mistakes harshly.",
        "shortForm": "Temptation → Pride"
      },
      {
        "id": 10,
        "slug": "10-generous-heart",
        "name": "10. Generous Heart",
        "journey": [
          "Pride",
          "Loneliness",
          "Hesitation",
          "Giving",
          "Joy"
        ],
        "description": "Sharing transforms loneliness into connection.",
        "whyItWorks": "Demonstrates that generosity multiplies happiness.",
        "whenToUse": "Sharing, kindness, friendship.",
        "bestAge": "5–7",
        "buildingBlocks": [
          "Special possession",
          "Refusal",
          "Loneliness",
          "First gift",
          "Ripple of joy"
        ],
        "avoid": "Forcing generosity.",
        "shortForm": "Hesitation → Joy"
      },
      {
        "id": 11,
        "slug": "11-emotional-harbor",
        "name": "11. Emotional Harbor",
        "journey": [
          "Defiance",
          "Emotional Release",
          "Loneliness",
          "Reflection",
          "Love"
        ],
        "description": "Big emotions are expressed safely before returning to connection.",
        "whyItWorks": "Validates anger while preserving emotional safety.",
        "whenToUse": "Tantrums, frustration, feeling misunderstood.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Emotional outburst",
          "Imaginative escape",
          "Peak freedom",
          "Homesickness",
          "Loving return"
        ],
        "avoid": "Punishing emotional expression.",
        "shortForm": "Defiance → Love"
      },
      {
        "id": 12,
        "slug": "12-validated-grump",
        "name": "12. Validated Grump",
        "journey": [
          "Resentment",
          "Frustration",
          "Overwhelm",
          "Despair",
          "Acceptance"
        ],
        "description": "A terrible day becomes bearable when feelings are acknowledged.",
        "whyItWorks": "Builds resilience through validation instead of forced positivity.",
        "whenToUse": "Bad days, setbacks, frustration.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Series of setbacks",
          "Emotional overload",
          "Quiet listening",
          "Gentle reassurance",
          "Acceptance"
        ],
        "avoid": "Lecturing about staying positive.",
        "shortForm": "Resentment → Acceptance"
      },
      {
        "id": 13,
        "slug": "13-creative-empowerment",
        "name": "13. Creative Empowerment",
        "journey": [
          "Uncertainty",
          "Curiosity",
          "Experimentation",
          "Discovery",
          "Pride"
        ],
        "description": "A child solves a problem through imagination and creativity.",
        "whyItWorks": "Builds creative confidence instead of dependence.",
        "whenToUse": "Inventing, making, problem-solving.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Open problem",
          "Playful ideas",
          "Failed attempts",
          "Creative breakthrough",
          "Pride"
        ],
        "avoid": "Adults providing the solution.",
        "shortForm": "Uncertainty → Pride"
      },
      {
        "id": 14,
        "slug": "14-identity-reframing",
        "name": "14. Identity Reframing",
        "journey": [
          "Self-Doubt",
          "Comparison",
          "Discovery",
          "Acceptance",
          "Confidence"
        ],
        "description": "A child learns their difference is a unique strength.",
        "whyItWorks": "Builds identity and self-esteem.",
        "whenToUse": "Feeling different, jealousy, comparison.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Feeling left out",
          "Comparison",
          "Discovery",
          "Acceptance",
          "Confidence"
        ],
        "avoid": "Changing the child to fit in.",
        "shortForm": "Self-Doubt → Confidence"
      },
      {
        "id": 15,
        "slug": "15-resourceful-improviser",
        "name": "15. Resourceful Improviser",
        "journey": [
          "Loss",
          "Frustration",
          "Curiosity",
          "New Possibility",
          "Success"
        ],
        "description": "Losing something leads to discovering an even better solution.",
        "whyItWorks": "Encourages flexibility and resilience.",
        "whenToUse": "Mistakes, setbacks, accidents.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Loss",
          "Search",
          "Experiment",
          "Unexpected solution",
          "Celebration"
        ],
        "avoid": "Solving everything with luck.",
        "shortForm": "Loss → Success"
      },
      {
        "id": 16,
        "slug": "16-surprise-guest",
        "name": "16. Surprise Guest",
        "journey": [
          "Routine",
          "Surprise",
          "Confusion",
          "Adaptation",
          "Joy"
        ],
        "description": "An unexpected visitor or event enriches everyone's lives.",
        "whyItWorks": "Builds adaptability and openness.",
        "whenToUse": "New friends, visitors, change.",
        "bestAge": "5–7",
        "buildingBlocks": [
          "Calm routine",
          "Unexpected arrival",
          "Adjustment",
          "Shared fun",
          "Warm goodbye"
        ],
        "avoid": "Making the visitor a villain.",
        "shortForm": "Confusion → Joy"
      },
      {
        "id": 17,
        "slug": "17-infinite-measure",
        "name": "17. Infinite Measure",
        "journey": [
          "Love",
          "Wonder",
          "Bigger Comparison",
          "Awe",
          "Security"
        ],
        "description": "A child discovers love cannot be measured because it keeps growing.",
        "whyItWorks": "Makes abstract love tangible.",
        "whenToUse": "Parent-child stories, reassurance.",
        "bestAge": "5–7",
        "buildingBlocks": [
          "Loving question",
          "Bigger examples",
          "Nature comparisons",
          "Comfort",
          "Belonging"
        ],
        "avoid": "Treating love like a competition.",
        "shortForm": "Wonder → Security"
      },
      {
        "id": 18,
        "slug": "18-runaway-logic",
        "name": "18. Runaway Logic",
        "journey": [
          "Small Choice",
          "Bigger Consequence",
          "Escalation",
          "Funny Chaos",
          "Resolution"
        ],
        "description": "One simple action creates an increasingly funny chain reaction.",
        "whyItWorks": "Teaches cause and effect through humour.",
        "whenToUse": "Comedy, problem-solving.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Tiny event",
          "Domino chain",
          "Escalation",
          "Creative solution",
          "Calm ending"
        ],
        "avoid": "Random, unrelated events.",
        "shortForm": "Small Choice → Resolution"
      },
      {
        "id": 19,
        "slug": "19-comic-pivot",
        "name": "19. Comic Pivot",
        "journey": [
          "Obsession",
          "Frustration",
          "Bigger Obsession",
          "Sudden Shift",
          "Laughter"
        ],
        "description": "The hero's focus suddenly changes, ending the conflict.",
        "whyItWorks": "Creates satisfying comic relief.",
        "whenToUse": "Funny stories, stubborn characters.",
        "bestAge": "5–7",
        "buildingBlocks": [
          "One desire",
          "Escalation",
          "Distraction",
          "Instant change",
          "Laughter"
        ],
        "avoid": "Mean-spirited humour.",
        "shortForm": "Frustration → Laughter"
      },
      {
        "id": 20,
        "slug": "20-curious-insecurity",
        "name": "20. Curious Insecurity",
        "journey": [
          "Curiosity",
          "Self-Doubt",
          "Exploration",
          "Understanding",
          "Belonging"
        ],
        "description": "Questions about identity lead to deeper confidence.",
        "whyItWorks": "Helps children understand themselves.",
        "whenToUse": "Identity, belonging, curiosity.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Question",
          "Search",
          "Reflection",
          "Discovery",
          "Acceptance"
        ],
        "avoid": "Giving quick answers without exploration.",
        "shortForm": "Self-Doubt → Belonging"
      },
      {
        "id": 21,
        "slug": "21-courageous-breath",
        "name": "21. Courageous Breath",
        "journey": [
          "Nervousness",
          "Pause",
          "Calm Breathing",
          "First Step",
          "Confidence"
        ],
        "description": "A child calms themselves before facing a challenge.",
        "whyItWorks": "Teaches emotional regulation in stressful moments.",
        "whenToUse": "New experiences, stage fear, school.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Fear",
          "Breathing",
          "Small action",
          "Success",
          "Confidence"
        ],
        "avoid": "Removing all fear instantly.",
        "shortForm": "Nervousness → Confidence"
      },
      {
        "id": 22,
        "slug": "22-appreciated-helper",
        "name": "22. Appreciated Helper",
        "journey": [
          "Happy Helping",
          "Feeling Invisible",
          "Recognition",
          "Gratitude",
          "Joy"
        ],
        "description": "A helpful child realizes their kindness is seen and valued.",
        "whyItWorks": "Encourages kindness without resentment.",
        "whenToUse": "Gratitude, family, friendship.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Helping",
          "Being unnoticed",
          "Recognition",
          "Gratitude",
          "Celebration"
        ],
        "avoid": "Rewarding only with prizes.",
        "shortForm": "Feeling Invisible → Joy"
      },
      {
        "id": 23,
        "slug": "23-melodramatic-threat",
        "name": "23. Melodramatic Threat",
        "journey": [
          "Frustration",
          "Big Declaration",
          "Reflection",
          "Comfort",
          "Calm"
        ],
        "description": "Dramatic reactions soften through understanding and reassurance.",
        "whyItWorks": "Lets children laugh at exaggerated emotions.",
        "whenToUse": "Bad days, disappointment, comedy.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Big complaint",
          "Funny exaggeration",
          "Gentle listening",
          "Calm ending"
        ],
        "avoid": "Mocking the child's emotions.",
        "shortForm": "Frustration → Calm"
      },
      {
        "id": 24,
        "slug": "24-silent-awe",
        "name": "24. Silent Awe",
        "journey": [
          "Curiosity",
          "Wonder",
          "Stillness",
          "Gratitude",
          "Peace"
        ],
        "description": "A child quietly experiences something beautiful without needing words.",
        "whyItWorks": "Develops mindfulness and appreciation.",
        "whenToUse": "Nature, festivals, spiritual moments.",
        "bestAge": "5–8",
        "buildingBlocks": [
          "Quiet observation",
          "Beautiful moment",
          "Silence",
          "Reflection",
          "Peace"
        ],
        "avoid": "Explaining the experience too much.",
        "shortForm": "Curiosity → Peace"
      },
      {
        "id": 26,
        "slug": "self-identity",
        "name": "Self & Identity",
        "journey": [
          "Radical Self-Acceptance, Identity Reframing, Creative Empowerment, Underdog's Wit"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 27,
        "slug": "emotional-regulation",
        "name": "Emotional Regulation",
        "journey": [
          "Emotional Harbor, Mindful De-escalation, Validated Grump, Courageous Breath"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 28,
        "slug": "relationships",
        "name": "Relationships",
        "journey": [
          "Circle of Safety, Empathetic Witness, Triumphant Teamwork, Generous Heart, Appreciated Helper, Infinite Measure"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 29,
        "slug": "growth-resilience",
        "name": "Growth & Resilience",
        "journey": [
          "Rhythmic Growth, Resourceful Improviser, Empowered Boundary"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 30,
        "slug": "wonder-exploration",
        "name": "Wonder & Exploration",
        "journey": [
          "Sensory Discovery, Silent Awe, Curious Insecurity"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 31,
        "slug": "adventure-humor",
        "name": "Adventure & Humor",
        "journey": [
          "Runaway Logic, Comic Pivot, Surprise Guest"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 33,
        "slug": "if-the-story-is-about",
        "name": "If the Story is About...",
        "journey": [
          "Recommended Emotional Arc(s)"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 34,
        "slug": "feeling-different",
        "name": "Feeling Different",
        "journey": [
          "Radical Self-Acceptance, Identity Reframing"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 35,
        "slug": "fear",
        "name": "Fear",
        "journey": [
          "Circle of Safety, Courageous Breath"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 36,
        "slug": "anger",
        "name": "Anger",
        "journey": [
          "Emotional Harbor"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 37,
        "slug": "sadness",
        "name": "Sadness",
        "journey": [
          "Empathetic Witness, Validated Grump"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 38,
        "slug": "friendship",
        "name": "Friendship",
        "journey": [
          "Triumphant Teamwork, Generous Heart"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 39,
        "slug": "sharing",
        "name": "Sharing",
        "journey": [
          "Generous Heart"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 40,
        "slug": "confidence",
        "name": "Confidence",
        "journey": [
          "Underdog's Wit, Creative Empowerment"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 41,
        "slug": "mistakes",
        "name": "Mistakes",
        "journey": [
          "Resourceful Improviser, Rhythmic Growth"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 42,
        "slug": "waiting",
        "name": "Waiting",
        "journey": [
          "Circle of Safety, Rhythmic Growth"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 43,
        "slug": "new-experiences",
        "name": "New Experiences",
        "journey": [
          "Courageous Breath, Circle of Safety"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 44,
        "slug": "patience",
        "name": "Patience",
        "journey": [
          "Rhythmic Growth"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 45,
        "slug": "nature",
        "name": "Nature",
        "journey": [
          "Sensory Discovery, Silent Awe"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 46,
        "slug": "gratitude",
        "name": "Gratitude",
        "journey": [
          "Appreciated Helper, Infinite Measure"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 47,
        "slug": "rules-boundaries",
        "name": "Rules & Boundaries",
        "journey": [
          "Empowered Boundary"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 48,
        "slug": "curiosity",
        "name": "Curiosity",
        "journey": [
          "Sensory Discovery, Curious Insecurity"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 49,
        "slug": "change",
        "name": "Change",
        "journey": [
          "Surprise Guest, Resourceful Improviser"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 50,
        "slug": "teamwork",
        "name": "Teamwork",
        "journey": [
          "Triumphant Teamwork"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 51,
        "slug": "bedtime",
        "name": "Bedtime",
        "journey": [
          "Mindful De-escalation"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 52,
        "slug": "problem-solving",
        "name": "Problem Solving",
        "journey": [
          "Underdog's Wit, Creative Empowerment"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 53,
        "slug": "belonging",
        "name": "Belonging",
        "journey": [
          "Radical Self-Acceptance, Circle of Safety"
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 55,
        "slug": "",
        "name": "☐",
        "journey": [
          "Emotion starts small and grows naturally."
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 56,
        "slug": "",
        "name": "☐",
        "journey": [
          "Child experiences the feeling before the solution appears."
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 57,
        "slug": "",
        "name": "☐",
        "journey": [
          "Only one major emotional turning point."
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 58,
        "slug": "",
        "name": "☐",
        "journey": [
          "Recovery follows the emotional climax."
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 59,
        "slug": "",
        "name": "☐",
        "journey": [
          "Child solves or participates in solving the emotional problem."
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 60,
        "slug": "",
        "name": "☐",
        "journey": [
          "Emotional lesson is shown through actions."
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 61,
        "slug": "",
        "name": "☐",
        "journey": [
          "Ending feels emotionally safe."
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 62,
        "slug": "",
        "name": "☐",
        "journey": [
          "Emotional arc matches the child's developmental age."
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      },
      {
        "id": 63,
        "slug": "",
        "name": "☐",
        "journey": [
          "The ending leaves hope, not fear."
        ],
        "description": null,
        "whyItWorks": null,
        "whenToUse": null,
        "bestAge": null,
        "buildingBlocks": [],
        "avoid": null,
        "shortForm": null
      }
    ],
    "openings": [
      {
        "id": 1,
        "slug": "the-vulnerable-wanderer",
        "name": "The Vulnerable Wanderer",
        "description": "Introduce the hero facing a relatable emotional challenge before the adventure begins.",
        "howItWorks": "Starts with emotion before action so children immediately identify with the hero.",
        "whyItWorks": "Empathy is created before curiosity, making readers care about what happens next.",
        "bestStoryStructures": [
          "Transformation Story",
          "Journey Story",
          "Character Growth Story"
        ],
        "bestAdventureArchetypes": [
          "Great Journey",
          "Hero's Trial",
          "Coming of Age"
        ],
        "bestEmotionalArcs": [
          "Fear → Courage",
          "Self-Doubt → Confidence",
          "Loneliness → Belonging"
        ],
        "bestStoryTypes": [
          "Emotional Growth",
          "Friendship",
          "Journey"
        ],
        "bestAge": "5–8",
        "openingFormula": "Child struggling → Small glimpse of world → Something unexpected appears",
        "openingEmotion": "Empathy",
        "illustrationGoal": "Show the hero small within a rich environment, with body language revealing the emotional state.",
        "pageTurnHook": "\"Then something unexpected caught their attention...\"",
        "writingTips": "Keep the challenge small and relatable. Show emotion through actions instead of explaining it."
      },
      {
        "id": 2,
        "slug": "the-tiny-mystery",
        "name": "The Tiny Mystery",
        "description": "Begin with a small unexplained event that sparks curiosity.",
        "howItWorks": "Gives the child an immediate question to solve.",
        "whyItWorks": "Curiosity keeps pages turning naturally.",
        "bestStoryStructures": [
          "Mystery Story",
          "Discovery Story"
        ],
        "bestAdventureArchetypes": [
          "Mystery to Solve",
          "Secret Discovery",
          "Treasure Hunt"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Discovery",
          "Wonder → Understanding"
        ],
        "bestStoryTypes": [
          "Mystery",
          "Discovery",
          "Adventure"
        ],
        "bestAge": "5–10",
        "openingFormula": "Normal world → Strange detail appears → Hero decides to investigate",
        "openingEmotion": "Curiosity",
        "illustrationGoal": "Highlight one unusual object or event while keeping the rest of the scene ordinary.",
        "pageTurnHook": "\"But why was it there?\"",
        "writingTips": "Mystery should be small enough for children to understand but intriguing enough to continue reading."
      },
      {
        "id": 3,
        "slug": "the-unexpected-interruption",
        "name": "The Unexpected Interruption",
        "description": "The hero's ordinary day is suddenly interrupted by an unexpected event.",
        "howItWorks": "Quickly shifts from normal life into adventure.",
        "whyItWorks": "Creates momentum immediately without long setup.",
        "bestStoryStructures": [
          "Adventure Story",
          "Rescue Story",
          "Quest Story"
        ],
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Great Journey",
          "Race Against Time"
        ],
        "bestEmotionalArcs": [
          "Surprise → Courage",
          "Calm → Determination"
        ],
        "bestStoryTypes": [
          "Adventure",
          "Rescue",
          "Quest"
        ],
        "bestAge": "5–10",
        "openingFormula": "Normal day → Unexpected interruption → Hero reacts",
        "openingEmotion": "Surprise",
        "illustrationGoal": "Contrast peaceful routine with sudden movement or change.",
        "pageTurnHook": "\"Before anyone could understand what happened...\"",
        "writingTips": "Keep the interruption simple and easy to understand. The hero should react immediately."
      },
      {
        "id": 4,
        "slug": "the-everyday-wonder",
        "name": "The Everyday Wonder",
        "description": "Begin in an ordinary place where something beautiful or unusual is quietly discovered.",
        "howItWorks": "Invites children to notice wonder in familiar surroundings.",
        "whyItWorks": "Builds curiosity through observation instead of action.",
        "bestStoryStructures": [
          "Discovery Story",
          "Nature Story"
        ],
        "bestAdventureArchetypes": [
          "Hidden World",
          "Nature's Balance",
          "Secret Discovery"
        ],
        "bestEmotionalArcs": [
          "Wonder → Gratitude",
          "Curiosity → Discovery"
        ],
        "bestStoryTypes": [
          "Nature",
          "Discovery"
        ],
        "bestAge": "5–8",
        "openingFormula": "Ordinary place → Tiny beautiful detail → Hero notices something different",
        "openingEmotion": "Wonder",
        "illustrationGoal": "Rich environmental illustration with one subtle magical or surprising detail.",
        "pageTurnHook": "\"But today, something looked different...\"",
        "writingTips": "Let the illustration do much of the storytelling. Keep text gentle and minimal."
      },
      {
        "id": 5,
        "slug": "the-emotional-spark",
        "name": "The Emotional Spark",
        "description": "Open with a strong feeling or emotional problem the hero is experiencing.",
        "howItWorks": "Emotion becomes the story's starting point rather than the plot.",
        "whyItWorks": "Children recognise the feeling immediately.",
        "bestStoryStructures": [
          "Transformation Story",
          "Character Story"
        ],
        "bestAdventureArchetypes": [
          "Coming of Age",
          "Hero's Trial"
        ],
        "bestEmotionalArcs": [
          "Any emotional arc"
        ],
        "bestStoryTypes": [
          "Emotional Growth",
          "Friendship"
        ],
        "bestAge": "5–10",
        "openingFormula": "Strong emotion → Small situation showing it → Something changes",
        "openingEmotion": "Empathy",
        "illustrationGoal": "Close-up of facial expression and body language.",
        "pageTurnHook": "\"Then something happened that changed everything...\"",
        "writingTips": "Show emotion through behaviour rather than naming it."
      },
      {
        "id": 6,
        "slug": "the-invitation",
        "name": "The Invitation",
        "description": "Someone invites the hero to help, join or explore something new.",
        "howItWorks": "Gives the story a clear purpose from the beginning.",
        "whyItWorks": "Children quickly understand the mission.",
        "bestStoryStructures": [
          "Journey Story",
          "Quest Story"
        ],
        "bestAdventureArchetypes": [
          "Great Journey",
          "Community Project",
          "Expedition"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Confidence",
          "Fear → Courage"
        ],
        "bestStoryTypes": [
          "Journey",
          "Quest",
          "Community"
        ],
        "bestAge": "6–10",
        "openingFormula": "Invitation arrives → Hero hesitates → Accepts the invitation",
        "openingEmotion": "Curiosity",
        "illustrationGoal": "Show two characters interacting with excitement or curiosity.",
        "pageTurnHook": "\"Should I go?\"",
        "writingTips": "The invitation should feel exciting but believable."
      },
      {
        "id": 7,
        "slug": "the-missing-something",
        "name": "The Missing Something",
        "description": "An important object, person or idea has disappeared.",
        "howItWorks": "Instantly creates a clear goal.",
        "whyItWorks": "Children immediately understand what needs to be solved.",
        "bestStoryStructures": [
          "Mystery Story",
          "Rescue Story"
        ],
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Mystery to Solve",
          "Treasure Hunt"
        ],
        "bestEmotionalArcs": [
          "Concern → Hope",
          "Curiosity → Discovery"
        ],
        "bestStoryTypes": [
          "Mystery",
          "Rescue"
        ],
        "bestAge": "5–10",
        "openingFormula": "Something important is missing → Hero discovers it → Search begins",
        "openingEmotion": "Concern",
        "illustrationGoal": "Empty space where something should be.",
        "pageTurnHook": "\"Where did it go?\"",
        "writingTips": "Make the missing item emotionally meaningful."
      },
      {
        "id": 8,
        "slug": "the-promise",
        "name": "The Promise",
        "description": "The hero makes—or receives—a meaningful promise.",
        "howItWorks": "Establishes responsibility and emotional stakes.",
        "whyItWorks": "Readers want to know whether the promise will be kept.",
        "bestStoryStructures": [
          "Relationship Story",
          "Community Story"
        ],
        "bestAdventureArchetypes": [
          "Promise Keeper",
          "Community Project"
        ],
        "bestEmotionalArcs": [
          "Trust → Responsibility",
          "Fear → Integrity"
        ],
        "bestStoryTypes": [
          "Relationships",
          "Family",
          "Community"
        ],
        "bestAge": "6–10",
        "openingFormula": "Promise made → Responsibility accepted → Challenge begins",
        "openingEmotion": "Trust",
        "illustrationGoal": "Warm interaction between characters that shows the relationship.",
        "pageTurnHook": "\"Could the promise really be kept?\"",
        "writingTips": "Keep the promise simple and emotionally important."
      },
      {
        "id": 9,
        "slug": "the-race-against-time",
        "name": "The Race Against Time",
        "description": "The hero must complete something before a deadline.",
        "howItWorks": "Introduces urgency from the very first page.",
        "whyItWorks": "Creates immediate tension and momentum.",
        "bestStoryStructures": [
          "Adventure Story",
          "Rescue Story",
          "Mission Story"
        ],
        "bestAdventureArchetypes": [
          "Race Against Time",
          "Rescue Mission",
          "Festival Adventure"
        ],
        "bestEmotionalArcs": [
          "Anxiety → Determination",
          "Worry → Confidence"
        ],
        "bestStoryTypes": [
          "Adventure",
          "Rescue",
          "Festival"
        ],
        "bestAge": "6–10",
        "openingFormula": "Deadline introduced → Stakes explained → Hero decides to act",
        "openingEmotion": "Urgency",
        "illustrationGoal": "Show a visible countdown (setting sun, approaching storm, festival preparations, etc.).",
        "pageTurnHook": "\"Would they make it in time?\"",
        "writingTips": "Make the deadline easy for children to understand and emotionally meaningful."
      },
      {
        "id": 10,
        "slug": "the-impossible-task",
        "name": "The Impossible Task",
        "description": "The hero is asked to do something that feels far beyond their ability.",
        "howItWorks": "Establishes the transformation arc immediately.",
        "whyItWorks": "Children instantly root for an underdog.",
        "bestStoryStructures": [
          "Hero's Trial Story",
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Hero's Trial",
          "Training Journey",
          "Coming of Age"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Confidence",
          "Fear → Courage"
        ],
        "bestStoryTypes": [
          "Growth",
          "Hero Journey"
        ],
        "bestAge": "6–10",
        "openingFormula": "Impossible challenge → Hero doubts themselves → First small attempt",
        "openingEmotion": "Self-Doubt",
        "illustrationGoal": "Show the huge challenge compared to the small hero.",
        "pageTurnHook": "\"How could anyone do that?\"",
        "writingTips": "Make the task appear impossible—but secretly achievable through growth."
      },
      {
        "id": 12,
        "slug": "",
        "name": "#",
        "description": "Opening Type",
        "howItWorks": "Primary Strength",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      },
      {
        "id": 13,
        "slug": "1",
        "name": "1",
        "description": "The Vulnerable Wanderer",
        "howItWorks": "Emotional empathy",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      },
      {
        "id": 14,
        "slug": "2",
        "name": "2",
        "description": "The Tiny Mystery",
        "howItWorks": "Curiosity",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      },
      {
        "id": 15,
        "slug": "3",
        "name": "3",
        "description": "The Unexpected Interruption",
        "howItWorks": "Fast action",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      },
      {
        "id": 16,
        "slug": "4",
        "name": "4",
        "description": "The Everyday Wonder",
        "howItWorks": "Discovery",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      },
      {
        "id": 17,
        "slug": "5",
        "name": "5",
        "description": "The Emotional Spark",
        "howItWorks": "Emotional connection",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      },
      {
        "id": 18,
        "slug": "6",
        "name": "6",
        "description": "The Invitation",
        "howItWorks": "Purpose",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      },
      {
        "id": 19,
        "slug": "7",
        "name": "7",
        "description": "The Missing Something",
        "howItWorks": "Clear goal",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      },
      {
        "id": 20,
        "slug": "8",
        "name": "8",
        "description": "The Promise",
        "howItWorks": "Responsibility",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      },
      {
        "id": 21,
        "slug": "9",
        "name": "9",
        "description": "The Race Against Time",
        "howItWorks": "Urgency",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      },
      {
        "id": 22,
        "slug": "10",
        "name": "10",
        "description": "The Impossible Task",
        "howItWorks": "Transformation",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "openingFormula": null,
        "openingEmotion": null,
        "illustrationGoal": null,
        "pageTurnHook": null,
        "writingTips": null
      }
    ],
    "endings": [
      {
        "id": 1,
        "slug": "the-circular-return",
        "name": "The Circular Return",
        "description": "The story ends where it began, but the hero has changed.",
        "howItWorks": "Mirrors the opening to highlight growth.",
        "whyItWorks": "Children enjoy recognizing familiar scenes with new meaning.",
        "bestStoryStructures": [
          "Circular Story",
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Coming of Age",
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Confidence",
          "Fear → Courage",
          "Loneliness → Belonging"
        ],
        "bestStoryTypes": [
          "Emotional Growth",
          "Journey"
        ],
        "bestAge": "5–10",
        "endingFormula": "Return to opening → Show changed behaviour → Quiet emotional close",
        "emotionalResolution": "Growth and peace",
        "finalLineStyle": "Reflective",
        "replayTrigger": "Opening scene echoes with new meaning",
        "illustrationGoal": "Same location as the opening, but brighter and more alive",
        "writingTips": "Let actions reveal the change instead of explaining it."
      },
      {
        "id": 2,
        "slug": "the-quiet-internal-victory",
        "name": "The Quiet Internal Victory",
        "description": "The biggest success is emotional rather than external.",
        "howItWorks": "The mission matters, but the hero's inner change matters more.",
        "whyItWorks": "Leaves a lasting emotional impact.",
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Hero's Trial",
          "Coming of Age"
        ],
        "bestEmotionalArcs": [
          "Shame → Confidence",
          "Fear → Courage"
        ],
        "bestStoryTypes": [
          "Emotional Growth"
        ],
        "bestAge": "5–10",
        "endingFormula": "Mission completed → Hero thinks differently → Peaceful ending",
        "emotionalResolution": "Confidence, acceptance",
        "finalLineStyle": "Gentle and reflective",
        "replayTrigger": "Small visual callback to the emotional journey",
        "illustrationGoal": "Calm close-up of the hero showing confidence",
        "writingTips": "Show the emotional change through behaviour and expression."
      },
      {
        "id": 3,
        "slug": "the-ripple-effect",
        "name": "The Ripple Effect",
        "description": "The hero's change positively influences others.",
        "howItWorks": "Shows that personal growth spreads outward.",
        "whyItWorks": "Reinforces kindness and community naturally.",
        "bestStoryStructures": [
          "Community Story",
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Community Project",
          "Helping Hand"
        ],
        "bestEmotionalArcs": [
          "Self-Focus → Compassion",
          "Fear → Belonging"
        ],
        "bestStoryTypes": [
          "Community",
          "Friendship"
        ],
        "bestAge": "5–10",
        "endingFormula": "Hero changes → Others respond → Community benefits",
        "emotionalResolution": "Belonging",
        "finalLineStyle": "Warm and hopeful",
        "replayTrigger": "Background characters now behave differently",
        "illustrationGoal": "Show the whole community flourishing",
        "writingTips": "Keep the focus on influence, not praise."
      },
      {
        "id": 4,
        "slug": "the-gentle-surprise",
        "name": "The Gentle Surprise",
        "description": "A small unexpected reveal adds delight without changing the story.",
        "howItWorks": "Rewards attentive readers.",
        "whyItWorks": "Creates an \"Aha!\" moment and encourages rereading.",
        "bestStoryStructures": [
          "Mystery Story",
          "Discovery Story"
        ],
        "bestAdventureArchetypes": [
          "Secret Discovery",
          "Treasure Hunt"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Wonder"
        ],
        "bestStoryTypes": [
          "Mystery",
          "Discovery"
        ],
        "bestAge": "5–10",
        "endingFormula": "Problem solved → Small hidden reveal → Smile",
        "emotionalResolution": "Delight",
        "finalLineStyle": "Quiet surprise",
        "replayTrigger": "Hidden clue that makes earlier pages more meaningful",
        "illustrationGoal": "Focus on one surprising visual detail",
        "writingTips": "Keep the surprise small and believable."
      },
      {
        "id": 5,
        "slug": "the-new-beginning",
        "name": "The New Beginning",
        "description": "The adventure ends by opening a hopeful next chapter.",
        "howItWorks": "Gives closure while suggesting future possibilities.",
        "whyItWorks": "Makes the story world feel alive beyond the final page.",
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestAdventureArchetypes": [
          "Great Journey",
          "Expedition"
        ],
        "bestEmotionalArcs": [
          "Hope → Confidence"
        ],
        "bestStoryTypes": [
          "Adventure",
          "Journey"
        ],
        "bestAge": "5–10",
        "endingFormula": "Mission complete → New opportunity appears → Hopeful close",
        "emotionalResolution": "Optimism",
        "finalLineStyle": "Hopeful",
        "replayTrigger": "Small hint of the next adventure",
        "illustrationGoal": "Hero looking toward a new horizon",
        "writingTips": "End one story completely before hinting at another."
      },
      {
        "id": 6,
        "slug": "the-shared-celebration",
        "name": "The Shared Celebration",
        "description": "Friends, family or the community celebrate together.",
        "howItWorks": "Rewards the journey with shared joy.",
        "whyItWorks": "Creates a satisfying emotional release.",
        "bestStoryStructures": [
          "Celebration Story",
          "Community Story"
        ],
        "bestAdventureArchetypes": [
          "Festival Adventure",
          "Community Project"
        ],
        "bestEmotionalArcs": [
          "Gratitude → Joy",
          "Loneliness → Belonging"
        ],
        "bestStoryTypes": [
          "Celebration",
          "Community"
        ],
        "bestAge": "5–10",
        "endingFormula": "Mission complete → Everyone gathers → Celebration",
        "emotionalResolution": "Joy and belonging",
        "finalLineStyle": "Joyful",
        "replayTrigger": "Background details reward rereading",
        "illustrationGoal": "Rich festive spread full of life",
        "writingTips": "Keep the celebration connected to the emotional journey."
      },
      {
        "id": 7,
        "slug": "the-passing-forward",
        "name": "The Passing Forward",
        "description": "The hero shares the wisdom, kindness or courage they discovered with someone else.",
        "howItWorks": "The transformation is completed by helping another character.",
        "whyItWorks": "Shows that true growth naturally spreads to others.",
        "bestStoryStructures": [
          "Transformation Story",
          "Community Story"
        ],
        "bestAdventureArchetypes": [
          "Helping Hand",
          "Community Project",
          "Coming of Age"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Confidence",
          "Fear → Courage",
          "Self-Focus → Compassion"
        ],
        "bestStoryTypes": [
          "Emotional Growth",
          "Friendship",
          "Community"
        ],
        "bestAge": "5–10",
        "endingFormula": "Hero transforms → Helps another → Wisdom continues",
        "emotionalResolution": "Generosity and responsibility",
        "finalLineStyle": "Warm and inspiring",
        "replayTrigger": "A younger or struggling character now begins their own journey.",
        "illustrationGoal": "Hero helping another in a scene similar to the one where they once needed help.",
        "writingTips": "Show the wisdom through actions, not speeches."
      },
      {
        "id": 8,
        "slug": "nature-responds",
        "name": "Nature Responds",
        "description": "Nature quietly reflects the hero's emotional transformation.",
        "howItWorks": "The environment changes to mirror the emotional resolution.",
        "whyItWorks": "Creates a memorable visual ending without explaining the lesson.",
        "bestStoryStructures": [
          "Nature Story",
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Nature's Balance",
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Fear → Peace",
          "Sadness → Hope",
          "Loneliness → Belonging"
        ],
        "bestStoryTypes": [
          "Nature",
          "Emotional Growth"
        ],
        "bestAge": "5–10",
        "endingFormula": "Hero changes → Nature responds → Quiet final image",
        "emotionalResolution": "Peace and harmony",
        "finalLineStyle": "Gentle and poetic",
        "replayTrigger": "Readers notice nature behaving differently on a reread.",
        "illustrationGoal": "Blooming flowers, returning birds, sunlight breaking through clouds, calm river.",
        "writingTips": "Keep the change subtle and symbolic."
      },
      {
        "id": 9,
        "slug": "the-callback",
        "name": "The Callback",
        "description": "The ending echoes a moment, line or image from the opening, but with new emotional meaning.",
        "howItWorks": "Creates symmetry and highlights the hero's transformation.",
        "whyItWorks": "Children enjoy recognising familiar moments with a deeper understanding.",
        "bestStoryStructures": [
          "Circular Story",
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Coming of Age",
          "Hero's Trial"
        ],
        "bestEmotionalArcs": [
          "Fear → Courage",
          "Self-Doubt → Confidence",
          "Loneliness → Belonging"
        ],
        "bestStoryTypes": [
          "Emotional Growth",
          "Journey"
        ],
        "bestAge": "5–10",
        "endingFormula": "Repeat opening moment → Hero responds differently → Quiet close",
        "emotionalResolution": "Growth and satisfaction",
        "finalLineStyle": "Reflective",
        "replayTrigger": "Children notice how the opening and ending mirror each other.",
        "illustrationGoal": "Nearly identical composition to the opening illustration, but with changed body language and surroundings.",
        "writingTips": "Use visual storytelling more than dialogue."
      },
      {
        "id": 10,
        "slug": "the-open-door",
        "name": "The Open Door",
        "description": "The main story feels complete while gently hinting that more adventures are possible.",
        "howItWorks": "Provides closure while expanding the world.",
        "whyItWorks": "Encourages imagination and series potential.",
        "bestStoryStructures": [
          "Journey Story",
          "Discovery Story"
        ],
        "bestAdventureArchetypes": [
          "Great Journey",
          "Hidden World",
          "Expedition"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Wonder",
          "Hope → Confidence"
        ],
        "bestStoryTypes": [
          "Adventure",
          "Discovery",
          "Series"
        ],
        "bestAge": "5–10",
        "endingFormula": "Mission complete → Small mystery remains → Hopeful final image",
        "emotionalResolution": "Wonder and anticipation",
        "finalLineStyle": "Hopeful",
        "replayTrigger": "A tiny unexplored path, unopened letter, distant light, new map or new friend appears.",
        "illustrationGoal": "Hero looking toward a new horizon or discovering one last tiny clue.",
        "writingTips": "The current emotional journey must feel complete before teasing the future."
      },
      {
        "id": 12,
        "slug": "",
        "name": "#",
        "description": "Ending Type",
        "howItWorks": "Primary Strength",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      },
      {
        "id": 13,
        "slug": "1",
        "name": "1",
        "description": "The Circular Return",
        "howItWorks": "Transformation",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      },
      {
        "id": 14,
        "slug": "2",
        "name": "2",
        "description": "The Quiet Internal Victory",
        "howItWorks": "Emotional Growth",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      },
      {
        "id": 15,
        "slug": "3",
        "name": "3",
        "description": "The Ripple Effect",
        "howItWorks": "Community Impact",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      },
      {
        "id": 16,
        "slug": "4",
        "name": "4",
        "description": "The Gentle Surprise",
        "howItWorks": "Replay Value",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      },
      {
        "id": 17,
        "slug": "5",
        "name": "5",
        "description": "The New Beginning",
        "howItWorks": "Hope",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      },
      {
        "id": 18,
        "slug": "6",
        "name": "6",
        "description": "The Shared Celebration",
        "howItWorks": "Joy & Belonging",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      },
      {
        "id": 19,
        "slug": "7",
        "name": "7",
        "description": "The Passing Forward",
        "howItWorks": "Wisdom Through Action",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      },
      {
        "id": 20,
        "slug": "8",
        "name": "8",
        "description": "Nature Responds",
        "howItWorks": "Symbolic Resolution",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      },
      {
        "id": 21,
        "slug": "9",
        "name": "9",
        "description": "The Callback",
        "howItWorks": "Emotional Symmetry",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      },
      {
        "id": 22,
        "slug": "10",
        "name": "10",
        "description": "The Open Door",
        "howItWorks": "Wonder & Future Adventure",
        "whyItWorks": null,
        "bestStoryStructures": [],
        "bestAdventureArchetypes": [],
        "bestEmotionalArcs": [],
        "bestStoryTypes": [],
        "bestAge": null,
        "endingFormula": null,
        "emotionalResolution": null,
        "finalLineStyle": null,
        "replayTrigger": null,
        "illustrationGoal": null,
        "writingTips": null
      }
    ],
    "replayHooks": [
      {
        "id": 1,
        "slug": "hidden-object-hunt",
        "name": "Hidden Object Hunt",
        "category": "Visual",
        "description": "Hide one object on every page.",
        "howItWorks": "Children search each reread.",
        "whyItWorks": "Encourages observation.",
        "complexity": "★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Discovery",
          "Mystery"
        ],
        "bestAdventureArchetypes": [
          "Mystery to Solve",
          "Treasure Hunt"
        ],
        "bestEmotionalArcs": [
          "Curiosity → Wonder"
        ],
        "bestAge": "4–8",
        "notes": "Vary difficulty."
      },
      {
        "id": 2,
        "slug": "hidden-symbol",
        "name": "Hidden Symbol",
        "category": "Visual",
        "description": "Hide the Ganesha wisdom element.",
        "howItWorks": "Children find the symbol.",
        "whyItWorks": "Reinforces the lesson visually.",
        "complexity": "★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Transformation"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "False Belief → True Belief"
        ],
        "bestAge": "5–10",
        "notes": "One per spread."
      },
      {
        "id": 3,
        "slug": "background-story",
        "name": "Background Story",
        "category": "Visual",
        "description": "Side characters have their own mini-story.",
        "howItWorks": "Children notice new details.",
        "whyItWorks": "Rewards rereading.",
        "complexity": "★★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Community"
        ],
        "bestAdventureArchetypes": [
          "Community Project"
        ],
        "bestEmotionalArcs": [
          "Belonging"
        ],
        "bestAge": "5–9",
        "notes": "Keep subtle."
      },
      {
        "id": 4,
        "slug": "tiny-visual-joke",
        "name": "Tiny Visual Joke",
        "category": "Visual",
        "description": "Small humorous details.",
        "howItWorks": "Easy to miss first time.",
        "whyItWorks": "Adds delight.",
        "complexity": "★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Any"
        ],
        "bestAdventureArchetypes": [
          "Performance Story"
        ],
        "bestEmotionalArcs": [
          "Joy"
        ],
        "bestAge": "5–8",
        "notes": "Never distract."
      },
      {
        "id": 5,
        "slug": "secret-path",
        "name": "Secret Path",
        "category": "Visual",
        "description": "A hidden trail connects pages.",
        "howItWorks": "Children follow clues.",
        "whyItWorks": "Makes rereads interactive.",
        "complexity": "★★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Journey"
        ],
        "bestAdventureArchetypes": [
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–9",
        "notes": "Great for maps."
      },
      {
        "id": 6,
        "slug": "colour-clue",
        "name": "Colour Clue",
        "category": "Visual",
        "description": "Colour hints foreshadow events.",
        "howItWorks": "Seen only later.",
        "whyItWorks": "Clever payoff.",
        "complexity": "★★",
        "bestStoryStage": "Beginning–Middle",
        "bestStoryStructures": [
          "Mystery"
        ],
        "bestAdventureArchetypes": [
          "Ancient Secret"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "6–10",
        "notes": "Use sparingly."
      },
      {
        "id": 7,
        "slug": "foreshadowed-prop",
        "name": "Foreshadowed Prop",
        "category": "Visual",
        "description": "A future prop appears early.",
        "howItWorks": "Reward on reread.",
        "whyItWorks": "Creates \"I saw that!\" moments.",
        "complexity": "★★",
        "bestStoryStage": "Opening",
        "bestStoryStructures": [
          "Quest"
        ],
        "bestAdventureArchetypes": [
          "Secret Discovery"
        ],
        "bestEmotionalArcs": [
          "Surprise"
        ],
        "bestAge": "5–10",
        "notes": "Natural placement."
      },
      {
        "id": 8,
        "slug": "symbol-evolution",
        "name": "Symbol Evolution",
        "category": "Visual",
        "description": "Wisdom element changes across pages.",
        "howItWorks": "Tracks inner growth.",
        "whyItWorks": "Connects story and symbol.",
        "complexity": "★★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Transformation"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "Growth"
        ],
        "bestAge": "5–10",
        "notes": "Excellent for Prana Kids."
      },
      {
        "id": 9,
        "slug": "circular-callback",
        "name": "Circular Callback",
        "category": "Story",
        "description": "End with a visual or line from the opening.",
        "howItWorks": "Creates satisfying closure.",
        "whyItWorks": "Children notice the change.",
        "complexity": "★",
        "bestStoryStage": "Ending",
        "bestStoryStructures": [
          "Circular Story"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "False Belief → True Belief"
        ],
        "bestAge": "5–10",
        "notes": "Best emotional payoff."
      },
      {
        "id": 10,
        "slug": "repeated-phrase",
        "name": "Repeated Phrase",
        "category": "Language",
        "description": "Repeat a memorable phrase with new meaning.",
        "howItWorks": "Phrase evolves through the story.",
        "whyItWorks": "Fun to anticipate.",
        "complexity": "★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestAdventureArchetypes": [
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Confidence"
        ],
        "bestAge": "4–8",
        "notes": "Use 2–4 repetitions."
      },
      {
        "id": 11,
        "slug": "running-joke",
        "name": "Running Joke",
        "category": "Humor",
        "description": "Repeat a joke with variations.",
        "howItWorks": "Builds expectation.",
        "whyItWorks": "Predictable humor delights children.",
        "complexity": "★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Adventure"
        ],
        "bestAdventureArchetypes": [
          "Team Adventure"
        ],
        "bestEmotionalArcs": [
          "Joy"
        ],
        "bestAge": "5–8",
        "notes": "Don't overuse."
      },
      {
        "id": 12,
        "slug": "returning-character",
        "name": "Returning Character",
        "category": "Character",
        "description": "A background character appears throughout.",
        "howItWorks": "Children look for them each time.",
        "whyItWorks": "Creates familiarity.",
        "complexity": "★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Community Story"
        ],
        "bestAdventureArchetypes": [
          "Community Project"
        ],
        "bestEmotionalArcs": [
          "Belonging"
        ],
        "bestAge": "5–8",
        "notes": "Subtle appearances."
      },
      {
        "id": 13,
        "slug": "echo-scene",
        "name": "Echo Scene",
        "category": "Story",
        "description": "A later scene mirrors an earlier one.",
        "howItWorks": "Highlights growth.",
        "whyItWorks": "Reinforces transformation.",
        "complexity": "★★",
        "bestStoryStage": "Ending",
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Coming of Age"
        ],
        "bestEmotionalArcs": [
          "Growth"
        ],
        "bestAge": "6–10",
        "notes": "Same setting, different outcome."
      },
      {
        "id": 14,
        "slug": "parallel-action",
        "name": "Parallel Action",
        "category": "Story",
        "description": "Two similar events occur differently.",
        "howItWorks": "Encourages comparison.",
        "whyItWorks": "Shows learning without explaining.",
        "complexity": "★★",
        "bestStoryStage": "Middle–Ending",
        "bestStoryStructures": [
          "Growth Story"
        ],
        "bestAdventureArchetypes": [
          "Hero's Trial"
        ],
        "bestEmotionalArcs": [
          "Confidence"
        ],
        "bestAge": "6–10",
        "notes": "Great for emotional arcs."
      },
      {
        "id": 15,
        "slug": "mirror-ending",
        "name": "Mirror Ending",
        "category": "Story",
        "description": "Final illustration mirrors the first.",
        "howItWorks": "Visual transformation.",
        "whyItWorks": "Powerful emotional closure.",
        "complexity": "★★",
        "bestStoryStage": "Ending",
        "bestStoryStructures": [
          "Circular Story"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "Peace"
        ],
        "bestAge": "5–10",
        "notes": "Excellent for picture books."
      },
      {
        "id": 16,
        "slug": "side-character-story",
        "name": "Side Character Story",
        "category": "Character",
        "description": "Supporting characters have their own mini-journey.",
        "howItWorks": "New discoveries each reread.",
        "whyItWorks": "Expands the world.",
        "complexity": "★★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Community Story"
        ],
        "bestAdventureArchetypes": [
          "Community Project"
        ],
        "bestEmotionalArcs": [
          "Belonging"
        ],
        "bestAge": "5–9",
        "notes": "Keep secondary."
      },
      {
        "id": 17,
        "slug": "mentor-clue",
        "name": "Mentor Clue",
        "category": "Character",
        "description": "Mentor quietly hints at the solution early.",
        "howItWorks": "Makes sense on reread.",
        "whyItWorks": "Rewards observation.",
        "complexity": "★★",
        "bestStoryStage": "Beginning",
        "bestStoryStructures": [
          "Mentor Story"
        ],
        "bestAdventureArchetypes": [
          "Heritage Journey"
        ],
        "bestEmotionalArcs": [
          "Understanding"
        ],
        "bestAge": "6–10",
        "notes": "Never too obvious."
      },
      {
        "id": 18,
        "slug": "friendship-moments",
        "name": "Friendship Moments",
        "category": "Character",
        "description": "Tiny acts of kindness in the background.",
        "howItWorks": "Emotional details emerge later.",
        "whyItWorks": "Builds warmth.",
        "complexity": "★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Friendship Story"
        ],
        "bestAdventureArchetypes": [
          "New Friend"
        ],
        "bestEmotionalArcs": [
          "Belonging"
        ],
        "bestAge": "4–8",
        "notes": "Small visual actions."
      },
      {
        "id": 19,
        "slug": "character-hobby",
        "name": "Character Hobby",
        "category": "Character",
        "description": "Recurring hobbies appear across stories.",
        "howItWorks": "Builds familiarity.",
        "whyItWorks": "Makes characters memorable.",
        "complexity": "★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Any"
        ],
        "bestAdventureArchetypes": [
          "Any"
        ],
        "bestEmotionalArcs": [
          "Any"
        ],
        "bestAge": "5–10",
        "notes": "Helps build the Prana Kids universe."
      },
      {
        "id": 20,
        "slug": "hidden-emotion",
        "name": "Hidden Emotion",
        "category": "Character",
        "description": "Expressions reveal feelings before dialogue does.",
        "howItWorks": "Encourages emotional literacy.",
        "whyItWorks": "Children notice more over time.",
        "complexity": "★★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Emotional Story"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "All"
        ],
        "bestAge": "5–10",
        "notes": "Excellent illustration cue."
      },
      {
        "id": 21,
        "slug": "map-connection",
        "name": "Map Connection",
        "category": "World",
        "description": "Hidden map links important places.",
        "howItWorks": "Children trace future adventures.",
        "whyItWorks": "Builds a connected universe.",
        "complexity": "★★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestAdventureArchetypes": [
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–10",
        "notes": "Great for series."
      },
      {
        "id": 22,
        "slug": "nature-cycle",
        "name": "Nature Cycle",
        "category": "World",
        "description": "Nature changes with the story.",
        "howItWorks": "Seasons mirror emotions.",
        "whyItWorks": "Makes worlds feel alive.",
        "complexity": "★★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Nature Story"
        ],
        "bestAdventureArchetypes": [
          "Nature's Balance"
        ],
        "bestEmotionalArcs": [
          "Growth"
        ],
        "bestAge": "5–10",
        "notes": "Subtle changes."
      },
      {
        "id": 23,
        "slug": "world-rule",
        "name": "World Rule",
        "category": "World",
        "description": "A recurring rule governs the world.",
        "howItWorks": "Children remember the world's logic.",
        "whyItWorks": "Adds consistency.",
        "complexity": "★",
        "bestStoryStage": "Beginning",
        "bestStoryStructures": [
          "Any"
        ],
        "bestAdventureArchetypes": [
          "Hidden World"
        ],
        "bestEmotionalArcs": [
          "Understanding"
        ],
        "bestAge": "5–10",
        "notes": "Keep rules simple."
      },
      {
        "id": 24,
        "slug": "festival-detail",
        "name": "Festival Detail",
        "category": "World",
        "description": "Festival decorations reveal new details each read.",
        "howItWorks": "Encourages observation.",
        "whyItWorks": "Rich visual rewards.",
        "complexity": "★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Celebration Story"
        ],
        "bestAdventureArchetypes": [
          "Festival Adventure"
        ],
        "bestEmotionalArcs": [
          "Joy"
        ],
        "bestAge": "5–8",
        "notes": "Ideal for Ganesh Chaturthi."
      },
      {
        "id": 25,
        "slug": "prop-history",
        "name": "Prop History",
        "category": "World",
        "description": "Objects quietly reappear across stories.",
        "howItWorks": "Creates continuity.",
        "whyItWorks": "Rewards loyal readers.",
        "complexity": "★★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Series"
        ],
        "bestAdventureArchetypes": [
          "Heritage Journey"
        ],
        "bestEmotionalArcs": [
          "Belonging"
        ],
        "bestAge": "6–10",
        "notes": "Excellent series device."
      },
      {
        "id": 26,
        "slug": "wisdom-element-discovery",
        "name": "Wisdom Element Discovery",
        "category": "Wisdom",
        "description": "Children notice the Ganesha wisdom element appearing in different forms.",
        "howItWorks": "Symbol reinforces the story visually.",
        "whyItWorks": "Strengthens recall.",
        "complexity": "★",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "False Belief → True Belief"
        ],
        "bestAge": "5–10",
        "notes": "Signature Prana Kids hook."
      },
      {
        "id": 27,
        "slug": "chant-connection",
        "name": "Chant Connection",
        "category": "Wisdom",
        "description": "A chant echoes the emotional journey.",
        "howItWorks": "Children connect sound with meaning.",
        "whyItWorks": "Encourages participation.",
        "complexity": "★★",
        "bestStoryStage": "Middle–Ending",
        "bestStoryStructures": [
          "Wisdom Story"
        ],
        "bestAdventureArchetypes": [
          "Heritage Journey"
        ],
        "bestEmotionalArcs": [
          "Calm → Confidence"
        ],
        "bestAge": "5–10",
        "notes": "Never presented as magic."
      },
      {
        "id": 28,
        "slug": "choice-reflection",
        "name": "Choice Reflection",
        "category": "Wisdom",
        "description": "Earlier choices gain new meaning after the ending.",
        "howItWorks": "Children rethink the story.",
        "whyItWorks": "Deepens understanding.",
        "complexity": "★★",
        "bestStoryStage": "Ending",
        "bestStoryStructures": [
          "Choice Story"
        ],
        "bestAdventureArchetypes": [
          "Choice & Consequence"
        ],
        "bestEmotionalArcs": [
          "Wisdom"
        ],
        "bestAge": "6–10",
        "notes": "Excellent discussion starter."
      },
      {
        "id": 29,
        "slug": "true-belief-callback",
        "name": "True Belief Callback",
        "category": "Wisdom",
        "description": "Final scene reflects the new True Belief without stating it.",
        "howItWorks": "Shows growth through action.",
        "whyItWorks": "Reinforces transformation.",
        "complexity": "★★",
        "bestStoryStage": "Ending",
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Coming of Age"
        ],
        "bestEmotionalArcs": [
          "False Belief → True Belief"
        ],
        "bestAge": "5–10",
        "notes": "Avoid explaining the lesson."
      },
      {
        "id": 30,
        "slug": "parent-discussion-prompt",
        "name": "Parent Discussion Prompt",
        "category": "Reflection",
        "description": "Ending naturally invites conversation.",
        "howItWorks": "Extends learning beyond the story.",
        "whyItWorks": "Builds replay through discussion.",
        "complexity": "★",
        "bestStoryStage": "Ending",
        "bestStoryStructures": [
          "Any"
        ],
        "bestAdventureArchetypes": [
          "Any"
        ],
        "bestEmotionalArcs": [
          "Any"
        ],
        "bestAge": "5–10",
        "notes": "Optional, outside the story text."
      }
    ],
    "readAloudDevices": [
      {
        "id": 1,
        "slug": "repeated-phrase",
        "name": "Repeated Phrase",
        "category": "Rhythm",
        "description": "Repeat a memorable line with growing meaning.",
        "howItWorks": "Builds anticipation.",
        "whyItWorks": "Children join in.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestAdventureArchetypes": [
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Confidence"
        ],
        "bestAge": "4–8",
        "example": "\"Not yet... not yet...\"",
        "notes": "Use 2–4 times."
      },
      {
        "id": 2,
        "slug": "rule-of-three",
        "name": "Rule of Three",
        "category": "Rhythm",
        "description": "Repeat an action three times with variation.",
        "howItWorks": "Creates satisfying rhythm.",
        "whyItWorks": "Easy to remember.",
        "bestStoryStage": "Middle",
        "bestStoryStructures": [
          "Adventure Story"
        ],
        "bestAdventureArchetypes": [
          "Hero's Trial"
        ],
        "bestEmotionalArcs": [
          "Determination"
        ],
        "bestAge": "5–8",
        "example": "Three attempts",
        "notes": "Third time succeeds."
      },
      {
        "id": 3,
        "slug": "predictable-pattern",
        "name": "Predictable Pattern",
        "category": "Rhythm",
        "description": "Repeat a sentence structure.",
        "howItWorks": "Children predict what comes next.",
        "whyItWorks": "Encourages participation.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Community Story"
        ],
        "bestAdventureArchetypes": [
          "Team Adventure"
        ],
        "bestEmotionalArcs": [
          "Joy"
        ],
        "bestAge": "4–7",
        "example": "—",
        "notes": "Simple wording."
      },
      {
        "id": 4,
        "slug": "echo-line",
        "name": "Echo Line",
        "category": "Rhythm",
        "description": "A line returns later with new meaning.",
        "howItWorks": "Reinforces growth.",
        "whyItWorks": "Emotional payoff.",
        "bestStoryStage": "Ending",
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "Growth"
        ],
        "bestAge": "5–10",
        "example": "—",
        "notes": "Best near ending."
      },
      {
        "id": 5,
        "slug": "call-and-response",
        "name": "Call and Response",
        "category": "Participation",
        "description": "Narrator asks; children answer.",
        "howItWorks": "Makes reading interactive.",
        "whyItWorks": "High engagement.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Friendship Story"
        ],
        "bestAdventureArchetypes": [
          "Community Project"
        ],
        "bestEmotionalArcs": [
          "Joy"
        ],
        "bestAge": "4–7",
        "example": "\"Who's there?\"",
        "notes": "Don't overuse."
      },
      {
        "id": 6,
        "slug": "cumulative-build",
        "name": "Cumulative Build",
        "category": "Rhythm",
        "description": "Each page adds one new element.",
        "howItWorks": "Builds excitement.",
        "whyItWorks": "Great memory aid.",
        "bestStoryStage": "Middle",
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestAdventureArchetypes": [
          "Expedition"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "4–8",
        "example": "—",
        "notes": "Perfect for quests."
      },
      {
        "id": 7,
        "slug": "repeated-action",
        "name": "Repeated Action",
        "category": "Rhythm",
        "description": "Hero repeats an action while improving.",
        "howItWorks": "Shows growth naturally.",
        "whyItWorks": "Reinforces learning.",
        "bestStoryStage": "Middle",
        "bestStoryStructures": [
          "Training Story"
        ],
        "bestAdventureArchetypes": [
          "Training Journey"
        ],
        "bestEmotionalArcs": [
          "Confidence"
        ],
        "bestAge": "5–9",
        "example": "—",
        "notes": "Each attempt improves."
      },
      {
        "id": 8,
        "slug": "gentle-refrain",
        "name": "Gentle Refrain",
        "category": "Rhythm",
        "description": "Soft recurring sentence throughout story.",
        "howItWorks": "Creates emotional anchor.",
        "whyItWorks": "Comforting.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Emotional Story"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "Belonging"
        ],
        "bestAge": "4–8",
        "example": "—",
        "notes": "Ideal bedtime stories."
      },
      {
        "id": 9,
        "slug": "sound-words-onomatopoeia",
        "name": "Sound Words (Onomatopoeia)",
        "category": "Sound",
        "description": "Use sounds like Splash! Crunch! Whoosh!",
        "howItWorks": "Makes scenes vivid.",
        "whyItWorks": "Children love repeating sounds.",
        "bestStoryStage": "Action Scenes",
        "bestStoryStructures": [
          "Adventure Story"
        ],
        "bestAdventureArchetypes": [
          "Rescue Mission",
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Excitement"
        ],
        "bestAge": "4–8",
        "example": "\"Splash!\"",
        "notes": "Don't overload."
      },
      {
        "id": 10,
        "slug": "alliteration",
        "name": "Alliteration",
        "category": "Language",
        "description": "Repeat the same starting sound.",
        "howItWorks": "Creates musical rhythm.",
        "whyItWorks": "Easy to remember.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Any"
        ],
        "bestAdventureArchetypes": [
          "Any"
        ],
        "bestEmotionalArcs": [
          "Joy"
        ],
        "bestAge": "4–8",
        "example": "\"Busy buzzing bees\"",
        "notes": "Keep natural."
      },
      {
        "id": 11,
        "slug": "rhyme-burst",
        "name": "Rhyme Burst",
        "category": "Language",
        "description": "Short rhyming phrase.",
        "howItWorks": "Adds playful rhythm.",
        "whyItWorks": "Encourages participation.",
        "bestStoryStage": "Key Moments",
        "bestStoryStructures": [
          "Celebration Story"
        ],
        "bestAdventureArchetypes": [
          "Festival Adventure"
        ],
        "bestEmotionalArcs": [
          "Joy"
        ],
        "bestAge": "4–7",
        "example": "—",
        "notes": "Use sparingly."
      },
      {
        "id": 12,
        "slug": "musical-sentence",
        "name": "Musical Sentence",
        "category": "Rhythm",
        "description": "Long flowing sentence with natural cadence.",
        "howItWorks": "Pleasant to read aloud.",
        "whyItWorks": "Keeps listener engaged.",
        "bestStoryStage": "Descriptive Scenes",
        "bestStoryStructures": [
          "Nature Story"
        ],
        "bestAdventureArchetypes": [
          "Nature's Balance"
        ],
        "bestEmotionalArcs": [
          "Wonder"
        ],
        "bestAge": "5–9",
        "example": "—",
        "notes": "Avoid becoming too long."
      },
      {
        "id": 13,
        "slug": "whisper-moment",
        "name": "Whisper Moment",
        "category": "Voice",
        "description": "Sentence naturally invites a whisper.",
        "howItWorks": "Creates suspense.",
        "whyItWorks": "Children lean in.",
        "bestStoryStage": "Mystery",
        "bestStoryStructures": [
          "Mystery Story"
        ],
        "bestAdventureArchetypes": [
          "Ancient Secret"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–9",
        "example": "\"Very quietly...\"",
        "notes": "Great before page turn."
      },
      {
        "id": 14,
        "slug": "loud-moment",
        "name": "Loud Moment",
        "category": "Voice",
        "description": "Big exciting sentence.",
        "howItWorks": "Releases energy.",
        "whyItWorks": "Fun for group reading.",
        "bestStoryStage": "Climax",
        "bestStoryStructures": [
          "Hero Story"
        ],
        "bestAdventureArchetypes": [
          "Hero's Trial"
        ],
        "bestEmotionalArcs": [
          "Excitement"
        ],
        "bestAge": "4–8",
        "example": "\"Run!\"",
        "notes": "Use only once or twice."
      },
      {
        "id": 15,
        "slug": "character-catchphrase",
        "name": "Character Catchphrase",
        "category": "Character",
        "description": "A character repeats a favourite line.",
        "howItWorks": "Builds familiarity.",
        "whyItWorks": "Children anticipate it.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Character Story"
        ],
        "bestAdventureArchetypes": [
          "New Friend"
        ],
        "bestEmotionalArcs": [
          "Belonging"
        ],
        "bestAge": "4–8",
        "example": "—",
        "notes": "Signature character trait."
      },
      {
        "id": 16,
        "slug": "prediction-pause",
        "name": "Prediction Pause",
        "category": "Participation",
        "description": "Pause before revealing what happens.",
        "howItWorks": "Invites guessing.",
        "whyItWorks": "Keeps children engaged.",
        "bestStoryStage": "Before Page Turn",
        "bestStoryStructures": [
          "Mystery Story"
        ],
        "bestAdventureArchetypes": [
          "Mystery to Solve"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–9",
        "example": "\"What do you think?\"",
        "notes": "Short pause only."
      },
      {
        "id": 17,
        "slug": "count-together",
        "name": "Count Together",
        "category": "Participation",
        "description": "Count objects or actions together.",
        "howItWorks": "Interactive reading.",
        "whyItWorks": "Builds participation.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestAdventureArchetypes": [
          "Expedition"
        ],
        "bestEmotionalArcs": [
          "Excitement"
        ],
        "bestAge": "4–7",
        "example": "Count steps",
        "notes": "Great for younger readers."
      },
      {
        "id": 18,
        "slug": "point-and-find",
        "name": "Point-and-Find",
        "category": "Participation",
        "description": "Ask readers to spot something.",
        "howItWorks": "Encourages observation.",
        "whyItWorks": "Supports replay.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Discovery Story"
        ],
        "bestAdventureArchetypes": [
          "Secret Discovery"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "4–8",
        "example": "Find the Mouse",
        "notes": "Excellent with illustrations."
      },
      {
        "id": 19,
        "slug": "character-voice",
        "name": "Character Voice",
        "category": "Participation",
        "description": "Give each character a distinct voice.",
        "howItWorks": "Makes dialogue memorable.",
        "whyItWorks": "Builds personality.",
        "bestStoryStage": "Dialogue",
        "bestStoryStructures": [
          "Friendship Story"
        ],
        "bestAdventureArchetypes": [
          "Team Adventure"
        ],
        "bestEmotionalArcs": [
          "Joy"
        ],
        "bestAge": "4–9",
        "example": "—",
        "notes": "Keep voices consistent."
      },
      {
        "id": 20,
        "slug": "audience-question",
        "name": "Audience Question",
        "category": "Participation",
        "description": "Ask a direct question.",
        "howItWorks": "Invites thinking.",
        "whyItWorks": "Builds emotional connection.",
        "bestStoryStage": "Reflection",
        "bestStoryStructures": [
          "Emotional Story"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "Reflection"
        ],
        "bestAge": "5–10",
        "example": "\"What would you do?\"",
        "notes": "Natural, not preachy."
      },
      {
        "id": 21,
        "slug": "slow-pause",
        "name": "Slow Pause",
        "category": "Emotion",
        "description": "Short pause after an emotional sentence.",
        "howItWorks": "Gives emotions space.",
        "whyItWorks": "Helps children process feelings.",
        "bestStoryStage": "Emotional Low",
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "Sadness → Hope"
        ],
        "bestAge": "5–10",
        "example": "—",
        "notes": "Don't overuse."
      },
      {
        "id": 22,
        "slug": "silent-spread",
        "name": "Silent Spread",
        "category": "Emotion",
        "description": "Let the illustration tell the story.",
        "howItWorks": "Creates reflection.",
        "whyItWorks": "Powerful emotional impact.",
        "bestStoryStage": "Turning Point",
        "bestStoryStructures": [
          "Emotional Story"
        ],
        "bestAdventureArchetypes": [
          "Coming of Age"
        ],
        "bestEmotionalArcs": [
          "Reflection"
        ],
        "bestAge": "5–10",
        "example": "—",
        "notes": "Very few words."
      },
      {
        "id": 23,
        "slug": "emotional-contrast",
        "name": "Emotional Contrast",
        "category": "Emotion",
        "description": "Shift quickly between two emotions.",
        "howItWorks": "Makes feelings memorable.",
        "whyItWorks": "Mirrors real life.",
        "bestStoryStage": "Climax",
        "bestStoryStructures": [
          "Hero Story"
        ],
        "bestAdventureArchetypes": [
          "Hero's Trial"
        ],
        "bestEmotionalArcs": [
          "Fear → Courage"
        ],
        "bestAge": "5–10",
        "example": "—",
        "notes": "Clear transitions."
      },
      {
        "id": 24,
        "slug": "voice-shift",
        "name": "Voice Shift",
        "category": "Emotion",
        "description": "Change narration tone with the story.",
        "howItWorks": "Reinforces mood.",
        "whyItWorks": "Keeps attention.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Any"
        ],
        "bestAdventureArchetypes": [
          "Any"
        ],
        "bestEmotionalArcs": [
          "Any"
        ],
        "bestAge": "4–10",
        "example": "—",
        "notes": "Smooth transitions."
      },
      {
        "id": 25,
        "slug": "heartbeat-moment",
        "name": "Heartbeat Moment",
        "category": "Emotion",
        "description": "One short sentence before the climax.",
        "howItWorks": "Builds tension.",
        "whyItWorks": "Powerful page turn.",
        "bestStoryStage": "Climax",
        "bestStoryStructures": [
          "Adventure Story"
        ],
        "bestAdventureArchetypes": [
          "Race Against Time"
        ],
        "bestEmotionalArcs": [
          "Anxiety"
        ],
        "bestAge": "5–10",
        "example": "\"Everything stopped.\"",
        "notes": "Keep very short."
      },
      {
        "id": 26,
        "slug": "page-turn-sentence",
        "name": "Page-Turn Sentence",
        "category": "Flow",
        "description": "End with a sentence that demands the next page.",
        "howItWorks": "Creates momentum.",
        "whyItWorks": "Essential for picture books.",
        "bestStoryStage": "Every Spread",
        "bestStoryStructures": [
          "Any"
        ],
        "bestAdventureArchetypes": [
          "Any"
        ],
        "bestEmotionalArcs": [
          "Any"
        ],
        "bestAge": "4–10",
        "example": "\"But then...\"",
        "notes": "Most important device."
      },
      {
        "id": 27,
        "slug": "cliffhanger-line",
        "name": "Cliffhanger Line",
        "category": "Flow",
        "description": "Pause before revealing the answer.",
        "howItWorks": "Builds suspense.",
        "whyItWorks": "Keeps children listening.",
        "bestStoryStage": "Mid Story",
        "bestStoryStructures": [
          "Mystery Story"
        ],
        "bestAdventureArchetypes": [
          "Mystery to Solve"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–10",
        "example": "—",
        "notes": "Best before discoveries."
      },
      {
        "id": 28,
        "slug": "visual-pause",
        "name": "Visual Pause",
        "category": "Flow",
        "description": "Allow the illustration to finish the moment.",
        "howItWorks": "Balances text and art.",
        "whyItWorks": "Improves pacing.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Any"
        ],
        "bestAdventureArchetypes": [
          "Any"
        ],
        "bestEmotionalArcs": [
          "Wonder"
        ],
        "bestAge": "4–10",
        "example": "—",
        "notes": "Don't explain the picture."
      },
      {
        "id": 29,
        "slug": "illustration-echo",
        "name": "Illustration Echo",
        "category": "Flow",
        "description": "Text hints at something visible but doesn't describe it fully.",
        "howItWorks": "Encourages observation.",
        "whyItWorks": "Supports rereading.",
        "bestStoryStage": "Throughout",
        "bestStoryStructures": [
          "Discovery Story"
        ],
        "bestAdventureArchetypes": [
          "Secret Discovery"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–10",
        "example": "—",
        "notes": "Trust the illustrator."
      },
      {
        "id": 30,
        "slug": "closing-whisper",
        "name": "Closing Whisper",
        "category": "Flow",
        "description": "End with a soft, memorable sentence.",
        "howItWorks": "Leaves emotional resonance.",
        "whyItWorks": "Ideal bedtime ending.",
        "bestStoryStage": "Final Page",
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "Peace"
        ],
        "bestAge": "4–10",
        "example": "\"And the forest smiled.\"",
        "notes": "Short and gentle."
      }
    ],
    "titleFormulas": [
      {
        "id": 1,
        "slug": "character-adventure",
        "name": "Character + Adventure",
        "pattern": "Hero + Adventure",
        "description": "Focuses on the hero's journey.",
        "whyItWorks": "Personal connection.",
        "bestStoryTypes": [
          "Adventure"
        ],
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestAdventureArchetypes": [
          "Great Journey"
        ],
        "bestEmotionalArcs": [
          "Courage"
        ],
        "bestAge": "5–8",
        "exampleTitles": [
          "Chinu's Big Adventure"
        ],
        "notes": "Most versatile"
      },
      {
        "id": 2,
        "slug": "character-object",
        "name": "Character + Object",
        "pattern": "Hero + Important Object",
        "description": "Highlights a key object.",
        "whyItWorks": "Sparks curiosity.",
        "bestStoryTypes": [
          "Discovery"
        ],
        "bestStoryStructures": [
          "Mystery Story"
        ],
        "bestAdventureArchetypes": [
          "Treasure Hunt"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–8",
        "exampleTitles": [
          "Mira and the Golden Feather"
        ],
        "notes": "Quest stories"
      },
      {
        "id": 3,
        "slug": "character-place",
        "name": "Character + Place",
        "pattern": "Hero + Place",
        "description": "Emphasises the world.",
        "whyItWorks": "Strong setting.",
        "bestStoryTypes": [
          "Exploration"
        ],
        "bestStoryStructures": [
          "Expedition"
        ],
        "bestAdventureArchetypes": [
          "Hidden World"
        ],
        "bestEmotionalArcs": [
          "Wonder"
        ],
        "bestAge": "5–8",
        "exampleTitles": [
          "Kabir at Crystal Falls"
        ],
        "notes": "World-focused"
      },
      {
        "id": 4,
        "slug": "character-problem",
        "name": "Character + Problem",
        "pattern": "Hero + Challenge",
        "description": "Presents the central conflict.",
        "whyItWorks": "Immediate engagement.",
        "bestStoryTypes": [
          "Growth"
        ],
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Hero's Trial"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "Neel's Impossible Climb"
        ],
        "notes": "Strong emotional hook"
      },
      {
        "id": 5,
        "slug": "character-friend",
        "name": "Character + Friend",
        "pattern": "Hero + Friend",
        "description": "Relationship-focused.",
        "whyItWorks": "Warm and relatable.",
        "bestStoryTypes": [
          "Friendship"
        ],
        "bestStoryStructures": [
          "Friendship Story"
        ],
        "bestAdventureArchetypes": [
          "New Friend"
        ],
        "bestEmotionalArcs": [
          "Belonging"
        ],
        "bestAge": "4–8",
        "exampleTitles": [
          "Chinu and a New Friend"
        ],
        "notes": "Younger readers"
      },
      {
        "id": 6,
        "slug": "character-promise",
        "name": "Character + Promise",
        "pattern": "Hero + Promise",
        "description": "Highlights responsibility.",
        "whyItWorks": "Creates investment.",
        "bestStoryTypes": [
          "Community"
        ],
        "bestStoryStructures": [
          "Promise Story"
        ],
        "bestAdventureArchetypes": [
          "Promise Keeper"
        ],
        "bestEmotionalArcs": [
          "Responsibility"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "Veer's Promise"
        ],
        "notes": "Emotional stories"
      },
      {
        "id": 7,
        "slug": "character-festival",
        "name": "Character + Festival",
        "pattern": "Hero + Celebration",
        "description": "Festival-centred.",
        "whyItWorks": "Bright and memorable.",
        "bestStoryTypes": [
          "Celebration"
        ],
        "bestStoryStructures": [
          "Celebration Story"
        ],
        "bestAdventureArchetypes": [
          "Festival Adventure"
        ],
        "bestEmotionalArcs": [
          "Joy"
        ],
        "bestAge": "5–8",
        "exampleTitles": [
          "Mayur's Festival Surprise"
        ],
        "notes": "Cultural stories"
      },
      {
        "id": 8,
        "slug": "character-discovery",
        "name": "Character + Discovery",
        "pattern": "Hero + Discovery",
        "description": "Something important is found.",
        "whyItWorks": "Creates curiosity.",
        "bestStoryTypes": [
          "Mystery"
        ],
        "bestStoryStructures": [
          "Discovery Story"
        ],
        "bestAdventureArchetypes": [
          "Secret Discovery"
        ],
        "bestEmotionalArcs": [
          "Wonder"
        ],
        "bestAge": "5–8",
        "exampleTitles": [
          "Arin Finds a Secret Path"
        ],
        "notes": "Great for page turns"
      },
      {
        "id": 9,
        "slug": "the-secret-of",
        "name": "The Secret of...",
        "pattern": "The Secret of + Place/Object",
        "description": "Mystery-driven.",
        "whyItWorks": "Curiosity gap.",
        "bestStoryTypes": [
          "Mystery"
        ],
        "bestStoryStructures": [
          "Mystery Story"
        ],
        "bestAdventureArchetypes": [
          "Ancient Secret"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–10",
        "exampleTitles": [
          "The Secret of Whispering Woods"
        ],
        "notes": "Classic picture-book style"
      },
      {
        "id": 10,
        "slug": "the-lost",
        "name": "The Lost...",
        "pattern": "The Lost + Object",
        "description": "Missing object/person.",
        "whyItWorks": "Clear goal.",
        "bestStoryTypes": [
          "Rescue"
        ],
        "bestStoryStructures": [
          "Rescue Story"
        ],
        "bestAdventureArchetypes": [
          "Rescue Mission"
        ],
        "bestEmotionalArcs": [
          "Concern"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "The Lost Lantern"
        ],
        "notes": "Strong hook"
      },
      {
        "id": 11,
        "slug": "the-little",
        "name": "The Little...",
        "pattern": "The Little + Character/Object",
        "description": "Highlights something small but important.",
        "whyItWorks": "Appeals to children.",
        "bestStoryTypes": [
          "Growth"
        ],
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Helping Hand"
        ],
        "bestEmotionalArcs": [
          "Hope"
        ],
        "bestAge": "4–7",
        "exampleTitles": [
          "The Little Seed"
        ],
        "notes": "Gentle stories"
      },
      {
        "id": 12,
        "slug": "the-hidden",
        "name": "The Hidden...",
        "pattern": "The Hidden + Place",
        "description": "Discovery focus.",
        "whyItWorks": "Encourages exploration.",
        "bestStoryTypes": [
          "Discovery"
        ],
        "bestStoryStructures": [
          "Discovery Story"
        ],
        "bestAdventureArchetypes": [
          "Hidden World"
        ],
        "bestEmotionalArcs": [
          "Wonder"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "The Hidden Garden"
        ],
        "notes": "Adventure stories"
      },
      {
        "id": 13,
        "slug": "the-last",
        "name": "The Last...",
        "pattern": "The Last + Item",
        "description": "Scarcity creates tension.",
        "whyItWorks": "Immediate stakes.",
        "bestStoryTypes": [
          "Adventure"
        ],
        "bestStoryStructures": [
          "Hero Story"
        ],
        "bestAdventureArchetypes": [
          "Race Against Time"
        ],
        "bestEmotionalArcs": [
          "Determination"
        ],
        "bestAge": "6–10",
        "exampleTitles": [
          "The Last Lotus"
        ],
        "notes": "High stakes"
      },
      {
        "id": 14,
        "slug": "the-gift-of",
        "name": "The Gift of...",
        "pattern": "The Gift of + Value/Object",
        "description": "Emotional focus.",
        "whyItWorks": "Warm and memorable.",
        "bestStoryTypes": [
          "Friendship"
        ],
        "bestStoryStructures": [
          "Relationship Story"
        ],
        "bestAdventureArchetypes": [
          "Gift of Giving"
        ],
        "bestEmotionalArcs": [
          "Gratitude"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "The Gift of Kindness"
        ],
        "notes": "Values stories"
      },
      {
        "id": 15,
        "slug": "the-song-of",
        "name": "The Song of...",
        "pattern": "The Song of + Nature",
        "description": "Nature-centred.",
        "whyItWorks": "Poetic and calming.",
        "bestStoryTypes": [
          "Nature"
        ],
        "bestStoryStructures": [
          "Nature Story"
        ],
        "bestAdventureArchetypes": [
          "Nature's Balance"
        ],
        "bestEmotionalArcs": [
          "Wonder"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "The Song of the River"
        ],
        "notes": "Beautiful read-aloud titles"
      },
      {
        "id": 16,
        "slug": "how-saved",
        "name": "How ___ Saved...",
        "pattern": "How + Hero + Saved...",
        "description": "Hero immediately feels active.",
        "whyItWorks": "Action-driven.",
        "bestStoryTypes": [
          "Rescue"
        ],
        "bestStoryStructures": [
          "Rescue Story"
        ],
        "bestAdventureArchetypes": [
          "Rescue Mission"
        ],
        "bestEmotionalArcs": [
          "Courage"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "How Chinu Saved the Nest"
        ],
        "notes": "Strong verbs"
      },
      {
        "id": 17,
        "slug": "the-day-we",
        "name": "The Day We...",
        "pattern": "The Day We + Action",
        "description": "Shared adventure.",
        "whyItWorks": "Inclusive.",
        "bestStoryTypes": [
          "Team"
        ],
        "bestStoryStructures": [
          "Community Story"
        ],
        "bestAdventureArchetypes": [
          "Team Adventure"
        ],
        "bestEmotionalArcs": [
          "Belonging"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "The Day We Built a Bridge"
        ],
        "notes": "Great for teamwork"
      },
      {
        "id": 18,
        "slug": "racing-to",
        "name": "Racing to...",
        "pattern": "Racing to + Goal",
        "description": "Urgency.",
        "whyItWorks": "High energy.",
        "bestStoryTypes": [
          "Adventure"
        ],
        "bestStoryStructures": [
          "Time Story"
        ],
        "bestAdventureArchetypes": [
          "Race Against Time"
        ],
        "bestEmotionalArcs": [
          "Determination"
        ],
        "bestAge": "5–10",
        "exampleTitles": [
          "Racing to the Festival"
        ],
        "notes": "Fast-paced"
      },
      {
        "id": 19,
        "slug": "building",
        "name": "Building...",
        "pattern": "Building + Object",
        "description": "Creative mission.",
        "whyItWorks": "Clear purpose.",
        "bestStoryTypes": [
          "Creation"
        ],
        "bestStoryStructures": [
          "Builder Story"
        ],
        "bestAdventureArchetypes": [
          "Build Together"
        ],
        "bestEmotionalArcs": [
          "Achievement"
        ],
        "bestAge": "5–8",
        "exampleTitles": [
          "Building the Treehouse"
        ],
        "notes": "Maker stories"
      },
      {
        "id": 20,
        "slug": "searching-for",
        "name": "Searching for...",
        "pattern": "Searching for + Object",
        "description": "Discovery mission.",
        "whyItWorks": "Immediate curiosity.",
        "bestStoryTypes": [
          "Mystery"
        ],
        "bestStoryStructures": [
          "Discovery Story"
        ],
        "bestAdventureArchetypes": [
          "Secret Discovery"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "Searching for the Blue Feather"
        ],
        "notes": "Excellent for quests"
      },
      {
        "id": 21,
        "slug": "the-brave",
        "name": "The Brave...",
        "pattern": "The Brave + Character",
        "description": "Courage-focused.",
        "whyItWorks": "Aspirational.",
        "bestStoryTypes": [
          "Growth"
        ],
        "bestStoryStructures": [
          "Hero Story"
        ],
        "bestAdventureArchetypes": [
          "Hero's Trial"
        ],
        "bestEmotionalArcs": [
          "Courage"
        ],
        "bestAge": "5–8",
        "exampleTitles": [
          "The Brave Little Rabbit"
        ],
        "notes": "Popular style"
      },
      {
        "id": 22,
        "slug": "the-kind",
        "name": "The Kind...",
        "pattern": "The Kind + Character",
        "description": "Kindness-focused.",
        "whyItWorks": "Warm emotional appeal.",
        "bestStoryTypes": [
          "Friendship"
        ],
        "bestStoryStructures": [
          "Helping Story"
        ],
        "bestAdventureArchetypes": [
          "Helping Hand"
        ],
        "bestEmotionalArcs": [
          "Compassion"
        ],
        "bestAge": "4–8",
        "exampleTitles": [
          "The Kind Squirrel"
        ],
        "notes": "Gentle stories"
      },
      {
        "id": 23,
        "slug": "the-quiet",
        "name": "The Quiet...",
        "pattern": "The Quiet + Character/Object",
        "description": "Reflection-focused.",
        "whyItWorks": "Creates intrigue.",
        "bestStoryTypes": [
          "Emotional"
        ],
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Dream Adventure"
        ],
        "bestEmotionalArcs": [
          "Peace"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "The Quiet River"
        ],
        "notes": "Calm stories"
      },
      {
        "id": 24,
        "slug": "the-patient",
        "name": "The Patient...",
        "pattern": "The Patient + Character",
        "description": "Patience-focused.",
        "whyItWorks": "Growth mindset.",
        "bestStoryTypes": [
          "Growth"
        ],
        "bestStoryStructures": [
          "Training Story"
        ],
        "bestAdventureArchetypes": [
          "Training Journey"
        ],
        "bestEmotionalArcs": [
          "Perseverance"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "The Patient Turtle"
        ],
        "notes": "Self-regulation"
      },
      {
        "id": 25,
        "slug": "learning-to",
        "name": "Learning to...",
        "pattern": "Learning to + Action",
        "description": "Highlights growth.",
        "whyItWorks": "Transformation is clear.",
        "bestStoryTypes": [
          "Coming of Age"
        ],
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Coming of Age"
        ],
        "bestEmotionalArcs": [
          "Growth"
        ],
        "bestAge": "5–10",
        "exampleTitles": [
          "Learning to Listen"
        ],
        "notes": "Emotional stories"
      },
      {
        "id": 26,
        "slug": "when-the-forest",
        "name": "When the Forest...",
        "pattern": "When the + Nature Element",
        "description": "Nature begins the story.",
        "whyItWorks": "Builds wonder.",
        "bestStoryTypes": [
          "Nature"
        ],
        "bestStoryStructures": [
          "Discovery Story"
        ],
        "bestAdventureArchetypes": [
          "Nature's Balance"
        ],
        "bestEmotionalArcs": [
          "Wonder"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "When the Forest Whispered"
        ],
        "notes": "Strong Prana Kids feel"
      },
      {
        "id": 27,
        "slug": "the-whispering",
        "name": "The Whispering...",
        "pattern": "The Whispering + Place",
        "description": "Mysterious location.",
        "whyItWorks": "Sparks curiosity.",
        "bestStoryTypes": [
          "Mystery"
        ],
        "bestStoryStructures": [
          "Hidden World Story"
        ],
        "bestAdventureArchetypes": [
          "Hidden World"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "The Whispering Cave"
        ],
        "notes": "World-building"
      },
      {
        "id": 28,
        "slug": "the-wisdom-of",
        "name": "The Wisdom of...",
        "pattern": "The Wisdom of + Symbol",
        "description": "Centres the story on a wisdom element.",
        "whyItWorks": "Fits the Prana Kids philosophy.",
        "bestStoryTypes": [
          "Wisdom"
        ],
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestAdventureArchetypes": [
          "Heritage Journey"
        ],
        "bestEmotionalArcs": [
          "Understanding"
        ],
        "bestAge": "6–10",
        "exampleTitles": [
          "The Wisdom of the Lotus"
        ],
        "notes": "Symbol-driven"
      },
      {
        "id": 29,
        "slug": "following-the",
        "name": "Following the...",
        "pattern": "Following the + Clue/Trail",
        "description": "Suggests exploration and purpose.",
        "whyItWorks": "Encourages adventure.",
        "bestStoryTypes": [
          "Quest"
        ],
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestAdventureArchetypes": [
          "Expedition"
        ],
        "bestEmotionalArcs": [
          "Curiosity"
        ],
        "bestAge": "5–9",
        "exampleTitles": [
          "Following the Fireflies"
        ],
        "notes": "Excellent for nature stories"
      },
      {
        "id": 30,
        "slug": "one-small-step",
        "name": "One Small Step...",
        "pattern": "One Small Step + Goal",
        "description": "Emphasises gradual growth.",
        "whyItWorks": "Reinforces perseverance.",
        "bestStoryTypes": [
          "Growth"
        ],
        "bestStoryStructures": [
          "Training Story"
        ],
        "bestAdventureArchetypes": [
          "Training Journey"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Confidence"
        ],
        "bestAge": "5–10",
        "exampleTitles": [
          "One Small Step to the Summit"
        ],
        "notes": "Perfect for Prana Kids' growth philosophy"
      }
    ],
    "storyConflicts": [
      {
        "id": 1,
        "slug": "rescue-conflict",
        "name": "Rescue Conflict",
        "description": "Someone needs saving before it's too late.",
        "generatedFrom": "Rescue Mission + Physical Obstacle",
        "bestStoryStructures": [
          "Rescue Story"
        ],
        "bestEmotionalArcs": [
          "Fear → Courage"
        ]
      },
      {
        "id": 2,
        "slug": "journey-conflict",
        "name": "Journey Conflict",
        "description": "The destination seems impossible to reach.",
        "generatedFrom": "Great Journey + Nature Obstacle",
        "bestStoryStructures": [
          "Journey Story"
        ],
        "bestEmotionalArcs": [
          "Doubt → Confidence"
        ]
      },
      {
        "id": 3,
        "slug": "trust-conflict",
        "name": "Trust Conflict",
        "description": "Others don't believe the hero.",
        "generatedFrom": "Social Obstacle",
        "bestStoryStructures": [
          "Relationship Story"
        ],
        "bestEmotionalArcs": [
          "Self-Doubt → Confidence"
        ]
      },
      {
        "id": 4,
        "slug": "friendship-conflict",
        "name": "Friendship Conflict",
        "description": "Friends are drifting apart or arguing.",
        "generatedFrom": "Friendship Mission + Social Obstacle",
        "bestStoryStructures": [
          "Friendship Story"
        ],
        "bestEmotionalArcs": [
          "Hurt → Belonging"
        ]
      },
      {
        "id": 5,
        "slug": "responsibility-conflict",
        "name": "Responsibility Conflict",
        "description": "The hero must fulfil an important duty.",
        "generatedFrom": "Responsibility Mission",
        "bestStoryStructures": [
          "Responsibility Story"
        ],
        "bestEmotionalArcs": [
          "Hesitation → Pride"
        ]
      },
      {
        "id": 6,
        "slug": "nature-conflict",
        "name": "Nature Conflict",
        "description": "Nature itself blocks the mission.",
        "generatedFrom": "Nature Obstacle",
        "bestStoryStructures": [
          "Survival Story"
        ],
        "bestEmotionalArcs": [
          "Fear → Resilience"
        ]
      },
      {
        "id": 7,
        "slug": "puzzle-conflict",
        "name": "Puzzle Conflict",
        "description": "Progress depends on solving a mystery or riddle.",
        "generatedFrom": "Puzzle Obstacle",
        "bestStoryStructures": [
          "Mystery Story"
        ],
        "bestEmotionalArcs": [
          "Confusion → Clarity"
        ]
      },
      {
        "id": 8,
        "slug": "time-conflict",
        "name": "Time Conflict",
        "description": "The mission must finish before time runs out.",
        "generatedFrom": "Time Obstacle",
        "bestStoryStructures": [
          "Race Against Time"
        ],
        "bestEmotionalArcs": [
          "Anxiety → Determination"
        ]
      },
      {
        "id": 9,
        "slug": "community-conflict",
        "name": "Community Conflict",
        "description": "The group cannot work together.",
        "generatedFrom": "Community Mission + Social Obstacle",
        "bestStoryStructures": [
          "Community Story"
        ],
        "bestEmotionalArcs": [
          "Frustration → Cooperation"
        ]
      },
      {
        "id": 10,
        "slug": "inner-conflict",
        "name": "Inner Conflict",
        "description": "The hero's own false belief is the biggest obstacle.",
        "generatedFrom": "Core Need",
        "bestStoryStructures": [
          "Transformation Story"
        ],
        "bestEmotionalArcs": [
          "False Belief → True Belief"
        ]
      }
    ],
    "escalations": [
      {
        "id": 1,
        "slug": "obstacle-gets-harder",
        "name": "Obstacle Gets Harder",
        "description": "The existing obstacle becomes more difficult.",
        "commonUse": "Any story"
      },
      {
        "id": 2,
        "slug": "new-obstacle-appears",
        "name": "New Obstacle Appears",
        "description": "A second challenge blocks progress.",
        "commonUse": "Adventure"
      },
      {
        "id": 3,
        "slug": "time-runs-short",
        "name": "Time Runs Short",
        "description": "Less time remains to finish the mission.",
        "commonUse": "Time stories"
      },
      {
        "id": 4,
        "slug": "wrong-choice",
        "name": "Wrong Choice",
        "description": "The hero's mistake makes things worse.",
        "commonUse": "Growth stories"
      },
      {
        "id": 5,
        "slug": "someone-gives-up",
        "name": "Someone Gives Up",
        "description": "A companion loses hope.",
        "commonUse": "Team stories"
      },
      {
        "id": 6,
        "slug": "nature-changes",
        "name": "Nature Changes",
        "description": "Weather or environment suddenly changes.",
        "commonUse": "Nature stories"
      },
      {
        "id": 7,
        "slug": "important-clue-lost",
        "name": "Important Clue Lost",
        "description": "A clue disappears or becomes unusable.",
        "commonUse": "Mystery stories"
      },
      {
        "id": 8,
        "slug": "plan-fails",
        "name": "Plan Fails",
        "description": "The first solution doesn't work.",
        "commonUse": "Problem-solving"
      },
      {
        "id": 9,
        "slug": "mission-seems-impossible",
        "name": "Mission Seems Impossible",
        "description": "The hero reaches the emotional low.",
        "commonUse": "Almost every story"
      },
      {
        "id": 10,
        "slug": "difficult-choice",
        "name": "Difficult Choice",
        "description": "Two good options force a meaningful decision.",
        "commonUse": "Moral stories"
      },
      {
        "id": 11,
        "slug": "unexpected-twist",
        "name": "Unexpected Twist",
        "description": "A surprising revelation changes the situation.",
        "commonUse": "Mystery/Discovery"
      },
      {
        "id": 12,
        "slug": "rival-interferes",
        "name": "Rival Interferes",
        "description": "Another character unintentionally or intentionally complicates the mission.",
        "commonUse": "Competition stories"
      }
    ],
    "storyQualityScorecard": [
      {
        "name": "Story Seed",
        "maxScore": 5,
        "checks": [
          "Childhood Situation feels authentic",
          "Core Need is clear",
          "False Belief drives the story",
          "Appropriate for target age",
          "Story has emotional potential"
        ]
      },
      {
        "name": "Story Engine",
        "maxScore": 10,
        "checks": [
          "Life Domain fits naturally",
          "Story Action drives the plot",
          "Adventure Archetype matches the mission",
          "Mission feels meaningful",
          "Obstacle creates challenge",
          "Story World supports the adventure",
          "Character Goal is clear",
          "Escalation increases naturally",
          "Conflict feels believable",
          "Everything maps correctly through the engine"
        ]
      },
      {
        "name": "Story Structure",
        "maxScore": 10,
        "checks": [
          "Strong opening",
          "Every slide moves the story",
          "Good pacing",
          "Midpoint changes the story",
          "Emotional Low feels earned",
          "Climax is satisfying",
          "Ending resolves naturally",
          "No unnecessary scenes",
          "Clear page turns",
          "Story feels complete"
        ]
      },
      {
        "name": "Emotional Journey",
        "maxScore": 10,
        "checks": [
          "Primary emotion is clear",
          "Emotional arc is believable",
          "Body language supports emotion",
          "Behaviour feels authentic",
          "Dialogue reflects emotion",
          "Inner thoughts are consistent",
          "Emotional growth feels earned",
          "Emotion is shown, not told",
          "Resolution satisfies",
          "Child can relate emotionally"
        ]
      },
      {
        "name": "Wisdom Layer",
        "maxScore": 10,
        "checks": [
          "Wisdom Element fits naturally",
          "Teaching Method is appropriate",
          "Wisdom comes through experience",
          "Mentor guides but doesn't solve",
          "Symbol appears naturally",
          "New Choice shows transformation",
          "Story Expression feels organic",
          "No preaching",
          "Wisdom is memorable",
          "Prana Kids philosophy is maintained"
        ]
      },
      {
        "name": "Storytelling Craft",
        "maxScore": 10,
        "checks": [
          "Opening Hook is strong",
          "Storytelling Techniques are effective",
          "Technique Combination works well",
          "Curiosity keeps increasing",
          "Page-turns are compelling",
          "Replay Hooks are included",
          "Read-Aloud Devices improve rhythm",
          "Title suits the story",
          "Ending is memorable",
          "Overall storytelling feels polished"
        ]
      },
      {
        "name": "Character & World",
        "maxScore": 10,
        "checks": [
          "Hero is relatable",
          "Supporting characters matter",
          "Character relationships feel real",
          "Story World feels alive",
          "Nature participates in the story",
          "Props are used meaningfully",
          "Setting changes with the story",
          "World mechanics are consistent",
          "Illustrations have visual variety",
          "World is memorable"
        ]
      },
      {
        "name": "Replay & Read-Aloud",
        "maxScore": 10,
        "checks": [
          "Repeated phrase included",
          "Hidden visual detail",
          "Prediction/Search moment",
          "Callback included",
          "Rhythm reads aloud naturally",
          "Sentence length is appropriate",
          "Dialogue sounds natural",
          "Sound words used effectively",
          "Child will ask for another reading",
          "Parent will enjoy rereading"
        ]
      },
      {
        "name": "Illustration Potential",
        "maxScore": 10,
        "checks": [
          "Every spread is visually distinct",
          "Emotional expressions are clear",
          "Nature supports storytelling",
          "Dynamic compositions",
          "Visual page-turn moments",
          "Colour progression supports mood",
          "Hidden replay details included",
          "Character acting is expressive",
          "Background tells part of the story",
          "Final spread is memorable"
        ]
      },
      {
        "name": "Prana Kids Identity",
        "maxScore": 10,
        "checks": [
          "Wonder over preaching",
          "Emotional wisdom through experience",
          "Nature is a character",
          "Child solves the problem",
          "Curiosity is encouraged",
          "Kindness is demonstrated",
          "Courage grows naturally",
          "Hopeful emotional tone",
          "Original Prana Kids feel",
          "Story feels timeless"
        ]
      },
      {
        "name": "Originality",
        "maxScore": 5,
        "checks": [
          "Fresh premise",
          "Fresh emotional angle",
          "Fresh visual idea",
          "Doesn't feel derivative",
          "Memorable concept"
        ]
      },
      {
        "name": "Age Appropriateness",
        "maxScore": 5,
        "checks": [
          "Vocabulary suitable",
          "Emotional depth appropriate",
          "Attention span respected",
          "Concepts understandable",
          "Reading experience enjoyable"
        ]
      },
      {
        "name": "Overall Magic Test",
        "maxScore": 5,
        "checks": [
          "Would a child ask to hear it again tonight?",
          "Would a parent enjoy reading it repeatedly?",
          "Is there one unforgettable illustration?",
          "Is there one unforgettable line?",
          "Does it unmistakably feel like Prana Kids?"
        ]
      }
    ]
  }
};
